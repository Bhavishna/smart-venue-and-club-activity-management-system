import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

// Base protected route that checks if user is authenticated
export const ProtectedRoute = ({ children, roles = [] }) => {
  const { currentUser } = useAuth();
  const location = useLocation();

  if (!currentUser) {
    // Redirect to login if not authenticated
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // If roles are specified, check if user's role is allowed
  if (roles.length > 0 && !roles.includes(currentUser.role)) {
    // Redirect to unauthorized page
    return <Navigate to="/unauthorized" replace />;
  }

  return children;
};

// Role-specific route components
export const AdminRoute = ({ children }) => (
  <ProtectedRoute roles={['admin']}>
    {children}
  </ProtectedRoute>
);

export const FacultyRoute = ({ children }) => (
  <ProtectedRoute roles={['faculty', 'admin']}>
    {children}
  </ProtectedRoute>
);

export const StudentCoordinatorRoute = ({ children }) => (
  <ProtectedRoute roles={['studentCoordinator', 'admin']}>
    {children}
  </ProtectedRoute>
);

export const StudentRoute = ({ children }) => (
  <ProtectedRoute roles={['student', 'studentCoordinator', 'faculty', 'admin']}>
    {children}
  </ProtectedRoute>
);
