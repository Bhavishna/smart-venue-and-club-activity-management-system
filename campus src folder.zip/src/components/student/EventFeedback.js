import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import useCollectionData from '../../hooks/useCollection';

const EventFeedback = ({ eventId, onClose }) => {
  const { currentUser } = useAuth();
  
  const { items: feedback, addItem: addFeedback, updateItem } = useCollectionData('feedback');
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const [hasSubmitted, setHasSubmitted] = useState(false);
  const [existingFeedback, setExistingFeedback] = useState(null);
  
  // Check if user has already submitted feedback
  useEffect(() => {
    if (currentUser && eventId) {
      const existing = feedback.find(
        f => f.eventId === eventId && f.studentId === currentUser.id
      );
      
      if (existing) {
        setHasSubmitted(true);
        setExistingFeedback(existing);
        setRating(existing.rating);
        setComment(existing.comment || '');
      }
    }
  }, [currentUser, eventId, feedback]);
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (rating === 0) {
      setError('Please select a rating');
      return;
    }
    
    try {
      const feedbackData = {
        eventId,
        studentId: currentUser.id,
        rating,
        comment,
        submittedAt: new Date().toISOString()
      };
      
      if (hasSubmitted && existingFeedback) {
        // Update existing feedback
        await updateItem(existingFeedback.id, {
          ...feedbackData,
          updatedAt: new Date().toISOString()
        });
      } else {
        // Add new feedback
        await addFeedback(feedbackData);
      }
      
      setSuccess(true);
      setError('');
      
      // Close the feedback form after 2 seconds
      setTimeout(() => {
        if (onClose) onClose();
      }, 2000);
    } catch (err) {
      console.error('Feedback submission error:', err);
      setError('Failed to submit feedback. Please try again.');
    }
  };
  
  // Star rating component
  const StarRating = () => (
    <div style={{ display: 'flex', gap: '10px' }}>
      {[1, 2, 3, 4, 5].map(star => (
        <button
          key={star}
          type="button"
          onClick={() => setRating(star)}
          style={{
            backgroundColor: 'transparent',
            border: 'none',
            fontSize: '30px',
            cursor: 'pointer',
            color: rating >= star ? '#f39c12' : '#ddd'
          }}
          aria-label={`${star} stars`}
        >
          ★
        </button>
      ))}
    </div>
  );
  
  return (
    <div className="feedback-modal" style={{ 
      backgroundColor: 'white',
      borderRadius: '8px',
      padding: '20px',
      maxWidth: '500px',
      width: '100%',
      boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)'
    }}>
      <div style={{ 
        display: 'flex', 
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: '20px'
      }}>
        <h2 style={{ margin: 0 }}>
          {hasSubmitted ? 'Update Feedback' : 'Submit Feedback'}
        </h2>
        <button
          onClick={onClose}
          style={{
            background: 'none',
            border: 'none',
            fontSize: '20px',
            cursor: 'pointer',
            color: '#666'
          }}
          aria-label="Close"
        >
          ×
        </button>
      </div>
      
      {success ? (
        <div className="success-message" style={{ 
          padding: '15px', 
          backgroundColor: '#d4edda', 
          color: '#155724',
          borderRadius: '5px',
          marginBottom: '20px',
          textAlign: 'center'
        }}>
          Thank you for your feedback!
        </div>
      ) : (
        <>
          {error && (
            <div className="error-message" style={{ 
              padding: '15px', 
              backgroundColor: '#f8d7da', 
              color: '#721c24',
              borderRadius: '5px',
              marginBottom: '20px'
            }}>
              {error}
            </div>
          )}
          
          {hasSubmitted && !success && (
            <div className="update-notice" style={{ 
              padding: '15px', 
              backgroundColor: '#fff3cd', 
              color: '#856404',
              borderRadius: '5px',
              marginBottom: '20px'
            }}>
              You've already submitted feedback for this event. Your feedback is being updated.
            </div>
          )}
          
          <form onSubmit={handleSubmit}>
            <div style={{ marginBottom: '20px' }}>
              <label style={{ display: 'block', marginBottom: '10px', fontWeight: 'bold' }}>
                Rate your experience:
              </label>
              <StarRating />
            </div>
            
            <div style={{ marginBottom: '20px' }}>
              <label htmlFor="comment" style={{ display: 'block', marginBottom: '10px', fontWeight: 'bold' }}>
                Your Comments (optional):
              </label>
              <textarea
                id="comment"
                value={comment}
                onChange={e => setComment(e.target.value)}
                rows={4}
                style={{
                  width: '100%',
                  padding: '10px',
                  borderRadius: '4px',
                  border: '1px solid #ddd',
                  resize: 'vertical'
                }}
                placeholder="Share your thoughts about this event..."
              />
            </div>
            
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px' }}>
              <button
                type="button"
                onClick={onClose}
                style={{
                  padding: '10px 15px',
                  backgroundColor: '#f0f0f0',
                  color: '#333',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
              >
                Cancel
              </button>
              <button
                type="submit"
                style={{
                  padding: '10px 15px',
                  backgroundColor: '#f39c12',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
              >
                {hasSubmitted ? 'Update Feedback' : 'Submit Feedback'}
              </button>
            </div>
          </form>
        </>
      )}
    </div>
  );
};

export default EventFeedback;
