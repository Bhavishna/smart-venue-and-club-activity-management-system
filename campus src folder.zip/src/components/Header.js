import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Header = () => {
  const { currentUser, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <header style={{ 
      backgroundColor: '#333',
      color: 'white',
      padding: '10px 20px',
      marginBottom: '20px'
    }}>
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        maxWidth: '1200px',
        margin: '0 auto'
      }}>
        <div>
          <Link to="/" style={{ color: 'white', textDecoration: 'none', fontSize: '20px', fontWeight: 'bold' }}>
            Education Management System
          </Link>
        </div>
        
        <nav>
          {currentUser ? (
            <div style={{ display: 'flex', alignItems: 'center' }}>
              <Link to="/dashboard" style={{ color: 'white', textDecoration: 'none', marginRight: '20px' }}>
                Dashboard
              </Link>
              
              <span style={{ marginRight: '20px' }}>
                {currentUser.name} ({currentUser.role})
              </span>
              
              <button 
                onClick={handleLogout}
                style={{ 
                  backgroundColor: '#e74c3c',
                  color: 'white',
                  border: 'none',
                  padding: '8px 15px',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
              >
                Logout
              </button>
            </div>
          ) : (
            <div>
              <Link to="/login" style={{ color: 'white', textDecoration: 'none', marginRight: '20px' }}>
                Login
              </Link>
              <Link to="/signup" style={{ color: 'white', textDecoration: 'none' }}>
                Sign Up
              </Link>
            </div>
          )}
        </nav>
      </div>
    </header>
  );
};

export default Header;
