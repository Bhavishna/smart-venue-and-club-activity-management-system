// src/hooks/useCollection.js
import { useState, useEffect, useCallback } from 'react';
import * as dataUtils from '../utils/dataUtils';

/**
 * Custom hook for working with collections in the data model
 * @param {string} collectionName - The name of the collection
 */
const useCollectionData = (collectionName) => {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  // Load all items from the collection
  const loadItems = useCallback(() => {
    try {
      setLoading(true);
      const data = dataUtils.getAll(collectionName);
      setItems(data);
      setError(null);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }, [collectionName]);
  
  // Load items on mount and when collection name changes
  useEffect(() => {
    loadItems();
  }, [loadItems]);
  
  // Get a single item by ID
  const getItem = useCallback((id) => {
    return dataUtils.getById(collectionName, id);
  }, [collectionName]);
  
  // Add a new item
  const addItem = useCallback((data) => {
    try {
      const newItem = dataUtils.create(collectionName, data);
      setItems(prev => [...prev, newItem]);
      return newItem;
    } catch (err) {
      setError(err.message);
      throw err;
    }
  }, [collectionName]);
  
  // Update an item
  const updateItem = useCallback((id, data) => {
    try {
      const updatedItem = dataUtils.update(collectionName, id, data);
      if (updatedItem) {
        setItems(prev => 
          prev.map(item => item.id === id ? updatedItem : item)
        );
      }
      return updatedItem;
    } catch (err) {
      setError(err.message);
      throw err;
    }
  }, [collectionName]);
  
  // Delete an item
  const deleteItem = useCallback((id) => {
    try {
      const success = dataUtils.remove(collectionName, id);
      if (success) {
        setItems(prev => prev.filter(item => item.id !== id));
      }
      return success;
    } catch (err) {
      setError(err.message);
      throw err;
    }
  }, [collectionName]);
  
  // Query items with a filter function
  const queryItems = useCallback((filterFn) => {
    try {
      return dataUtils.query(collectionName, filterFn);
    } catch (err) {
      setError(err.message);
      throw err;
    }
  }, [collectionName]);
  
  // Get related items
  const getRelatedItems = useCallback((relationCollectionName, foreignKey, id) => {
    try {
      return dataUtils.getRelated(relationCollectionName, foreignKey, id);
    } catch (err) {
      setError(err.message);
      throw err;
    }
  }, []);
  
  // Get related record
  const getRelatedItem = useCallback((relationCollectionName, id) => {
    try {
      return dataUtils.getRelatedRecord(relationCollectionName, id);
    } catch (err) {
      setError(err.message);
      throw err;
    }
  }, []);
  
  return {
    items,
    loading,
    error,
    loadItems,
    getItem,
    addItem,
    updateItem,
    deleteItem,
    queryItems,
    getRelatedItems,
    getRelatedItem
  };
};

export default useCollectionData;
