/**
 * Data Model Setup
 * 
 * This file defines and initializes the data model for the application
 * using localStorage as a simple database.
 */

// Prefix for all localStorage keys
const DB_PREFIX = 'myapp_';

// Define the collection schemas
const collections = {
  // Users collection
  users: {
    name: 'users',
    schema: {
      id: 'string',
      name: 'string',
      role: 'string', // admin, faculty, studentCoordinator, student
      email: 'string',
      password: 'string', // In a real app, this would be hashed
      createdAt: 'timestamp',
      updatedAt: 'timestamp'
    }
  },
  
  // Clubs collection
  clubs: {
    name: 'clubs',
    schema: {
      id: 'string',
      name: 'string',
      description: 'string',
      facultyCoordinatorId: 'string', // Reference to users collection
      studentCoordinatorId: 'string', // Reference to users collection
      createdAt: 'timestamp',
      updatedAt: 'timestamp'
    }
  },
  
  // Club membership requests
  club_requests: {
    name: 'club_requests',
    schema: {
      id: 'string',
      studentId: 'string', // Reference to users collection
      clubId: 'string', // Reference to clubs collection
      status: 'string', // pending, approved, rejected
      createdAt: 'timestamp',
      updatedAt: 'timestamp'
    }
  },
  
  // Club members
  club_members: {
    name: 'club_members',
    schema: {
      id: 'string',
      clubId: 'string', // Reference to clubs collection
      studentId: 'string', // Reference to users collection
      createdAt: 'timestamp',
      updatedAt: 'timestamp'
    }
  },
  
  // Events
  events: {
    name: 'events',
    schema: {
      id: 'string',
      clubId: 'string', // Reference to clubs collection
      title: 'string',
      desc: 'string',
      date: 'string', // ISO date string
      venueId: 'string', // Reference to venues collection
      time: 'string', // Time string (e.g., "14:00-16:00")
      requiresApproval: 'boolean',
      approved: 'boolean',
      createdAt: 'timestamp',
      updatedAt: 'timestamp'
    }
  },
  
  // Venues
  venues: {
    name: 'venues',
    schema: {
      id: 'string',
      name: 'string',
      capacity: 'number',
      createdAt: 'timestamp',
      updatedAt: 'timestamp'
    }
  },
  
  // Event registrations
  event_registrations: {
    name: 'event_registrations',
    schema: {
      id: 'string',
      eventId: 'string', // Reference to events collection
      studentId: 'string', // Reference to users collection
      createdAt: 'timestamp',
      updatedAt: 'timestamp'
    }
  },
  
  // Attendance records
  attendance_records: {
    name: 'attendance_records',
    schema: {
      id: 'string',
      eventId: 'string', // Reference to events collection
      studentId: 'string', // Reference to users collection
      FN: 'boolean', // Forenoon attendance
      AN: 'boolean', // Afternoon attendance
      timestamps: 'object', // Check-in times
      notes: 'string',
      createdAt: 'timestamp',
      updatedAt: 'timestamp'
    }
  },
  
  // Certificates
  certificates: {
    name: 'certificates',
    schema: {
      id: 'string',
      eventId: 'string', // Reference to events collection
      studentId: 'string', // Reference to users collection
      url: 'string', // URL to certificate file/image
      createdAt: 'timestamp',
      updatedAt: 'timestamp'
    }
  }
};

/**
 * Initialize the database with empty collections if they don't exist
 */
export const initializeDataModel = () => {
  // Initialize each collection as an empty array if it doesn't exist
  Object.values(collections).forEach(collection => {
    const key = `${DB_PREFIX}${collection.name}`;
    if (!localStorage.getItem(key)) {
      localStorage.setItem(key, JSON.stringify([]));
      console.log(`Initialized empty collection: ${collection.name}`);
    }
  });
  
  console.log('Data model initialized');
};

/**
 * Seed the database with sample data for testing
 */
export const seedDatabase = () => {
  // Check if we've already seeded the database
  if (localStorage.getItem(`${DB_PREFIX}db_seeded`)) {
    console.log('Database already seeded, skipping seed process');
    return;
  }
  
  // Seed users - we'll keep the existing users from Module 2
  // We'll just add a few more students for testing
  const existingUsers = JSON.parse(localStorage.getItem(`${DB_PREFIX}users`) || '[]');
  
  // Only add sample data if we don't have much data already
  if (existingUsers.length <= 4) {
    const additionalStudents = [
      {
        id: '2001',
        name: 'Alice Johnson',
        email: 'alice@example.com',
        password: 'password123',
        role: 'student',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: '2002',
        name: 'Bob Smith',
        email: 'bob@example.com',
        password: 'password123',
        role: 'student',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: '2003',
        name: 'Charlie Brown',
        email: 'charlie@example.com',
        password: 'password123',
        role: 'student',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }
    ];
    
    // Merge existing users with additional students
    const updatedUsers = [...existingUsers, ...additionalStudents];
    localStorage.setItem(`${DB_PREFIX}users`, JSON.stringify(updatedUsers));
    console.log('Seeded users collection with additional students');
  }
  
  // Find faculty and student coordinator IDs from existing users
  const users = JSON.parse(localStorage.getItem(`${DB_PREFIX}users`) || '[]');
  const facultyId = users.find(u => u.role === 'faculty')?.id || '1002';
  const coordinatorId = users.find(u => u.role === 'studentCoordinator')?.id || '1003';
  
  // Seed venues
  const venues = [
    {
      id: 'v1',
      name: 'Main Auditorium',
      capacity: 500,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    {
      id: 'v2',
      name: 'Conference Room A',
      capacity: 100,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    {
      id: 'v3',
      name: 'Lecture Hall 101',
      capacity: 150,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    {
      id: 'v4',
      name: 'Outdoor Amphitheater',
      capacity: 300,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }
  ];
  
  localStorage.setItem(`${DB_PREFIX}venues`, JSON.stringify(venues));
  console.log('Seeded venues collection');
  
  // Seed clubs
  const clubs = [
    {
      id: 'c1',
      name: 'Tech Innovators',
      description: 'A club focused on technology innovation and entrepreneurship.',
      facultyCoordinatorId: facultyId,
      studentCoordinatorId: coordinatorId,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    {
      id: 'c2',
      name: 'Coding Ninjas',
      description: 'A club for coding enthusiasts to learn and collaborate on projects.',
      facultyCoordinatorId: facultyId,
      studentCoordinatorId: coordinatorId,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    {
      id: 'c3',
      name: 'Arts & Culture Society',
      description: 'Celebrate and promote various art forms and cultural diversity.',
      facultyCoordinatorId: facultyId,
      studentCoordinatorId: coordinatorId,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }
  ];
  
  localStorage.setItem(`${DB_PREFIX}clubs`, JSON.stringify(clubs));
  console.log('Seeded clubs collection');
  
  // Seed club members
  const studentIds = users.filter(u => u.role === 'student').map(u => u.id);
  
  const clubMembers = [
    {
      id: 'cm1',
      clubId: 'c1',
      studentId: studentIds[0] || '2001',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    {
      id: 'cm2',
      clubId: 'c1',
      studentId: studentIds[1] || '2002',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    {
      id: 'cm3',
      clubId: 'c2',
      studentId: studentIds[0] || '2001',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    {
      id: 'cm4',
      clubId: 'c3',
      studentId: studentIds[2] || '2003',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }
  ];
  
  localStorage.setItem(`${DB_PREFIX}club_members`, JSON.stringify(clubMembers));
  console.log('Seeded club_members collection');
  
  // Seed events
  const now = new Date();
  const tomorrow = new Date(now);
  tomorrow.setDate(now.getDate() + 1);
  
  const nextWeek = new Date(now);
  nextWeek.setDate(now.getDate() + 7);
  
  const events = [
    {
      id: 'e1',
      clubId: 'c1',
      title: 'Tech Talk: Future of AI',
      desc: 'A discussion about the future of artificial intelligence and its impact on society.',
      date: tomorrow.toISOString().split('T')[0],
      venueId: 'v1',
      time: '14:00-16:00',
      requiresApproval: false,
      approved: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    {
      id: 'e2',
      clubId: 'c2',
      title: 'Hackathon 2023',
      desc: 'A 24-hour coding competition to build innovative solutions to real-world problems.',
      date: nextWeek.toISOString().split('T')[0],
      venueId: 'v2',
      time: '09:00-17:00',
      requiresApproval: true,
      approved: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    {
      id: 'e3',
      clubId: 'c3',
      title: 'Cultural Night',
      desc: 'A celebration of diverse cultures with performances, food, and activities.',
      date: nextWeek.toISOString().split('T')[0],
      venueId: 'v4',
      time: '18:00-22:00',
      requiresApproval: true,
      approved: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }
  ];
  
  localStorage.setItem(`${DB_PREFIX}events`, JSON.stringify(events));
  console.log('Seeded events collection');
  
  // Seed event registrations
  const eventRegistrations = [
    {
      id: 'er1',
      eventId: 'e1',
      studentId: studentIds[0] || '2001',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    {
      id: 'er2',
      eventId: 'e1',
      studentId: studentIds[1] || '2002',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    {
      id: 'er3',
      eventId: 'e2',
      studentId: studentIds[0] || '2001',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    {
      id: 'er4',
      eventId: 'e2',
      studentId: studentIds[1] || '2002',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    {
      id: 'er5',
      eventId: 'e3',
      studentId: studentIds[2] || '2003',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }
  ];
  
  localStorage.setItem(`${DB_PREFIX}event_registrations`, JSON.stringify(eventRegistrations));
  console.log('Seeded event_registrations collection');
  
  // Seed club requests
  const clubRequests = [
    {
      id: 'cr1',
      clubId: 'c1',
      studentId: studentIds[2] || '2003',
      status: 'pending',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    {
      id: 'cr2',
      clubId: 'c2',
      studentId: studentIds[2] || '2003',
      status: 'approved',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }
  ];
  
  localStorage.setItem(`${DB_PREFIX}club_requests`, JSON.stringify(clubRequests));
  console.log('Seeded club_requests collection');
  
  // Seed attendance records (for past events)
  const pastDate = new Date(now);
  pastDate.setDate(now.getDate() - 3);
  
  // First, add a past event
  const pastEvents = [
    {
      id: 'e4',
      clubId: 'c1',
      title: 'Past Workshop: Web Development',
      desc: 'A hands-on workshop on modern web development techniques.',
      date: pastDate.toISOString().split('T')[0],
      venueId: 'v3',
      time: '10:00-15:00',
      requiresApproval: false,
      approved: true,
      createdAt: new Date(pastDate).toISOString(),
      updatedAt: new Date(pastDate).toISOString()
    }
  ];
  
  const allEvents = [...events, ...pastEvents];
  localStorage.setItem(`${DB_PREFIX}events`, JSON.stringify(allEvents));
  
  // Add registrations for past event
  const pastEventRegistrations = [
    {
      id: 'er6',
      eventId: 'e4',
      studentId: studentIds[0] || '2001',
      createdAt: new Date(pastDate).toISOString(),
      updatedAt: new Date(pastDate).toISOString()
    },
    {
      id: 'er7',
      eventId: 'e4',
      studentId: studentIds[1] || '2002',
      createdAt: new Date(pastDate).toISOString(),
      updatedAt: new Date(pastDate).toISOString()
    }
  ];
  
  const allEventRegistrations = [...eventRegistrations, ...pastEventRegistrations];
  localStorage.setItem(`${DB_PREFIX}event_registrations`, JSON.stringify(allEventRegistrations));
  
  // Seed attendance records
  const attendanceRecords = [
    {
      id: 'ar1',
      eventId: 'e4',
      studentId: studentIds[0] || '2001',
      FN: true,
      AN: true,
      timestamps: {
        checkIn: new Date(pastDate).setHours(10, 5),
        checkOut: new Date(pastDate).setHours(15, 0)
      },
      notes: 'Active participant',
      createdAt: new Date(pastDate).toISOString(),
      updatedAt: new Date(pastDate).toISOString()
    },
    {
      id: 'ar2',
      eventId: 'e4',
      studentId: studentIds[1] || '2002',
      FN: true,
      AN: false,
      timestamps: {
        checkIn: new Date(pastDate).setHours(10, 15),
        checkOut: new Date(pastDate).setHours(12, 0)
      },
      notes: 'Left early',
      createdAt: new Date(pastDate).toISOString(),
      updatedAt: new Date(pastDate).toISOString()
    }
  ];
  
  localStorage.setItem(`${DB_PREFIX}attendance_records`, JSON.stringify(attendanceRecords));
  console.log('Seeded attendance_records collection');
  
  // Seed certificates
  const certificates = [
    {
      id: 'cert1',
      eventId: 'e4',
      studentId: studentIds[0] || '2001',
      url: 'https://example.com/certificates/workshop_web_dev_001.pdf',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }
  ];
  
  localStorage.setItem(`${DB_PREFIX}certificates`, JSON.stringify(certificates));
  console.log('Seeded certificates collection');
  
  // Mark database as seeded
  localStorage.setItem(`${DB_PREFIX}db_seeded`, 'true');
  console.log('Database seeded successfully');
};

/**
 * Return the database schema information
 */
export const getDataModelSchema = () => {
  return collections;
};

/**
 * Generate an ERD (Entity Relationship Diagram) representation
 * This is a simple text representation of the relationships
 */
export const getEntityRelationships = () => {
  return {
    users: {
      hasMany: ['clubs.facultyCoordinatorId', 'clubs.studentCoordinatorId', 'club_requests.studentId', 'club_members.studentId', 'event_registrations.studentId', 'attendance_records.studentId', 'certificates.studentId']
    },
    clubs: {
      belongsTo: ['users.id (as facultyCoordinatorId)', 'users.id (as studentCoordinatorId)'],
      hasMany: ['club_requests.clubId', 'club_members.clubId', 'events.clubId']
    },
    club_requests: {
      belongsTo: ['users.id (as studentId)', 'clubs.id (as clubId)']
    },
    club_members: {
      belongsTo: ['users.id (as studentId)', 'clubs.id (as clubId)']
    },
    events: {
      belongsTo: ['clubs.id (as clubId)', 'venues.id (as venueId)'],
      hasMany: ['event_registrations.eventId', 'attendance_records.eventId', 'certificates.eventId']
    },
    venues: {
      hasMany: ['events.venueId']
    },
    event_registrations: {
      belongsTo: ['events.id (as eventId)', 'users.id (as studentId)']
    },
    attendance_records: {
      belongsTo: ['events.id (as eventId)', 'users.id (as studentId)']
    },
    certificates: {
      belongsTo: ['events.id (as eventId)', 'users.id (as studentId)']
    }
  };
};

// Export utilities to help work with the data model
export const getCollectionName = (collectionKey) => {
  return collections[collectionKey]?.name || collectionKey;
};

export const getFullKey = (collectionKey) => {
  return `${DB_PREFIX}${getCollectionName(collectionKey)}`;
};
