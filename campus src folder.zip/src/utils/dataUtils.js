import { getFullKey } from './dataModel';

/**
 * Utility functions for working with the data model
 * These functions provide a layer on top of localStorage to work with our data schema
 */

/**
 * Retrieve all records from a collection
 * @param {string} collectionKey - The collection key (e.g., 'users', 'clubs')
 * @returns {Array} Array of records
 */
export const getAll = (collectionKey) => {
  const key = getFullKey(collectionKey);
  const data = localStorage.getItem(key);
  return data ? JSON.parse(data) : [];
};

/**
 * Retrieve a single record by ID
 * @param {string} collectionKey - The collection key
 * @param {string} id - The record ID
 * @returns {Object|null} The record or null if not found
 */
export const getById = (collectionKey, id) => {
  const records = getAll(collectionKey);
  return records.find(record => record.id === id) || null;
};

/**
 * Create a new record in a collection
 * @param {string} collectionKey - The collection key
 * @param {Object} data - The record data
 * @returns {Object} The created record
 */
export const create = (collectionKey, data) => {
  const records = getAll(collectionKey);
  
  // Generate a new ID
  const newId = Date.now().toString() + Math.floor(Math.random() * 1000);
  
  // Create new record with timestamps
  const newRecord = {
    id: newId,
    ...data,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  
  // Add to collection and save
  records.push(newRecord);
  localStorage.setItem(getFullKey(collectionKey), JSON.stringify(records));
  
  return newRecord;
};

/**
 * Update a record by ID
 * @param {string} collectionKey - The collection key
 * @param {string} id - The record ID
 * @param {Object} data - The updated data
 * @returns {Object|null} The updated record or null if not found
 */
export const update = (collectionKey, id, data) => {
  const records = getAll(collectionKey);
  const index = records.findIndex(record => record.id === id);
  
  if (index === -1) {
    return null;
  }
  
  // Update the record
  const updatedRecord = {
    ...records[index],
    ...data,
    updatedAt: new Date().toISOString()
  };
  
  records[index] = updatedRecord;
  localStorage.setItem(getFullKey(collectionKey), JSON.stringify(records));
  
  return updatedRecord;
};

/**
 * Delete a record by ID
 * @param {string} collectionKey - The collection key
 * @param {string} id - The record ID
 * @returns {boolean} Success status
 */
export const remove = (collectionKey, id) => {
  const records = getAll(collectionKey);
  const filteredRecords = records.filter(record => record.id !== id);
  
  if (filteredRecords.length === records.length) {
    return false;
  }
  
  localStorage.setItem(getFullKey(collectionKey), JSON.stringify(filteredRecords));
  return true;
};

/**
 * Query records with a filter function
 * @param {string} collectionKey - The collection key
 * @param {Function} filterFn - Filter function
 * @returns {Array} Filtered records
 */
export const query = (collectionKey, filterFn) => {
  const records = getAll(collectionKey);
  return filterFn ? records.filter(filterFn) : records;
};

/**
 * Get related records (one-to-many relationship)
 * @param {string} collectionKey - The collection key for related records
 * @param {string} foreignKey - The foreign key field name
 * @param {string} id - The ID to match
 * @returns {Array} Related records
 */
export const getRelated = (collectionKey, foreignKey, id) => {
  const records = getAll(collectionKey);
  return records.filter(record => record[foreignKey] === id);
};

/**
 * Get a related record (many-to-one relationship)
 * @param {string} collectionKey - The collection key for related record
 * @param {string} id - The ID to find
 * @returns {Object|null} Related record
 */
export const getRelatedRecord = (collectionKey, id) => {
  if (!id) return null;
  return getById(collectionKey, id);
};
