/**
 * LocalDB utility to simulate database tables using localStorage
 * with CRUD operations.
 */

// Prefix for all localStorage keys to avoid conflicts
const DB_PREFIX = 'myapp_';

/**
 * Create a new item in the specified store
 * @param {string} store - The name of the store/table
 * @param {object} data - The data to store
 * @returns {object} The created item with an ID
 */
export const createItem = (store, data) => {
  // Get existing items
  const items = readItems(store);
  
  // Generate a new ID (current timestamp + random suffix)
  const newId = Date.now().toString() + Math.floor(Math.random() * 1000);
  
  // Create new item with ID
  const newItem = {
    id: newId,
    ...data,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  
  // Add to items array and save
  items.push(newItem);
  localStorage.setItem(`${DB_PREFIX}${store}`, JSON.stringify(items));
  
  return newItem;
};

/**
 * Read all items from the specified store
 * @param {string} store - The name of the store/table
 * @returns {Array} Array of items
 */
export const readItems = (store) => {
  const data = localStorage.getItem(`${DB_PREFIX}${store}`);
  return data ? JSON.parse(data) : [];
};

/**
 * Read a specific item by ID
 * @param {string} store - The name of the store/table
 * @param {string} id - The ID of the item to read
 * @returns {object|null} The found item or null
 */
export const readItemById = (store, id) => {
  const items = readItems(store);
  return items.find(item => item.id === id) || null;
};

/**
 * Update an item by ID
 * @param {string} store - The name of the store/table
 * @param {string} id - The ID of the item to update
 * @param {object} newData - The new data to apply
 * @returns {object|null} The updated item or null if not found
 */
export const updateItem = (store, id, newData) => {
  const items = readItems(store);
  const index = items.findIndex(item => item.id === id);
  
  if (index === -1) {
    return null;
  }
  
  // Update the item
  const updatedItem = {
    ...items[index],
    ...newData,
    updatedAt: new Date().toISOString()
  };
  
  items[index] = updatedItem;
  localStorage.setItem(`${DB_PREFIX}${store}`, JSON.stringify(items));
  
  return updatedItem;
};

/**
 * Delete an item by ID
 * @param {string} store - The name of the store/table
 * @param {string} id - The ID of the item to delete
 * @returns {boolean} Success status
 */
export const deleteItem = (store, id) => {
  const items = readItems(store);
  const filteredItems = items.filter(item => item.id !== id);
  
  // If nothing was removed, return false
  if (filteredItems.length === items.length) {
    return false;
  }
  
  localStorage.setItem(`${DB_PREFIX}${store}`, JSON.stringify(filteredItems));
  return true;
};
