// Initialize the database with some test users if it doesn't exist
export const initializeDatabase = () => {
  const DB_PREFIX = 'myapp_';
  const usersKey = `${DB_PREFIX}users`;
  
  // Only initialize if the users store doesn't exist yet
  if (!localStorage.getItem(usersKey)) {
    const initialUsers = [
      {
        id: '1001',
        name: 'Admin User',
        email: 'admin@example.com',
        password: 'admin123', // In a real app, this would be hashed
        role: 'admin',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: '1002',
        name: 'Faculty User',
        email: 'faculty@example.com',
        password: 'faculty123',
        role: 'faculty',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: '1003',
        name: 'Student Coordinator',
        email: 'coordinator@example.com',
        password: 'coordinator123',
        role: 'studentCoordinator',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: '1004',
        name: 'Student User',
        email: 'student@example.com',
        password: 'student123',
        role: 'student',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }
    ];
    
    localStorage.setItem(usersKey, JSON.stringify(initialUsers));
    console.log('Database initialized with test users');
  }
};
