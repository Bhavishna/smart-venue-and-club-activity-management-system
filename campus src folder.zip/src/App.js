import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, Navigate, Outlet } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { initializeDatabase } from './utils/initialData';
import { initializeDataModel, seedDatabase } from './utils/dataModel';

// Pages
import Login from './pages/Login';
import Signup from './pages/Signup';
import Dashboard from './pages/Dashboard';
import Unauthorized from './pages/Unauthorized';
import TestLocalDB from './pages/TestLocalDB';

// Admin Components
import AdminLayout from './components/admin/AdminLayout';
import AdminDashboardPage from './pages/admin/Dashboard';
import UserManagement from './pages/admin/UserManagement';
import ClubManagement from './pages/admin/ClubManagement';
import VenueManagement from './pages/admin/VenueManagement';
import Reports from './pages/admin/Reports';

// Coordinator Components
import CoordinatorLayout from './components/coordinator/CoordinatorLayout';
import CoordinatorDashboard from './pages/coordinator/Dashboard';
import CreateEvent from './pages/coordinator/CreateEvent';
import EventsList from './pages/coordinator/EventsList';
import EventDetails from './pages/coordinator/EventDetails';
import AttendanceManagement from './pages/coordinator/AttendanceManagement';
import CertificateGeneration from './pages/coordinator/CertificateGeneration';
import RegistrationsManagement from './pages/coordinator/RegistrationsManagement';

// Student Components
import StudentLayout from './components/student/StudentLayout';
import StudentDashboardPage from './pages/student/Dashboard';
import ClubsList from './pages/student/ClubsList';
import ClubDetail from './pages/student/ClubDetail';
import Memberships from './pages/student/Memberships';
import StudentEventsList from './pages/student/EventsList';
import StudentEventDetail from './pages/student/EventDetail';
import MyEvents from './pages/student/MyEvents';
import Certificates from './pages/student/Certificates';
import Profile from './pages/student/Profile';
import CertificateVerify from './pages/CertificateVerify';

// Protected Routes
import { 
  AdminRoute, 
  FacultyRoute, 
  StudentCoordinatorRoute, 
  StudentRoute 
} from './components/ProtectedRoutes';

// Dashboard components for direct access (legacy)
import OldAdminDashboard from './pages/dashboards/AdminDashboard';
import FacultyDashboard from './pages/dashboards/FacultyDashboard';
import StudentCoordinatorDashboard from './pages/dashboards/StudentCoordinatorDashboard';
import StudentDashboard from './pages/dashboards/StudentDashboard';

// Home component for the landing page
const Home = () => (
  <div style={{ maxWidth: '800px', margin: '40px auto', padding: '20px', textAlign: 'center' }}>
    <h1>Education Management System</h1>
    <p style={{ fontSize: '18px', marginBottom: '30px' }}>
      Welcome to our platform for managing educational activities.
    </p>
    
    <div style={{ 
      display: 'flex', 
      justifyContent: 'center', 
      gap: '20px',
      marginBottom: '40px',
      flexWrap: 'wrap'
    }}>
      <Link 
        to="/login" 
        style={{ 
          padding: '10px 20px', 
          backgroundColor: '#3498db', 
          color: 'white', 
          textDecoration: 'none', 
          borderRadius: '5px',
          fontSize: '18px'
        }}
      >
        Login
      </Link>
      <Link 
        to="/signup" 
        style={{ 
          padding: '10px 20px', 
          backgroundColor: '#2ecc71', 
          color: 'white', 
          textDecoration: 'none', 
          borderRadius: '5px',
          fontSize: '18px'
        }}
      >
        Sign Up
      </Link>
    </div>
    
    <div style={{ marginTop: '30px', padding: '20px', backgroundColor: '#f8f9fa', borderRadius: '5px' }}>
      <h3>Test Accounts</h3>
      <ul style={{ listStyle: 'none', padding: 0 }}>
        <li style={{ margin: '10px 0' }}>Admin: admin@example.com / admin123</li>
        <li style={{ margin: '10px 0' }}>Faculty: faculty@example.com / faculty123</li>
        <li style={{ margin: '10px 0' }}>Coordinator: coordinator@example.com / coordinator123</li>
        <li style={{ margin: '10px 0' }}>Student: student@example.com / student123</li>
      </ul>
    </div>
    
    <div style={{ marginTop: '30px', padding: '20px', backgroundColor: '#e8f5e9', borderRadius: '5px' }}>
      <h3>Role-Based Features</h3>
      <div style={{ display: 'flex', justifyContent: 'center', gap: '20px', marginTop: '15px', flexWrap: 'wrap' }}>
        <Link 
          to="/admin/dashboard" 
          style={{ 
            padding: '8px 15px', 
            backgroundColor: '#e74c3c', 
            color: 'white', 
            textDecoration: 'none', 
            borderRadius: '4px'
          }}
        >
          Admin Panel
        </Link>
        <Link 
          to="/faculty" 
          style={{ 
            padding: '8px 15px', 
            backgroundColor: '#3498db', 
            color: 'white', 
            textDecoration: 'none', 
            borderRadius: '4px'
          }}
        >
          Faculty Portal
        </Link>
        <Link 
          to="/coordinator/dashboard" 
          style={{ 
            padding: '8px 15px', 
            backgroundColor: '#9b59b6', 
            color: 'white', 
            textDecoration: 'none', 
            borderRadius: '4px'
          }}
        >
          Coordinator Portal
        </Link>
        <Link 
          to="/student/dashboard" 
          style={{ 
            padding: '8px 15px', 
            backgroundColor: '#f39c12', 
            color: 'white', 
            textDecoration: 'none', 
            borderRadius: '4px'
          }}
        >
          Student Portal
        </Link>
      </div>
    </div>
    
    <div style={{ marginTop: '30px', textAlign: 'center' }}>
      <Link 
        to="/certificate-verify" 
        style={{ color: '#9b59b6', textDecoration: 'none' }}
      >
        Verify a Certificate
      </Link>
    </div>
  </div>
);

function App() {
  // Initialize the database with test users and data model on app load
  useEffect(() => {
    initializeDatabase();
    initializeDataModel(); // Initialize the data model
    seedDatabase(); // Seed the database with sample data
  }, []);

  return (
    <AuthProvider>
      <Router>
        <Routes>
          {/* Public routes */}
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/unauthorized" element={<Unauthorized />} />
          <Route path="/test-db" element={<TestLocalDB />} />
          <Route path="/certificate-verify" element={<CertificateVerify />} />

          {/* Main dashboard router */}
          <Route path="/dashboard" element={<Dashboard />} />

          {/* Admin Panel Routes */}
          <Route 
            path="/admin" 
            element={
              <AdminRoute>
                <AdminLayout />
              </AdminRoute>
            } 
          >
            <Route path="dashboard" element={<AdminDashboardPage />} />
            <Route path="users" element={<UserManagement />} />
            <Route path="clubs" element={<ClubManagement />} />
            <Route path="venues" element={<VenueManagement />} />
            <Route path="reports" element={<Reports />} />
            <Route index element={<Navigate to="/admin/dashboard" replace />} />
          </Route>
          
          {/* Student Coordinator Routes */}
          <Route 
            path="/coordinator" 
            element={
              <StudentCoordinatorRoute>
                <CoordinatorLayout />
              </StudentCoordinatorRoute>
            } 
          >
            <Route path="dashboard" element={<CoordinatorDashboard />} />
            <Route path="events" element={<EventsList />} />
            <Route path="events/create" element={<CreateEvent />} />
            <Route path="events/:eventId" element={<EventDetails />} />
            <Route path="attendance/:eventId" element={<AttendanceManagement />} />
            <Route path="certificates/:eventId" element={<CertificateGeneration />} />
            <Route path="registrations" element={<RegistrationsManagement />} />
            <Route index element={<Navigate to="/coordinator/dashboard" replace />} />
          </Route>
          
          {/* Student Routes */}
          <Route 
            path="/student" 
            element={
              <StudentRoute>
                <StudentLayout />
              </StudentRoute>
            } 
          >
            <Route path="dashboard" element={<StudentDashboardPage />} />
            <Route path="clubs" element={<ClubsList />} />
            <Route path="clubs/:clubId" element={<ClubDetail />} />
            <Route path="memberships" element={<Memberships />} />
            <Route path="events" element={<StudentEventsList />} />
            <Route path="events/:eventId" element={<StudentEventDetail />} />
            <Route path="my-events" element={<MyEvents />} />
            <Route path="certificates" element={<Certificates />} />
            <Route path="profile" element={<Profile />} />
            <Route index element={<Navigate to="/student/dashboard" replace />} />
          </Route>
          
          {/* Legacy role-specific routes with protection */}
          <Route 
            path="/admin-old" 
            element={
              <AdminRoute>
                <OldAdminDashboard />
              </AdminRoute>
            } 
          />
          
          <Route 
            path="/faculty/*" 
            element={
              <FacultyRoute>
                <FacultyDashboard />
              </FacultyRoute>
            } 
          />
          
          <Route 
            path="/coordinator-old" 
            element={
              <StudentCoordinatorRoute>
                <StudentCoordinatorDashboard />
              </StudentCoordinatorRoute>
            } 
          />
          
          <Route 
            path="/student-old" 
            element={
              <StudentRoute>
                <StudentDashboard />
              </StudentRoute>
            } 
          />

          {/* Fallback route */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;
