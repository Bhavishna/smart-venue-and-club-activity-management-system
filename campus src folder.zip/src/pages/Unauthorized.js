import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Unauthorized = () => {
  const { currentUser } = useAuth();
  const navigate = useNavigate();

  return (
    <div style={{ 
      maxWidth: '600px', 
      margin: '40px auto',
      padding: '30px',
      textAlign: 'center',
      boxShadow: '0 0 10px rgba(0,0,0,0.1)'
    }}>
      <h1 style={{ color: '#d32f2f', marginBottom: '20px' }}>Access Denied</h1>
      
      <p style={{ fontSize: '18px', marginBottom: '30px' }}>
        You don't have permission to access this page.
      </p>
      
      <div style={{ marginBottom: '30px' }}>
        <p>
          Your current role is: <strong>{currentUser?.role || 'None'}</strong>
        </p>
      </div>
      
      <div style={{ display: 'flex', justifyContent: 'center', gap: '15px' }}>
        <button 
          onClick={() => navigate(-1)} 
          style={{ 
            padding: '10px 15px', 
            backgroundColor: '#757575', 
            color: 'white', 
            border: 'none', 
            borderRadius: '4px', 
            cursor: 'pointer' 
          }}
        >
          Go Back
        </button>
        
        <Link 
          to="/dashboard" 
          style={{ 
            padding: '10px 15px', 
            backgroundColor: '#2196f3', 
            color: 'white', 
            textDecoration: 'none', 
            borderRadius: '4px' 
          }}
        >
          Go to Dashboard
        </Link>
      </div>
    </div>
  );
};

export default Unauthorized;
