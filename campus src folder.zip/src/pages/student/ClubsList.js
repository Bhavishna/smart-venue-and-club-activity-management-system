import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import useCollectionData from '../../hooks/useCollection';
import { useAuth } from '../../context/AuthContext';

const ClubsList = () => {
  const { items: clubs } = useCollectionData('clubs');
  const { items: clubMembers } = useCollectionData('club_members');
  const { items: clubRequests } = useCollectionData('club_requests');
  const { items: users } = useCollectionData('users');
  
  const { currentUser } = useAuth();
  
  const [filteredClubs, setFilteredClubs] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [membershipStatus, setMembershipStatus] = useState([]);
  
  // Extract all unique categories from clubs
  const categories = [...new Set(clubs.map(club => club.category || 'Uncategorized'))];
  
  // Filter clubs based on search and category
  useEffect(() => {
    if (!clubs.length) return;
    
    let result = [...clubs];
    
    // Apply search filter
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      result = result.filter(club => 
        club.name.toLowerCase().includes(term) || 
        (club.description && club.description.toLowerCase().includes(term))
      );
    }
    
    // Apply category filter
    if (categoryFilter !== 'all') {
      result = result.filter(club => (club.category || 'Uncategorized') === categoryFilter);
    }
    
    // Enhance club data
    result = result.map(club => {
      const facultyCoordinator = users.find(user => user.id === club.facultyCoordinatorId);
      const studentCoordinator = users.find(user => user.id === club.studentCoordinatorId);
      const memberCount = clubMembers.filter(member => member.clubId === club.id).length;
      
      return {
        ...club,
        facultyName: facultyCoordinator ? facultyCoordinator.name : 'Unknown',
        coordinatorName: studentCoordinator ? studentCoordinator.name : 'Unknown',
        memberCount
      };
    });
    
    // Sort by name
    result.sort((a, b) => a.name.localeCompare(b.name));
    
    setFilteredClubs(result);
  }, [clubs, users, clubMembers, searchTerm, categoryFilter]);
  
  // Determine membership status for each club
  useEffect(() => {
    if (!currentUser || !clubs.length) return;
    
    const statuses = {};
    
    // Check existing memberships
    clubMembers.forEach(membership => {
      if (membership.studentId === currentUser.id) {
        statuses[membership.clubId] = { status: 'member', id: membership.id };
      }
    });
    
    // Check pending requests
    clubRequests.forEach(request => {
      if (request.studentId === currentUser.id) {
        statuses[request.clubId] = { 
          status: request.status, // 'pending', 'approved', or 'rejected'
          id: request.id 
        };
      }
    });
    
    setMembershipStatus(statuses);
  }, [currentUser, clubs, clubMembers, clubRequests]);
  
  return (
    <div>
      <h1>Explore Clubs</h1>
      
      {/* Search and filter controls */}
      <div style={{ 
        backgroundColor: 'white', 
        padding: '20px', 
        borderRadius: '8px',
        marginBottom: '20px',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
        display: 'flex',
        gap: '15px',
        flexWrap: 'wrap'
      }}>
        <div style={{ flex: '1 1 300px' }}>
          <input
            type="text"
            placeholder="Search clubs..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            style={{
              width: '100%',
              padding: '10px 15px',
              borderRadius: '4px',
              border: '1px solid #ddd'
            }}
          />
        </div>
        
        <div>
          <select
            value={categoryFilter}
            onChange={e => setCategoryFilter(e.target.value)}
            style={{
              padding: '10px 15px',
              borderRadius: '4px',
              border: '1px solid #ddd',
              backgroundColor: 'white'
            }}
          >
            <option value="all">All Categories</option>
            {categories.map((category, index) => (
              <option key={index} value={category}>{category}</option>
            ))}
          </select>
        </div>
      </div>
      
      {/* Clubs Grid */}
      {filteredClubs.length === 0 ? (
        <div style={{ 
          backgroundColor: 'white', 
          padding: '30px', 
          borderRadius: '8px',
          textAlign: 'center',
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
        }}>
          <p style={{ margin: '0 0 15px 0', fontSize: '18px' }}>No clubs found matching your criteria.</p>
          <button
            onClick={() => { setSearchTerm(''); setCategoryFilter('all'); }}
            style={{
              padding: '8px 15px',
              backgroundColor: '#f39c12',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer'
            }}
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div style={{ 
          display: 'grid', 
          gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', 
          gap: '20px'
        }}>
          {filteredClubs.map(club => (
            <ClubCard 
              key={club.id} 
              club={club} 
              membershipStatus={membershipStatus[club.id]} 
              currentUser={currentUser}
            />
          ))}
        </div>
      )}
    </div>
  );
};

// Club card component
const ClubCard = ({ club, membershipStatus, currentUser }) => {
  const { addItem: addRequest } = useCollectionData('club_requests');
  const [requestSent, setRequestSent] = useState(false);
  const [error, setError] = useState(null);
  
  const handleJoinRequest = async () => {
    try {
      // Create a join request
      await addRequest({
        clubId: club.id,
        studentId: currentUser.id,
        status: 'pending',
        message: '',
        requestedAt: new Date().toISOString()
      });
      
      setRequestSent(true);
    } catch (err) {
      setError('Failed to send join request');
    }
  };
  
  let membershipButton;
  
  if (requestSent) {
    membershipButton = (
      <div style={{
        padding: '8px 15px',
        backgroundColor: '#27ae60',
        color: 'white',
        textAlign: 'center',
        borderRadius: '4px',
        fontSize: '14px'
      }}>
        Request Sent
      </div>
    );
  } else if (membershipStatus) {
    // Already a member or has a request
    if (membershipStatus.status === 'member') {
      membershipButton = (
        <div style={{
          padding: '8px 15px',
          backgroundColor: '#3498db',
          color: 'white',
          textAlign: 'center',
          borderRadius: '4px',
          fontSize: '14px'
        }}>
          Member
        </div>
      );
    } else if (membershipStatus.status === 'pending') {
      membershipButton = (
        <div style={{
          padding: '8px 15px',
          backgroundColor: '#f39c12',
          color: 'white',
          textAlign: 'center',
          borderRadius: '4px',
          fontSize: '14px'
        }}>
          Request Pending
        </div>
      );
    } else if (membershipStatus.status === 'rejected') {
      membershipButton = (
        <div style={{
          padding: '8px 15px',
          backgroundColor: '#e74c3c',
          color: 'white',
          textAlign: 'center',
          borderRadius: '4px',
          fontSize: '14px'
        }}>
          Request Denied
        </div>
      );
    }
  } else {
    // Not a member, show join button
    membershipButton = (
      <button
        onClick={handleJoinRequest}
        style={{
          width: '100%',
          padding: '8px 15px',
          backgroundColor: '#f39c12',
          color: 'white',
          border: 'none',
          borderRadius: '4px',
          cursor: 'pointer',
          fontSize: '14px'
        }}
      >
        Request to Join
      </button>
    );
  }
  
  return (
    <div style={{ 
      backgroundColor: 'white',
      borderRadius: '8px',
      overflow: 'hidden',
      boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
      display: 'flex',
      flexDirection: 'column'
    }}>
      <div style={{ padding: '20px' }}>
        <h2 style={{ margin: '0 0 10px 0', fontSize: '20px' }}>{club.name}</h2>
        
        {club.category && (
          <div style={{ 
            display: 'inline-block',
            backgroundColor: '#f8f9fa',
            padding: '4px 8px',
            borderRadius: '4px',
            fontSize: '12px',
            marginBottom: '15px'
          }}>
            {club.category}
          </div>
        )}
        
        <p style={{ 
          margin: '0 0 15px 0', 
          color: '#666',
          height: '80px',
          overflow: 'hidden',
          textOverflow: 'ellipsis'
        }}>
          {club.description}
        </p>
        
        <div style={{ 
          borderTop: '1px solid #eee', 
          paddingTop: '15px',
          marginBottom: '15px'
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
            <span style={{ color: '#666', fontSize: '14px' }}>Faculty:</span>
            <span style={{ fontSize: '14px' }}>{club.facultyName}</span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
            <span style={{ color: '#666', fontSize: '14px' }}>Coordinator:</span>
            <span style={{ fontSize: '14px' }}>{club.coordinatorName}</span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <span style={{ color: '#666', fontSize: '14px' }}>Members:</span>
            <span style={{ fontSize: '14px' }}>{club.memberCount}</span>
          </div>
        </div>
      </div>
      
      <div style={{ 
        marginTop: 'auto',
        padding: '15px 20px',
        borderTop: '1px solid #eee',
        display: 'flex',
        gap: '10px'
      }}>
        <Link to={`/student/clubs/${club.id}`} style={{
          flex: 1,
          padding: '8px 0',
          backgroundColor: '#3498db',
          color: 'white',
          textAlign: 'center',
          textDecoration: 'none',
          borderRadius: '4px',
          fontSize: '14px'
        }}>
          View Details
        </Link>
        
        <div style={{ flex: 1 }}>
          {membershipButton}
        </div>
      </div>
      
      {error && (
        <div style={{ 
          padding: '10px', 
          backgroundColor: '#f8d7da', 
          color: '#721c24',
          fontSize: '12px',
          textAlign: 'center'
        }}>
          {error}
        </div>
      )}
    </div>
  );
};

export default ClubsList;
