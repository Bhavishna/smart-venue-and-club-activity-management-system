import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import useCollectionData from '../../hooks/useCollection';
import { useAuth } from '../../context/AuthContext';
import EventFeedback from '../../components/student/EventFeedback';

const EventDetail = () => {
  const { eventId } = useParams();
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  
  const { items: events } = useCollectionData('events');
  const { items: clubs } = useCollectionData('clubs');
  const { items: venues } = useCollectionData('venues');
  const { items: users } = useCollectionData('users');
  const { 
    items: eventRegistrations, 
    addItem: addRegistration,
    deleteItem: deleteRegistration 
  } = useCollectionData('event_registrations');
  const { items: attendanceRecords } = useCollectionData('attendance_records');
  const { items: clubMembers } = useCollectionData('club_members');
  const { items: feedback } = useCollectionData('feedback');
  
  const [event, setEvent] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isRegistered, setIsRegistered] = useState(false);
  const [registrationId, setRegistrationId] = useState(null);
  const [clubMembershipRequired, setClubMembershipRequired] = useState(false);
  const [isMember, setIsMember] = useState(false);
  const [attendance, setAttendance] = useState(null);
  const [userFeedback, setUserFeedback] = useState(null);
  const [successMessage, setSuccessMessage] = useState('');
  const [cancelDialogOpen, setCancelDialogOpen] = useState(false);
  const [eventCapacity, setEventCapacity] = useState(null);
  const [registrationCount, setRegistrationCount] = useState(0);
  const [feedbackModalOpen, setFeedbackModalOpen] = useState(false);
  
  // Load event details
  useEffect(() => {
    if (!events.length || !clubs.length || !venues.length) return;
    
    const eventData = events.find(e => e.id === eventId);
    
    if (eventData) {
      // Check if event is approved
      if (!eventData.approved) {
        setError("This event is not yet approved and cannot be viewed.");
        setLoading(false);
        return;
      }
      
      const club = clubs.find(c => c.id === eventData.clubId);
      const venue = venues.find(v => v.id === eventData.venueId);
      
      // Get coordinator details
      let facultyCoordinator = null;
      let studentCoordinator = null;
      
      if (club) {
        facultyCoordinator = users.find(u => u.id === club.facultyCoordinatorId);
        studentCoordinator = users.find(u => u.id === club.studentCoordinatorId);
        
        // Check if membership is required to register
        setClubMembershipRequired(club.membershipRequired || false);
        
        // Check if user is a member of the club
        const membership = clubMembers.find(
          m => m.clubId === club.id && m.studentId === currentUser.id
        );
        
        setIsMember(!!membership);
      }
      
      // Determine venue capacity and current registrations
      if (venue) {
        setEventCapacity(venue.capacity || null);
      }
      
      const currentRegistrations = eventRegistrations.filter(r => r.eventId === eventId).length;
      setRegistrationCount(currentRegistrations);
      
      setEvent({
        ...eventData,
        clubName: club ? club.name : 'Unknown Club',
        venueName: venue ? venue.name : 'Unknown Venue',
        venueCapacity: venue ? venue.capacity : null,
        dateFormatted: new Date(eventData.date).toLocaleDateString(),
        facultyName: facultyCoordinator ? facultyCoordinator.name : null,
        facultyEmail: facultyCoordinator ? facultyCoordinator.email : null,
        coordinatorName: studentCoordinator ? studentCoordinator.name : null,
        coordinatorEmail: studentCoordinator ? studentCoordinator.email : null,
      });
    } else {
      setError("Event not found.");
    }
    
    setLoading(false);
  }, [events, clubs, venues, users, eventId, clubMembers, currentUser, eventRegistrations]);
  
  // Check registration status
  useEffect(() => {
    if (!currentUser || !eventRegistrations.length) return;
    
    const registration = eventRegistrations.find(
      reg => reg.eventId === eventId && reg.studentId === currentUser.id
    );
    
    if (registration) {
      setIsRegistered(true);
      setRegistrationId(registration.id);
    } else {
      setIsRegistered(false);
      setRegistrationId(null);
    }
  }, [currentUser, eventRegistrations, eventId]);
  
  // Check attendance if already attended
  useEffect(() => {
    if (!currentUser || !attendanceRecords.length) return;
    
    const attendanceRecord = attendanceRecords.find(
      record => record.eventId === eventId && record.studentId === currentUser.id
    );
    
    if (attendanceRecord) {
      setAttendance({
        FN: attendanceRecord.FN || false,
        AN: attendanceRecord.AN || false,
        notes: attendanceRecord.notes || ''
      });
    }
  }, [currentUser, attendanceRecords, eventId]);
  
  // Check if user has submitted feedback
  useEffect(() => {
    if (!currentUser || !feedback.length) return;
    
    const userFeedback = feedback.find(
      f => f.eventId === eventId && f.studentId === currentUser.id
    );
    
    if (userFeedback) {
      setUserFeedback(userFeedback);
    }
  }, [currentUser, feedback, eventId]);
  
  // Handle registration
  const handleRegister = async () => {
    if (!currentUser) {
      navigate('/login');
      return;
    }
    
    try {
      // Check if club membership is required
      if (clubMembershipRequired && !isMember) {
        setError("You must be a member of this club to register for this event.");
        return;
      }
      
      // Check if venue capacity would be exceeded
      if (eventCapacity !== null && registrationCount >= eventCapacity) {
        setError("Sorry, this event has reached its maximum capacity.");
        return;
      }
      
      // Create registration
      await addRegistration({
        eventId,
        studentId: currentUser.id,
        registeredAt: new Date().toISOString()
      });
      
      setIsRegistered(true);
      setSuccessMessage("You have successfully registered for this event!");
      
      // Increment registration count
      setRegistrationCount(prev => prev + 1);
      
      // Clear success message after 5 seconds
      setTimeout(() => setSuccessMessage(''), 5000);
    } catch (err) {
      setError("Failed to register for this event. Please try again.");
    }
  };
  
  // Handle cancellation
  const handleCancelRegistration = async () => {
    if (!registrationId) return;
    
    try {
      await deleteRegistration(registrationId);
      
      setIsRegistered(false);
      setRegistrationId(null);
      setSuccessMessage("Your registration has been cancelled.");
      
      // Decrement registration count
      setRegistrationCount(prev => prev - 1);
      
      // Close dialog
      setCancelDialogOpen(false);
      
      // Clear success message after 5 seconds
      setTimeout(() => setSuccessMessage(''), 5000);
    } catch (err) {
      setError("Failed to cancel registration. Please try again.");
      setCancelDialogOpen(false);
    }
  };
  
  if (loading) {
    return <div style={{ textAlign: 'center', padding: '50px' }}>Loading...</div>;
  }
  
  if (error) {
    return (
      <div style={{ 
        padding: '20px', 
        backgroundColor: '#f8d7da',
        color: '#721c24',
        borderRadius: '5px',
        marginBottom: '20px'
      }}>
        <p style={{ margin: '0 0 10px 0', fontWeight: 'bold' }}>{error}</p>
        <Link to="/student/events" style={{ color: '#721c24' }}>Back to Events</Link>
      </div>
    );
  }
  
  if (!event) {
    return (
      <div style={{ 
        padding: '20px', 
        backgroundColor: '#f8d7da',
        color: '#721c24',
        borderRadius: '5px',
        marginBottom: '20px'
      }}>
        <p style={{ margin: '0 0 10px 0', fontWeight: 'bold' }}>Event not found.</p>
        <Link to="/student/events" style={{ color: '#721c24' }}>Back to Events</Link>
      </div>
    );
  }
  
  const eventDate = new Date(event.date);
  const isPastEvent = eventDate < new Date();
  const isSameDay = eventDate.toDateString() === new Date().toDateString();
  const isUpcomingEvent = !isPastEvent;
  
  const canRegister = isUpcomingEvent && !isRegistered && 
    (!clubMembershipRequired || (clubMembershipRequired && isMember)) &&
    (eventCapacity === null || registrationCount < eventCapacity);
    
  const canCancel = isUpcomingEvent && isRegistered;
  
  return (
    <div>
      <div style={{ marginBottom: '20px' }}>
        <Link to="/student/events" style={{ color: '#666', textDecoration: 'none' }}>
          ← Back to Events
        </Link>
      </div>
      
      {successMessage && (
        <div style={{ 
          padding: '15px', 
          backgroundColor: '#d4edda', 
          color: '#155724',
          borderRadius: '5px',
          marginBottom: '20px'
        }}>
          {successMessage}
        </div>
      )}
      
      {error && (
        <div style={{ 
          padding: '15px', 
          backgroundColor: '#f8d7da', 
          color: '#721c24',
          borderRadius: '5px',
          marginBottom: '20px'
        }}>
          {error}
        </div>
      )}
      
      <div style={{ 
        backgroundColor: 'white',
        borderRadius: '8px',
        padding: '20px',
        marginBottom: '20px',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
      }}>
        <div style={{ 
          display: 'flex', 
          justifyContent: 'space-between', 
          alignItems: 'flex-start',
          flexWrap: 'wrap',
          gap: '20px',
          marginBottom: '20px'
        }}>
          <div>
            <h1 style={{ margin: '0 0 10px 0' }}>{event.title}</h1>
            <div style={{ 
              display: 'inline-block',
              backgroundColor: isPastEvent ? '#e74c3c' : (isSameDay ? '#f39c12' : '#2ecc71'),
              color: 'white',
              padding: '5px 10px',
              borderRadius: '4px',
              fontSize: '14px',
              fontWeight: 'bold'
            }}>
              {isPastEvent ? 'Past Event' : (isSameDay ? 'Today' : 'Upcoming')}
            </div>
          </div>
          
          <div>
            {isRegistered ? (
              <div>
                <div style={{
                  padding: '10px 20px',
                  backgroundColor: '#d4edda',
                  color: '#155724',
                  borderRadius: '4px',
                  marginBottom: '10px',
                  textAlign: 'center',
                  fontWeight: 'bold'
                }}>
                  You are registered for this event
                </div>
                
                {canCancel && (
                  <button
                    onClick={() => setCancelDialogOpen(true)}
                    style={{
                      padding: '8px 15px',
                      backgroundColor: '#e74c3c',
                      color: 'white',
                      border: 'none',
                      borderRadius: '4px',
                      cursor: 'pointer',
                      width: '100%'
                    }}
                  >
                    Cancel Registration
                  </button>
                )}
              </div>
            ) : (
              <div>
                {canRegister ? (
                  <button
                    onClick={handleRegister}
                    style={{
                      padding: '10px 20px',
                      backgroundColor: '#f39c12',
                      color: 'white',
                      border: 'none',
                      borderRadius: '4px',
                      cursor: 'pointer'
                    }}
                  >
                    Register for Event
                  </button>
                ) : isPastEvent ? (
                  <div style={{
                    padding: '10px 20px',
                    backgroundColor: '#f8d7da',
                    color: '#721c24',
                    borderRadius: '4px',
                    textAlign: 'center'
                  }}>
                    Registration closed (past event)
                  </div>
                ) : (
                  clubMembershipRequired && !isMember ? (
                    <div style={{
                      padding: '10px 20px',
                      backgroundColor: '#f8d7da',
                      color: '#721c24',
                      borderRadius: '4px',
                      textAlign: 'center'
                    }}>
                      Club membership required to register
                    </div>
                  ) : (
                    eventCapacity !== null && registrationCount >= eventCapacity && (
                      <div style={{
                        padding: '10px 20px',
                        backgroundColor: '#f8d7da',
                        color: '#721c24',
                        borderRadius: '4px',
                        textAlign: 'center'
                      }}>
                        Event at full capacity
                      </div>
                    )
                  )
                )}
              </div>
            )}
          </div>
        </div>
        
        <div style={{ display: 'flex', gap: '30px', flexWrap: 'wrap', marginBottom: '20px' }}>
          <div>
            <p style={{ margin: '0 0 5px 0', color: '#666', fontSize: '14px' }}>Date</p>
            <p style={{ margin: '0', fontWeight: 'bold' }}>{event.dateFormatted}</p>
          </div>
          
          <div>
            <p style={{ margin: '0 0 5px 0', color: '#666', fontSize: '14px' }}>Time</p>
            <p style={{ margin: '0', fontWeight: 'bold' }}>{event.time}</p>
          </div>
          
          <div>
            <p style={{ margin: '0 0 5px 0', color: '#666', fontSize: '14px' }}>Venue</p>
            <p style={{ margin: '0', fontWeight: 'bold' }}>{event.venueName}</p>
          </div>
          
          <div>
            <p style={{ margin: '0 0 5px 0', color: '#666', fontSize: '14px' }}>Club</p>
            <p style={{ margin: '0', fontWeight: 'bold' }}>
              <Link to={`/student/clubs/${event.clubId}`} style={{ color: '#f39c12', textDecoration: 'none' }}>
                {event.clubName}
              </Link>
            </p>
          </div>
          
          {eventCapacity !== null && (
            <div>
              <p style={{ margin: '0 0 5px 0', color: '#666', fontSize: '14px' }}>Capacity</p>
              <p style={{ margin: '0', fontWeight: 'bold' }}>
                {registrationCount}/{eventCapacity}
                {' '}
                <span style={{ 
                  fontSize: '12px', 
                  color: registrationCount >= eventCapacity ? '#e74c3c' : '#27ae60',
                  fontWeight: 'normal'
                }}>
                  ({registrationCount >= eventCapacity ? 'Full' : `${eventCapacity - registrationCount} spots left`})
                </span>
              </p>
            </div>
          )}
        </div>
        
        <div style={{ marginBottom: '25px' }}>
          <h3 style={{ margin: '0 0 10px 0' }}>Description</h3>
          <p style={{ margin: '0', lineHeight: '1.6' }}>{event.desc}</p>
        </div>
        
        <div style={{ display: 'flex', gap: '30px', flexWrap: 'wrap' }}>
          {event.facultyName && (
            <div>
              <h3 style={{ margin: '0 0 10px 0' }}>Faculty Coordinator</h3>
              <p style={{ margin: '0 0 5px 0', fontWeight: 'bold' }}>{event.facultyName}</p>
              {event.facultyEmail && <p style={{ margin: '0', color: '#666' }}>{event.facultyEmail}</p>}
            </div>
          )}
          
          {event.coordinatorName && (
            <div>
              <h3 style={{ margin: '0 0 10px 0' }}>Student Coordinator</h3>
              <p style={{ margin: '0 0 5px 0', fontWeight: 'bold' }}>{event.coordinatorName}</p>
              {event.coordinatorEmail && <p style={{ margin: '0', color: '#666' }}>{event.coordinatorEmail}</p>}
            </div>
          )}
        </div>
      </div>
      
      {/* Attendance section - shown only for past events where the user was registered */}
      {isPastEvent && isRegistered && (
        <div style={{ 
          backgroundColor: 'white',
          borderRadius: '8px',
          padding: '20px',
          marginBottom: '20px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
        }}>
          <h2 style={{ marginTop: 0 }}>Your Attendance</h2>
          
          {attendance ? (
            <div>
              <div style={{ display: 'flex', gap: '20px', marginBottom: '15px' }}>
                <div style={{ 
                  flex: 1,
                  padding: '15px',
                  backgroundColor: attendance.FN ? '#d4edda' : '#f8d7da',
                  color: attendance.FN ? '#155724' : '#721c24',
                  borderRadius: '5px',
                  textAlign: 'center'
                }}>
                  <p style={{ margin: '0 0 5px 0', fontWeight: 'bold' }}>Morning Session (FN)</p>
                  <p style={{ margin: '0', fontSize: '18px' }}>{attendance.FN ? 'Present' : 'Absent'}</p>
                </div>
                
                <div style={{ 
                  flex: 1,
                  padding: '15px',
                  backgroundColor: attendance.AN ? '#d4edda' : '#f8d7da',
                  color: attendance.AN ? '#155724' : '#721c24',
                  borderRadius: '5px',
                  textAlign: 'center'
                }}>
                  <p style={{ margin: '0 0 5px 0', fontWeight: 'bold' }}>Afternoon Session (AN)</p>
                  <p style={{ margin: '0', fontSize: '18px' }}>{attendance.AN ? 'Present' : 'Absent'}</p>
                </div>
              </div>
              
              <div style={{ 
                padding: '15px',
                backgroundColor: attendance.FN && attendance.AN ? '#d4edda' : '#f8d7da',
                color: attendance.FN && attendance.AN ? '#155724' : '#721c24',
                borderRadius: '5px',
                textAlign: 'center',
                fontWeight: 'bold'
              }}>
                Certificate Status: {attendance.FN && attendance.AN ? 'Eligible' : 'Not Eligible'}
                {attendance.FN && attendance.AN && (
                  <Link to="/student/certificates" style={{
                    display: 'inline-block',
                    marginLeft: '10px',
                    color: '#155724',
                    textDecoration: 'underline'
                  }}>
                    View Certificates
                  </Link>
                )}
              </div>
              
              {attendance.notes && (
                <div style={{ marginTop: '15px' }}>
                  <h3 style={{ margin: '0 0 10px 0' }}>Attendance Notes</h3>
                  <p style={{ margin: '0', padding: '10px', backgroundColor: '#f8f9fa', borderRadius: '4px' }}>
                    {attendance.notes}
                  </p>
                </div>
              )}
              
              {/* Feedback button for past events */}
              <div style={{ marginTop: '20px', textAlign: 'center' }}>
                <button
                  onClick={() => setFeedbackModalOpen(true)}
                  style={{
                    padding: '10px 20px',
                    backgroundColor: '#f39c12',
                    color: 'white',
                    border: 'none',
                    borderRadius: '4px',
                    cursor: 'pointer'
                  }}
                >
                  {userFeedback ? 'Update Feedback' : 'Provide Feedback'}
                </button>
              </div>
            </div>
          ) : (
            <p style={{ color: '#666' }}>Your attendance has not been recorded for this event.</p>
          )}
        </div>
      )}
      
      {/* User Feedback Display (if they've already given feedback) */}
      {userFeedback && isPastEvent && isRegistered && (
        <div style={{ 
          backgroundColor: 'white',
          borderRadius: '8px',
          padding: '20px',
          marginBottom: '20px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
        }}>
          <h2 style={{ marginTop: 0 }}>Your Feedback</h2>
          
          <div style={{ marginBottom: '15px' }}>
            <div style={{ display: 'flex', marginBottom: '10px' }}>
              <div style={{ color: '#f39c12', fontSize: '24px' }}>
                {[1, 2, 3, 4, 5].map(star => (
                  <span key={star} style={{ color: star <= userFeedback.rating ? '#f39c12' : '#ddd' }}>
                    ★
                  </span>
                ))}
              </div>
              <span style={{ marginLeft: '10px', fontWeight: 'bold' }}>
                {userFeedback.rating}/5
              </span>
            </div>
            
            {userFeedback.comment && (
              <div style={{ 
                backgroundColor: '#f8f9fa', 
                padding: '15px', 
                borderRadius: '5px',
                fontStyle: 'italic' 
              }}>
                "{userFeedback.comment}"
              </div>
            )}
          </div>
          
          <div style={{ textAlign: 'center' }}>
            <button
              onClick={() => setFeedbackModalOpen(true)}
              style={{
                padding: '8px 15px',
                backgroundColor: '#f39c12',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: 'pointer',
                fontSize: '14px'
              }}
            >
              Edit Feedback
            </button>
          </div>
        </div>
      )}
      
      {/* Cancellation Confirmation Dialog */}
      {cancelDialogOpen && (
        <div style={{ 
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000
        }}>
          <div style={{ 
            backgroundColor: 'white',
            borderRadius: '8px',
            padding: '20px',
            maxWidth: '400px',
            width: '90%',
            boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)'
          }}>
            <h2 style={{ margin: '0 0 15px 0' }}>Cancel Registration</h2>
            
            <p>Are you sure you want to cancel your registration for this event?</p>
            
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px', marginTop: '20px' }}>
              <button 
                onClick={() => setCancelDialogOpen(false)}
                style={{
                  padding: '8px 15px',
                  backgroundColor: '#f0f0f0',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
              >
                Keep Registration
              </button>
              <button 
                onClick={handleCancelRegistration}
                style={{
                  padding: '8px 15px',
                  backgroundColor: '#e74c3c',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
              >
                Cancel Registration
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Feedback Modal */}
      {feedbackModalOpen && (
        <div style={{ 
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000
        }}>
          <EventFeedback 
            eventId={eventId}
            onClose={() => setFeedbackModalOpen(false)}
          />
        </div>
      )}
    </div>
  );
};

export default EventDetail;
