import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import useCollectionData from '../../hooks/useCollection';
import { useAuth } from '../../context/AuthContext';

const MyEvents = () => {
  const { currentUser } = useAuth();
  
  const { items: events } = useCollectionData('events');
  const { items: clubs } = useCollectionData('clubs');
  const { items: venues } = useCollectionData('venues');
  const { items: eventRegistrations, deleteItem: deleteRegistration } = useCollectionData('event_registrations');
  const { items: attendanceRecords } = useCollectionData('attendance_records');
  const { items: certificates } = useCollectionData('certificates');
  
  const [registeredEvents, setRegisteredEvents] = useState([]);
  const [activeTab, setActiveTab] = useState('upcoming');
  const [cancelDialogOpen, setCancelDialogOpen] = useState(false);
  const [selectedRegistration, setSelectedRegistration] = useState(null);
  const [successMessage, setSuccessMessage] = useState('');
  const [error, setError] = useState('');
  
  // Get user's registered events
  useEffect(() => {
    if (!currentUser || !events.length || !clubs.length || !venues.length) return;
    
    const userRegistrations = eventRegistrations.filter(reg => reg.studentId === currentUser.id);
    
    const now = new Date();
    now.setHours(0, 0, 0, 0); // Start of today
    
    const registeredEventsList = userRegistrations.map(registration => {
      const event = events.find(e => e.id === registration.eventId);
      if (!event) return null;
      
      const club = clubs.find(c => c.id === event.clubId);
      const venue = venues.find(v => v.id === event.venueId);
      
      const eventDate = new Date(event.date);
      eventDate.setHours(0, 0, 0, 0); // Start of event day
      
      const isPast = eventDate < now;
      
      // Get attendance data
      const attendance = attendanceRecords.find(
        record => record.eventId === event.id && record.studentId === currentUser.id
      );
      
      // Get certificate
      const certificate = certificates.find(
        cert => cert.eventId === event.id && cert.studentId === currentUser.id
      );
      
      return {
        registrationId: registration.id,
        event: {
          id: event.id,
          title: event.title,
          date: event.date,
          dateFormatted: eventDate.toLocaleDateString(),
          time: event.time,
          clubName: club ? club.name : 'Unknown Club',
          venueName: venue ? venue.name : 'Unknown Venue'
        },
        isPast,
        registeredAt: registration.registeredAt,
        attendance: attendance ? {
          FN: attendance.FN || false,
          AN: attendance.AN || false,
          eligible: attendance.FN && attendance.AN
        } : null,
        certificate: certificate || null
      };
    }).filter(Boolean);
    
    // Sort events: upcoming by date (closest first), past by date (most recent first)
    registeredEventsList.sort((a, b) => {
      const dateA = new Date(a.event.date);
      const dateB = new Date(b.event.date);
      
      if (!a.isPast && !b.isPast) {
        return dateA - dateB; // Ascending for upcoming
      } else if (a.isPast && b.isPast) {
        return dateB - dateA; // Descending for past
      }
      
      return a.isPast ? 1 : -1; // Upcoming before past
    });
    
    setRegisteredEvents(registeredEventsList);
  }, [currentUser, events, clubs, venues, eventRegistrations, attendanceRecords, certificates]);
  
  // Cancel registration
  const handleCancelRegistration = async () => {
    if (!selectedRegistration) return;
    
    try {
      await deleteRegistration(selectedRegistration.registrationId);
      
      // Update state
      setRegisteredEvents(prev => 
        prev.filter(reg => reg.registrationId !== selectedRegistration.registrationId)
      );
      
      setSuccessMessage('Registration cancelled successfully');
      setTimeout(() => setSuccessMessage(''), 3000);
      
      setCancelDialogOpen(false);
      setSelectedRegistration(null);
    } catch (err) {
      setError('Failed to cancel registration');
      setTimeout(() => setError(''), 3000);
      setCancelDialogOpen(false);
    }
  };
  
  // Filter events based on active tab
  const filteredEvents = registeredEvents.filter(item => {
    if (activeTab === 'upcoming') {
      return !item.isPast;
    } else if (activeTab === 'past') {
      return item.isPast;
    } else if (activeTab === 'certificates') {
      return item.isPast && item.attendance && item.attendance.eligible;
    }
    return true;
  });
  
  return (
    <div>
      <h1>My Events</h1>
      
      {successMessage && (
        <div style={{ 
          padding: '15px', 
          backgroundColor: '#d4edda', 
          color: '#155724',
          borderRadius: '5px',
          marginBottom: '20px'
        }}>
          {successMessage}
        </div>
      )}
      
      {error && (
        <div style={{ 
          padding: '15px', 
          backgroundColor: '#f8d7da', 
          color: '#721c24',
          borderRadius: '5px',
          marginBottom: '20px'
        }}>
          {error}
        </div>
      )}
      
      <div style={{ 
        display: 'flex', 
        backgroundColor: 'white',
        borderRadius: '8px 8px 0 0',
        overflow: 'hidden',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
      }}>
        <button
          onClick={() => setActiveTab('upcoming')}
          style={{
            flex: 1,
            padding: '15px',
            backgroundColor: activeTab === 'upcoming' ? '#f39c12' : 'transparent',
            color: activeTab === 'upcoming' ? 'white' : '#333',
            border: 'none',
            cursor: 'pointer',
            fontWeight: activeTab === 'upcoming' ? 'bold' : 'normal'
          }}
        >
          Upcoming Events ({registeredEvents.filter(item => !item.isPast).length})
        </button>
        
        <button
          onClick={() => setActiveTab('past')}
          style={{
            flex: 1,
            padding: '15px',
            backgroundColor: activeTab === 'past' ? '#f39c12' : 'transparent',
            color: activeTab === 'past' ? 'white' : '#333',
            border: 'none',
            cursor: 'pointer',
            fontWeight: activeTab === 'past' ? 'bold' : 'normal'
          }}
        >
          Past Events ({registeredEvents.filter(item => item.isPast).length})
        </button>
        
        <button
          onClick={() => setActiveTab('certificates')}
          style={{
            flex: 1,
            padding: '15px',
            backgroundColor: activeTab === 'certificates' ? '#f39c12' : 'transparent',
            color: activeTab === 'certificates' ? 'white' : '#333',
            border: 'none',
            cursor: 'pointer',
            fontWeight: activeTab === 'certificates' ? 'bold' : 'normal'
          }}
        >
          Certificates ({registeredEvents.filter(item => item.isPast && item.attendance && item.attendance.eligible).length})
        </button>
      </div>
      
      <div style={{ 
        backgroundColor: 'white',
        borderRadius: '0 0 8px 8px',
        padding: '20px',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
        marginBottom: '30px'
      }}>
        {filteredEvents.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '30px 0' }}>
            <p style={{ fontSize: '16px', color: '#666', margin: '0 0 20px 0' }}>
              {activeTab === 'upcoming' 
                ? "You don't have any upcoming events." 
                : activeTab === 'past' 
                ? "You don't have any past events."
                : "You don't have any certificates yet."}
            </p>
            
            <Link to="/student/events" style={{
              display: 'inline-block',
              padding: '10px 20px',
              backgroundColor: '#f39c12',
              color: 'white',
              textDecoration: 'none',
              borderRadius: '4px'
            }}>
              Browse Events
            </Link>
          </div>
        ) : (
          <div>
            {activeTab === 'certificates' ? (
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '20px' }}>
                {filteredEvents.map(item => (
                  <div key={item.registrationId} style={{
                    backgroundColor: '#f8f9fa',
                    borderRadius: '8px',
                    padding: '20px',
                    border: '1px solid #eee'
                  }}>
                    <h3 style={{ margin: '0 0 15px 0' }}>{item.event.title}</h3>
                    <p style={{ margin: '0 0 15px 0', color: '#666' }}>
                      <strong>Date:</strong> {item.event.dateFormatted}<br/>
                      <strong>Club:</strong> {item.event.clubName}
                    </p>
                    
                    <div style={{ 
                      marginBottom: '15px',
                      padding: '10px',
                      backgroundColor: '#d4edda',
                      color: '#155724',
                      borderRadius: '4px',
                      textAlign: 'center',
                      fontWeight: 'bold'
                    }}>
                      Certificate Earned
                    </div>
                    
                    <Link to="/student/certificates" style={{
                      display: 'block',
                      padding: '8px 0',
                      backgroundColor: '#9b59b6',
                      color: 'white',
                      textAlign: 'center',
                      textDecoration: 'none',
                      borderRadius: '4px'
                    }}>
                      View Certificate
                    </Link>
                  </div>
                ))}
              </div>
            ) : (
              <div>
                {filteredEvents.map(item => (
                  <div key={item.registrationId} style={{ 
                    borderBottom: '1px solid #eee',
                    padding: '20px 0',
                    marginBottom: '10px',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    flexWrap: 'wrap',
                    gap: '20px'
                  }}>
                    <div>
                      <h3 style={{ margin: '0 0 10px 0' }}>{item.event.title}</h3>
                      <p style={{ margin: '0 0 5px 0', color: '#666' }}>
                        <strong>Date:</strong> {item.event.dateFormatted} • <strong>Time:</strong> {item.event.time}
                      </p>
                      <p style={{ margin: '0 0 10px 0', color: '#666' }}>
                        <strong>Venue:</strong> {item.event.venueName} • <strong>Club:</strong> {item.event.clubName}
                      </p>
                      
                      {item.isPast && item.attendance && (
                        <div style={{ 
                          display: 'flex', 
                          gap: '10px', 
                          marginBottom: '10px',
                          fontSize: '14px'
                        }}>
                          <div style={{ 
                            padding: '4px 8px',
                            backgroundColor: item.attendance.FN ? '#d4edda' : '#f8d7da',
                            color: item.attendance.FN ? '#155724' : '#721c24',
                            borderRadius: '4px'
                          }}>
                            FN: {item.attendance.FN ? 'Present' : 'Absent'}
                          </div>
                          <div style={{ 
                            padding: '4px 8px',
                            backgroundColor: item.attendance.AN ? '#d4edda' : '#f8d7da',
                            color: item.attendance.AN ? '#155724' : '#721c24',
                            borderRadius: '4px'
                          }}>
                            AN: {item.attendance.AN ? 'Present' : 'Absent'}
                          </div>
                          <div style={{ 
                            padding: '4px 8px',
                            backgroundColor: item.attendance.eligible ? '#d4edda' : '#f8d7da',
                            color: item.attendance.eligible ? '#155724' : '#721c24',
                            borderRadius: '4px'
                          }}>
                            {item.attendance.eligible ? 'Certificate Eligible' : 'Not Eligible for Certificate'}
                          </div>
                        </div>
                      )}
                    </div>
                    
                    <div style={{ display: 'flex', gap: '10px' }}>
                      <Link to={`/student/events/${item.event.id}`} style={{
                        padding: '8px 15px',
                        backgroundColor: '#f39c12',
                        color: 'white',
                        textDecoration: 'none',
                        borderRadius: '4px'
                      }}>
                        View Event
                      </Link>
                      
                      {!item.isPast && (
                        <button
                          onClick={() => {
                            setSelectedRegistration(item);
                            setCancelDialogOpen(true);
                          }}
                          style={{
                            padding: '8px 15px',
                            backgroundColor: '#e74c3c',
                            color: 'white',
                            border: 'none',
                            borderRadius: '4px',
                            cursor: 'pointer'
                          }}
                        >
                          Cancel Registration
                        </button>
                      )}
                      
                      {item.isPast && item.attendance && item.attendance.eligible && item.certificate && (
                        <Link to="/student/certificates" style={{
                          padding: '8px 15px',
                          backgroundColor: '#9b59b6',
                          color: 'white',
                          textDecoration: 'none',
                          borderRadius: '4px'
                        }}>
                          View Certificate
                        </Link>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
      
      {/* Cancellation Confirmation Dialog */}
      {cancelDialogOpen && selectedRegistration && (
        <div style={{ 
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          // src/pages/student/MyEvents.js (continued)
          backgroundColor: 'rgba(0, 0, 0, 0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000
        }}>
          <div style={{ 
            backgroundColor: 'white',
            borderRadius: '8px',
            padding: '20px',
            maxWidth: '400px',
            width: '90%',
            boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)'
          }}>
            <h2 style={{ margin: '0 0 15px 0' }}>Cancel Registration</h2>
            
            <p>Are you sure you want to cancel your registration for this event?</p>
            
            <p style={{ fontWeight: 'bold' }}>{selectedRegistration.event.title}</p>
            <p style={{ margin: '0 0 20px 0', color: '#666' }}>
              {selectedRegistration.event.dateFormatted} at {selectedRegistration.event.time}
            </p>
            
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px' }}>
              <button 
                onClick={() => {
                  setCancelDialogOpen(false);
                  setSelectedRegistration(null);
                }}
                style={{
                  padding: '8px 15px',
                  backgroundColor: '#f0f0f0',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
              >
                Keep Registration
              </button>
              <button 
                onClick={handleCancelRegistration}
                style={{
                  padding: '8px 15px',
                  backgroundColor: '#e74c3c',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
              >
                Cancel Registration
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MyEvents;
