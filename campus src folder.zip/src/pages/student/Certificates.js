import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import useCollectionData from '../../hooks/useCollection';
import { useAuth } from '../../context/AuthContext';

const Certificates = () => {
  const { currentUser } = useAuth();
  
  const { items: certificates } = useCollectionData('certificates');
  const { items: events } = useCollectionData('events');
  const { items: clubs } = useCollectionData('clubs');
  
  const [myCertificates, setMyCertificates] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCertificate, setSelectedCertificate] = useState(null);
  const [viewModalOpen, setViewModalOpen] = useState(false);
  
  // Load user's certificates
  useEffect(() => {
    if (!currentUser || !certificates.length || !events.length || !clubs.length) return;
    
    const userCertificates = certificates
      .filter(cert => cert.studentId === currentUser.id)
      .map(cert => {
        const event = events.find(e => e.id === cert.eventId);
        if (!event) return null;
        
        const club = clubs.find(c => c.id === event.clubId);
        
        return {
          id: cert.id,
          url: cert.url,
          fileName: cert.fileName || `certificate_${event.title.replace(/\s+/g, '_')}.pdf`,
          generatedAt: cert.generatedAt,
          event: {
            id: event.id,
            title: event.title,
            date: event.date,
            dateFormatted: new Date(event.date).toLocaleDateString(),
            clubName: club ? club.name : 'Unknown Club'
          },
          verificationCode: cert.id.substring(0, 8).toUpperCase()
        };
      })
      .filter(Boolean);
    
    // Sort by generation date, newest first
    userCertificates.sort((a, b) => 
      new Date(b.generatedAt || 0) - new Date(a.generatedAt || 0)
    );
    
    setMyCertificates(userCertificates);
  }, [currentUser, certificates, events, clubs]);
  
  // Filter certificates based on search term
  const filteredCertificates = myCertificates.filter(cert => {
    if (!searchTerm) return true;
    
    const term = searchTerm.toLowerCase();
    return (
      cert.event.title.toLowerCase().includes(term) ||
      cert.event.clubName.toLowerCase().includes(term) ||
      cert.verificationCode.toLowerCase().includes(term)
    );
  });
  
  // Handle certificate download
  const handleDownload = (certificate) => {
    if (certificate.url) {
      // Create temporary anchor element to trigger download
      const a = document.createElement('a');
      a.href = certificate.url;
      a.download = certificate.fileName;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    }
  };
  
  // Handle certificate view
  const handleView = (certificate) => {
    setSelectedCertificate(certificate);
    setViewModalOpen(true);
  };
  
  // Verify certificate
  const verifyCertificate = (code) => {
    return certificates.some(cert => cert.id.substring(0, 8).toUpperCase() === code);
  };
  
  return (
    <div>
      <h1>My Certificates</h1>
      
      {myCertificates.length === 0 ? (
        <div style={{ 
          backgroundColor: 'white', 
          padding: '30px', 
          borderRadius: '8px',
          textAlign: 'center',
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
        }}>
          <p style={{ fontSize: '16px', margin: '0 0 20px 0' }}>
            You don't have any certificates yet.
          </p>
          <p style={{ fontSize: '14px', color: '#666', margin: '0 0 20px 0' }}>
            Attend events with full attendance to earn certificates.
          </p>
          <Link to="/student/events" style={{
            display: 'inline-block',
            padding: '10px 20px',
            backgroundColor: '#f39c12',
            color: 'white',
            textDecoration: 'none',
            borderRadius: '4px'
          }}>
            Browse Events
          </Link>
        </div>
      ) : (
        <>
          <div style={{ 
            backgroundColor: 'white', 
            padding: '20px', 
            borderRadius: '8px',
            marginBottom: '20px',
            boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
          }}>
            <input
              type="text"
              placeholder="Search certificates by event name, club, or verification code"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              style={{
                width: '100%',
                padding: '12px 15px',
                borderRadius: '4px',
                border: '1px solid #ddd',
                fontSize: '16px'
              }}
            />
          </div>
          
          {filteredCertificates.length === 0 ? (
            <div style={{ 
              backgroundColor: 'white', 
              padding: '30px', 
              borderRadius: '8px',
              textAlign: 'center',
              boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
            }}>
              <p>No certificates found matching your search.</p>
            </div>
          ) : (
            <div style={{ 
              display: 'grid', 
              gridTemplateColumns: 'repeat(auto-fill, minmax(350px, 1fr))', 
              gap: '20px'
            }}>
              {filteredCertificates.map(certificate => (
                <div key={certificate.id} style={{ 
                  backgroundColor: 'white',
                  borderRadius: '8px',
                  overflow: 'hidden',
                  boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
                }}>
                  <div style={{ 
                    backgroundColor: '#9b59b6',
                    padding: '15px 20px',
                    color: 'white'
                  }}>
                    <h3 style={{ margin: '0', fontSize: '18px' }}>Certificate of Participation</h3>
                  </div>
                  
                  <div style={{ padding: '20px' }}>
                    <h2 style={{ margin: '0 0 15px 0', fontSize: '20px' }}>{certificate.event.title}</h2>
                    
                    <div style={{ marginBottom: '15px' }}>
                      <div style={{ marginBottom: '5px' }}>
                        <span style={{ color: '#666', fontSize: '14px' }}>Date:</span>
                        <span style={{ marginLeft: '5px', fontSize: '14px' }}>{certificate.event.dateFormatted}</span>
                      </div>
                      <div style={{ marginBottom: '5px' }}>
                        <span style={{ color: '#666', fontSize: '14px' }}>Club:</span>
                        <span style={{ marginLeft: '5px', fontSize: '14px' }}>{certificate.event.clubName}</span>
                      </div>
                      <div>
                        <span style={{ color: '#666', fontSize: '14px' }}>Verification Code:</span>
                        <span style={{ 
                          marginLeft: '5px', 
                          fontSize: '14px',
                          fontFamily: 'monospace',
                          fontWeight: 'bold'
                        }}>
                          {certificate.verificationCode}
                        </span>
                      </div>
                    </div>
                  </div>
                  
                  <div style={{ 
                    borderTop: '1px solid #eee',
                    padding: '15px 20px',
                    display: 'flex',
                    gap: '10px'
                  }}>
                    <button
                      onClick={() => handleView(certificate)}
                      style={{
                        flex: 1,
                        padding: '8px 0',
                        backgroundColor: '#9b59b6',
                        color: 'white',
                        border: 'none',
                        borderRadius: '4px',
                        cursor: 'pointer',
                        fontSize: '14px'
                      }}
                    >
                      View Certificate
                    </button>
                    
                    <button
                      onClick={() => handleDownload(certificate)}
                      style={{
                        flex: 1,
                        padding: '8px 0',
                        backgroundColor: '#3498db',
                        color: 'white',
                        border: 'none',
                        borderRadius: '4px',
                        cursor: 'pointer',
                        fontSize: '14px'
                      }}
                    >
                      Download
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
          
          {/* Certificate verification section */}
          <div style={{ 
            backgroundColor: 'white', 
            padding: '20px', 
            borderRadius: '8px',
            marginTop: '30px',
            boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
          }}>
            <h2 style={{ marginTop: 0 }}>Certificate Verification</h2>
            
            <p>
              To verify a certificate, enter the verification code found on the certificate. 
              Others can use this code to verify the authenticity of your certificates.
            </p>
            
            <Link to="/certificate-verify" style={{
              display: 'inline-block',
              padding: '10px 20px',
              backgroundColor: '#9b59b6',
              color: 'white',
              textDecoration: 'none',
              borderRadius: '4px',
              marginTop: '10px'
            }}>
              Go to Certificate Verification
            </Link>
          </div>
        </>
      )}
      
      {/* Certificate Viewer Modal */}
      {viewModalOpen && selectedCertificate && (
        <div style={{ 
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.8)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000
        }}>
          <div style={{ 
            backgroundColor: 'white',
            borderRadius: '8px',
            width: '90%',
            maxWidth: '800px',
            maxHeight: '90vh',
            overflow: 'hidden',
            display: 'flex',
            flexDirection: 'column'
          }}>
            <div style={{ 
              padding: '15px 20px',
              backgroundColor: '#9b59b6',
              color: 'white',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center'
            }}>
              <h3 style={{ margin: 0 }}>Certificate Preview</h3>
              <button
                onClick={() => setViewModalOpen(false)}
                style={{
                  background: 'none',
                  border: 'none',
                  color: 'white',
                  fontSize: '22px',
                  cursor: 'pointer'
                }}
              >
                ×
              </button>
            </div>
            
            <div style={{ flex: 1, overflow: 'auto', padding: '20px' }}>
              {selectedCertificate.url ? (
                <iframe 
                  src={selectedCertificate.url} 
                  title="Certificate Preview"
                  style={{ width: '100%', height: '500px', border: 'none' }}
                />
              ) : (
                <div style={{ 
                  padding: '20px', 
                  textAlign: 'center',
                  backgroundColor: '#f8d7da',
                  color: '#721c24',
                  borderRadius: '4px'
                }}>
                  Certificate preview not available
                </div>
              )}
            </div>
            
            <div style={{ 
              padding: '15px 20px',
              borderTop: '1px solid #eee',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              backgroundColor: '#f8f9fa'
            }}>
              <div>
                <strong>Verification Code:</strong> {selectedCertificate.verificationCode}
              </div>
              
              <button
                onClick={() => handleDownload(selectedCertificate)}
                style={{
                  padding: '8px 15px',
                  backgroundColor: '#3498db',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
              >
                Download
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Certificates;
