import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import useCollectionData from '../../hooks/useCollection';

const Profile = () => {
  const { currentUser } = useAuth();
  
  const { items: clubMembers } = useCollectionData('club_members');
  const { items: clubs } = useCollectionData('clubs');
  const { items: eventRegistrations } = useCollectionData('event_registrations');
  const { items: events } = useCollectionData('events');
  const { items: certificates } = useCollectionData('certificates');
  const { items: attendanceRecords } = useCollectionData('attendance_records');
  
  const [stats, setStats] = useState({
    clubs: 0,
    events: {
      total: 0,
      attended: 0,
      upcoming: 0
    },
    certificates: 0,
    attendance: {
      full: 0,
      partial: 0
    }
  });
  
  // Calculate user statistics
  useEffect(() => {
    if (!currentUser) return;
    
    // Club memberships
    const userClubs = clubMembers.filter(
      member => member.studentId === currentUser.id
    );
    
    // Event registrations
    const userRegistrations = eventRegistrations.filter(
      reg => reg.studentId === currentUser.id
    );
    
    const userEventIds = userRegistrations.map(reg => reg.eventId);
    
    // Calculate attended events (past events user registered for)
    const now = new Date();
    const pastEvents = events.filter(
      event => userEventIds.includes(event.id) && new Date(event.date) < now
    );
    
    const upcomingEvents = events.filter(
      event => userEventIds.includes(event.id) && new Date(event.date) >= now
    );
    
    // Calculate attendance records
    const userAttendance = attendanceRecords.filter(
      record => record.studentId === currentUser.id
    );
    
    const fullAttendance = userAttendance.filter(
      record => record.FN && record.AN
    );
    
    const partialAttendance = userAttendance.filter(
      record => (record.FN || record.AN) && !(record.FN && record.AN)
    );
    
    // Certificates earned
    const userCertificates = certificates.filter(
      cert => cert.studentId === currentUser.id
    );
    
    setStats({
      clubs: userClubs.length,
      events: {
        total: userRegistrations.length,
        attended: pastEvents.length,
        upcoming: upcomingEvents.length
      },
      certificates: userCertificates.length,
      attendance: {
        full: fullAttendance.length,
        partial: partialAttendance.length
      }
    });
  }, [currentUser, clubMembers, eventRegistrations, events, certificates, attendanceRecords]);
  
  if (!currentUser) {
    return <div>Loading user profile...</div>;
  }
  
  return (
    <div>
      <h1>My Profile</h1>
      
      <div style={{ 
        backgroundColor: 'white',
        borderRadius: '8px',
        padding: '30px',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
        marginBottom: '30px'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: '30px' }}>
          <div style={{ 
            width: '100px',
            height: '100px',
            borderRadius: '50%',
            backgroundColor: '#f39c12',
            color: 'white',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '36px',
            fontWeight: 'bold',
            marginRight: '20px'
          }}>
            {currentUser.name.charAt(0).toUpperCase()}
          </div>
          
          <div>
            <h2 style={{ margin: '0 0 10px 0' }}>{currentUser.name}</h2>
            <p style={{ margin: '0', color: '#666' }}>{currentUser.email}</p>
            <p style={{ 
              margin: '10px 0 0 0',
              display: 'inline-block',
              padding: '5px 10px',
              backgroundColor: getRoleColor(currentUser.role),
              color: 'white',
              borderRadius: '4px',
              fontSize: '14px'
            }}>
              {getRoleName(currentUser.role)}
            </p>
          </div>
        </div>
        
        <div style={{ borderTop: '1px solid #eee', paddingTop: '20px' }}>
          <h3 style={{ margin: '0 0 15px 0' }}>Account Information</h3>
          
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px' }}>
            <div>
              <p style={{ margin: '0 0 5px 0', color: '#666', fontSize: '14px' }}>Name</p>
              <p style={{ margin: '0', fontWeight: 'bold' }}>{currentUser.name}</p>
            </div>
            
            <div>
              <p style={{ margin: '0 0 5px 0', color: '#666', fontSize: '14px' }}>Email</p>
              <p style={{ margin: '0', fontWeight: 'bold' }}>{currentUser.email}</p>
            </div>
            
            <div>
              <p style={{ margin: '0 0 5px 0', color: '#666', fontSize: '14px' }}>Role</p>
              <p style={{ margin: '0', fontWeight: 'bold' }}>{getRoleName(currentUser.role)}</p>
            </div>
            
            <div>
              <p style={{ margin: '0 0 5px 0', color: '#666', fontSize: '14px' }}>Member Since</p>
              <p style={{ margin: '0', fontWeight: 'bold' }}>
                {currentUser.createdAt 
                  ? new Date(currentUser.createdAt).toLocaleDateString() 
                  : 'Not available'}
              </p>
            </div>
          </div>
        </div>
      </div>
      
      <h2>My Activity Statistics</h2>
      
      <div style={{ 
        display: 'grid', 
        gridTemplateColumns: 'repeat(auto-fill, minmax(250px, 1fr))', 
        gap: '20px',
        marginBottom: '30px'
      }}>
        <div style={{ 
          backgroundColor: 'white',
          borderRadius: '8px',
          padding: '20px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
          textAlign: 'center'
        }}>
          <h3 style={{ margin: '0 0 5px 0', color: '#f39c12' }}>Club Memberships</h3>
          <p style={{ fontSize: '32px', fontWeight: 'bold', margin: '10px 0' }}>{stats.clubs}</p>
          <p style={{ color: '#666', margin: '0' }}>Active Clubs</p>
        </div>
        
        <div style={{ 
          backgroundColor: 'white',
          borderRadius: '8px',
          padding: '20px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
          textAlign: 'center'
        }}>
          <h3 style={{ margin: '0 0 5px 0', color: '#3498db' }}>Event Participation</h3>
          <p style={{ fontSize: '32px', fontWeight: 'bold', margin: '10px 0' }}>{stats.events.total}</p>
          <p style={{ color: '#666', margin: '0' }}>Total Events</p>
        </div>
        
        <div style={{ 
          backgroundColor: 'white',
          borderRadius: '8px',
          padding: '20px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
          textAlign: 'center'
        }}>
          <h3 style={{ margin: '0 0 5px 0', color: '#2ecc71' }}>Full Attendance</h3>
          <p style={{ fontSize: '32px', fontWeight: 'bold', margin: '10px 0' }}>{stats.attendance.full}</p>
          <p style={{ color: '#666', margin: '0' }}>Events</p>
        </div>
        
        <div style={{ 
          backgroundColor: 'white',
          borderRadius: '8px',
          padding: '20px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
          textAlign: 'center'
        }}>
          <h3 style={{ margin: '0 0 5px 0', color: '#9b59b6' }}>Certificates</h3>
          <p style={{ fontSize: '32px', fontWeight: 'bold', margin: '10px 0' }}>{stats.certificates}</p>
          <p style={{ color: '#666', margin: '0' }}>Earned</p>
        </div>
      </div>
      
      <div style={{ 
        backgroundColor: 'white',
        borderRadius: '8px',
        padding: '20px',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
      }}>
        <h2 style={{ marginTop: 0 }}>Participation Summary</h2>
        
        <div style={{ display: 'flex', gap: '20px', flexWrap: 'wrap' }}>
          <div style={{ flex: '1 1 300px' }}>
            <h3 style={{ margin: '0 0 15px 0' }}>Event Participation</h3>
            
            <div style={{ marginBottom: '20px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '5px' }}>
                <span>Attended Events</span>
                <span>{stats.events.attended}</span>
              </div>
              <div style={{ 
                height: '10px', 
                backgroundColor: '#ecf0f1',
                borderRadius: '5px',
                overflow: 'hidden'
              }}>
                <div style={{ 
                  height: '100%', 
                  width: `${(stats.events.attended / Math.max(stats.events.total, 1)) * 100}%`,
                  backgroundColor: '#3498db',
                  borderRadius: '5px'
                }} />
              </div>
            </div>
            
            <div style={{ marginBottom: '20px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '5px' }}>
                <span>Upcoming Events</span>
                <span>{stats.events.upcoming}</span>
              </div>
              <div style={{ 
                height: '10px', 
                backgroundColor: '#ecf0f1',
                borderRadius: '5px',
                overflow: 'hidden'
              }}>
                <div style={{ 
                  height: '100%', 
                  width: `${(stats.events.upcoming / Math.max(stats.events.total, 1)) * 100}%`,
                  backgroundColor: '#f39c12',
                  borderRadius: '5px'
                }} />
              </div>
            </div>
          </div>
          
          <div style={{ flex: '1 1 300px' }}>
            <h3 style={{ margin: '0 0 15px 0' }}>Attendance</h3>
            
            <div style={{ marginBottom: '20px' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '5px' }}>
                <span>Full Attendance</span>
                <span>{stats.attendance.full}</span>
              </div>
              <div style={{ 
                height: '10px', 
                backgroundColor: '#ecf0f1',
                borderRadius: '5px',
                overflow: 'hidden'
              }}>
                <div style={{ 
                  height: '100%', 
                  width: `${(stats.attendance.full / Math.max(stats.events.attended, 1)) * 100}%`,
                  backgroundColor: '#2ecc71',
                  borderRadius: '5px'
                }} />
              </div>
            </div>
            
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '5px' }}>
                <span>Partial Attendance</span>
                <span>{stats.attendance.partial}</span>
              </div>
              <div style={{ 
                height: '10px', 
                backgroundColor: '#ecf0f1',
                borderRadius: '5px',
                overflow: 'hidden'
              }}>
                <div style={{ 
                  height: '100%', 
                  width: `${(stats.attendance.partial / Math.max(stats.events.attended, 1)) * 100}%`,
                  backgroundColor: '#e74c3c',
                  borderRadius: '5px'
                }} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Helper function to get role name
const getRoleName = (role) => {
  switch (role) {
    case 'admin':
      return 'Administrator';
    case 'faculty':
      return 'Faculty Member';
    case 'studentCoordinator':
      return 'Student Coordinator';
    case 'student':
      return 'Student';
    default:
      return role;
  }
};

// Helper function to get role color
const getRoleColor = (role) => {
  switch (role) {
    case 'admin':
      return '#e74c3c';
    case 'faculty':
      return '#3498db';
    case 'studentCoordinator':
      return '#9b59b6';
    case 'student':
      return '#f39c12';
    default:
      return '#95a5a6';
  }
};

export default Profile;
