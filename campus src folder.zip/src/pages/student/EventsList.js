import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import useCollectionData from '../../hooks/useCollection';
import { useAuth } from '../../context/AuthContext';

const EventsList = () => {
  const { currentUser } = useAuth();
  
  const { items: events } = useCollectionData('events');
  const { items: clubs } = useCollectionData('clubs');
  const { items: venues } = useCollectionData('venues');
  const { items: clubMembers } = useCollectionData('club_members');
  const { items: eventRegistrations } = useCollectionData('event_registrations');
  
  const [filteredEvents, setFilteredEvents] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [clubFilter, setClubFilter] = useState('all');
  const [myClubs, setMyClubs] = useState([]);
  const [dateFilter, setDateFilter] = useState('upcoming');
  const [registrationStatus, setRegistrationStatus] = useState({});
  
  // Get user club memberships
  useEffect(() => {
    if (!currentUser) return;
    
    const userMemberships = clubMembers.filter(member => member.studentId === currentUser.id);
    const userClubIds = userMemberships.map(membership => membership.clubId);
    const memberClubs = clubs
      .filter(club => userClubIds.includes(club.id))
      .map(club => ({
        id: club.id,
        name: club.name
      }));
    
    setMyClubs(memberClubs);
  }, [currentUser, clubMembers, clubs]);
  
  // Filter events
  useEffect(() => {
    if (!events.length || !clubs.length || !venues.length) return;
    
    let now = new Date();
    now.setHours(0, 0, 0, 0); // Start of today
    
    let filteredList = [...events];
    
    // Filter only approved events
    filteredList = filteredList.filter(event => event.approved);
    
    // Apply date filter
    if (dateFilter === 'upcoming') {
      filteredList = filteredList.filter(event => new Date(event.date) >= now);
    } else if (dateFilter === 'past') {
      filteredList = filteredList.filter(event => new Date(event.date) < now);
    }
    
    // Apply club filter
    if (clubFilter !== 'all') {
      filteredList = filteredList.filter(event => event.clubId === clubFilter);
    }
    
    // Apply search filter
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filteredList = filteredList.filter(event => 
        event.title.toLowerCase().includes(term) || 
        (event.desc && event.desc.toLowerCase().includes(term))
      );
    }
    
    // Sort events: upcoming by date (closest first), past by date (most recent first)
    filteredList.sort((a, b) => {
      const dateA = new Date(a.date);
      const dateB = new Date(b.date);
      
      if (dateFilter === 'upcoming') {
        return dateA - dateB; // Ascending for upcoming
      } else if (dateFilter === 'past') {
        return dateB - dateA; // Descending for past
      }
      
      return 0;
    });
    
    // Enrich events with club and venue data
    const enrichedEvents = filteredList.map(event => {
      const club = clubs.find(c => c.id === event.clubId) || { name: 'Unknown Club' };
      const venue = venues.find(v => v.id === event.venueId) || { name: 'Unknown Venue' };
      
      return {
        ...event,
        clubName: club.name,
        venueName: venue.name,
        dateFormatted: new Date(event.date).toLocaleDateString()
      };
    });
    
    setFilteredEvents(enrichedEvents);
  }, [events, clubs, venues, searchTerm, clubFilter, dateFilter]);
  
  // Determine registration status for each event
  useEffect(() => {
    if (!currentUser || !eventRegistrations.length) return;
    
    const statuses = {};
    
    eventRegistrations.forEach(reg => {
      if (reg.studentId === currentUser.id) {
        statuses[reg.eventId] = reg.id;
      }
    });
    
    setRegistrationStatus(statuses);
  }, [currentUser, eventRegistrations]);
  
  return (
    <div>
      <h1>Events</h1>
      
      {/* Search and filter controls */}
      <div style={{ 
        backgroundColor: 'white', 
        padding: '20px', 
        borderRadius: '8px',
        marginBottom: '20px',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
      }}>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '15px', marginBottom: '15px' }}>
          <div style={{ flex: '1 1 300px' }}>
            <input
              type="text"
              placeholder="Search events..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              style={{
                width: '100%',
                padding: '10px 15px',
                borderRadius: '4px',
                border: '1px solid #ddd'
              }}
            />
          </div>
          
          <div>
            <select
              value={dateFilter}
              onChange={e => setDateFilter(e.target.value)}
              style={{
                padding: '10px 15px',
                borderRadius: '4px',
                border: '1px solid #ddd',
                backgroundColor: 'white'
              }}
            >
              <option value="upcoming">Upcoming Events</option>
              <option value="past">Past Events</option>
              <option value="all">All Events</option>
            </select>
          </div>
          
          <div>
            <select
              value={clubFilter}
              onChange={e => setClubFilter(e.target.value)}
              style={{
                padding: '10px 15px',
                borderRadius: '4px',
                border: '1px solid #ddd',
                backgroundColor: 'white'
              }}
            >
              <option value="all">All Clubs</option>
              {myClubs.length > 0 && (
                <optgroup label="My Clubs">
                  {myClubs.map(club => (
                    <option key={club.id} value={club.id}>{club.name}</option>
                  ))}
                </optgroup>
              )}
              <optgroup label="Other Clubs">
                {clubs
                  .filter(club => !myClubs.some(myClub => myClub.id === club.id))
                  .map(club => (
                    <option key={club.id} value={club.id}>{club.name}</option>
                  ))}
              </optgroup>
            </select>
          </div>
        </div>
      </div>
      
      {/* Events list */}
      {filteredEvents.length === 0 ? (
        <div style={{ 
          backgroundColor: 'white', 
          padding: '30px', 
          borderRadius: '8px',
          textAlign: 'center',
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
        }}>
          <p style={{ margin: '0 0 15px 0', fontSize: '16px' }}>No events found matching your criteria.</p>
          <button
            onClick={() => { 
              setSearchTerm(''); 
              setClubFilter('all'); 
              setDateFilter('upcoming'); 
            }}
            style={{
              padding: '10px 20px',
              backgroundColor: '#f39c12',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer'
            }}
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div style={{ 
          display: 'grid', 
          gridTemplateColumns: 'repeat(auto-fill, minmax(350px, 1fr))', 
          gap: '20px'
        }}>
          {filteredEvents.map(event => {
            const isRegistered = !!registrationStatus[event.id];
            const isPast = new Date(event.date) < new Date();
            
            return (
              <div key={event.id} style={{ 
                backgroundColor: 'white',
                borderRadius: '8px',
                overflow: 'hidden',
                boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
                display: 'flex',
                flexDirection: 'column'
              }}>
                <div style={{ padding: '20px' }}>
                  <div style={{ 
                    display: 'flex', 
                    justifyContent: 'space-between', 
                    marginBottom: '10px', 
                    alignItems: 'flex-start'
                  }}>
                    <h2 style={{ margin: '0', fontSize: '20px' }}>{event.title}</h2>
                    {isRegistered && (
                      <div style={{ 
                        backgroundColor: '#d4edda', 
                        color: '#155724',
                        padding: '4px 8px',
                        borderRadius: '4px',
                        fontSize: '12px',
                        fontWeight: 'bold'
                      }}>
                        Registered
                      </div>
                    )}
                  </div>
                  
                  <div style={{ marginBottom: '15px' }}>
                    <div style={{ marginBottom: '5px' }}>
                      <span style={{ color: '#666', fontSize: '14px' }}>Date:</span>
                      <span style={{ marginLeft: '5px', fontSize: '14px' }}>{event.dateFormatted}</span>
                    </div>
                    <div style={{ marginBottom: '5px' }}>
                      <span style={{ color: '#666', fontSize: '14px' }}>Time:</span>
                      <span style={{ marginLeft: '5px', fontSize: '14px' }}>{event.time}</span>
                    </div>
                    <div style={{ marginBottom: '5px' }}>
                      <span style={{ color: '#666', fontSize: '14px' }}>Club:</span>
                      <span style={{ marginLeft: '5px', fontSize: '14px' }}>{event.clubName}</span>
                    </div>
                    <div>
                      <span style={{ color: '#666', fontSize: '14px' }}>Venue:</span>
                      <span style={{ marginLeft: '5px', fontSize: '14px' }}>{event.venueName}</span>
                    </div>
                  </div>
                  
                  <p style={{ 
                    margin: '0', 
                    color: '#666',
                    fontSize: '14px',
                    height: '60px',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis'
                  }}>
                    {event.desc || 'No description available.'}
                  </p>
                </div>
                
                <div style={{ 
                  marginTop: 'auto',
                  borderTop: '1px solid #eee',
                  padding: '15px 20px',
                  display: 'flex',
                  gap: '10px'
                }}>
                  <Link to={`/student/events/${event.id}`} style={{
                    flex: 1,
                    padding: '8px 0',
                    backgroundColor: '#f39c12',
                    color: 'white',
                    textAlign: 'center',
                    textDecoration: 'none',
                    borderRadius: '4px',
                    fontSize: '14px'
                  }}>
                    View Details
                  </Link>
                  
                  {!isPast && (
                    isRegistered ? (
                      <Link to="/student/my-events" style={{
                        flex: 1,
                        padding: '8px 0',
                        backgroundColor: '#27ae60',
                        color: 'white',
                        textAlign: 'center',
                        textDecoration: 'none',
                        borderRadius: '4px',
                        fontSize: '14px'
                      }}>
                        View Registration
                      </Link>
                    ) : (
                      <Link to={`/student/events/${event.id}`} style={{
                        flex: 1,
                        padding: '8px 0',
                        backgroundColor: '#3498db',
                        color: 'white',
                        textAlign: 'center',
                        textDecoration: 'none',
                        borderRadius: '4px',
                        fontSize: '14px'
                      }}>
                        Register
                      </Link>
                    )
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default EventsList;
