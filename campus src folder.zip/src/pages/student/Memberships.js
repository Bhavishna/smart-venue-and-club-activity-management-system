import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import useCollectionData from '../../hooks/useCollection';

const Memberships = () => {
  const { currentUser } = useAuth();
  
  const { items: clubs } = useCollectionData('clubs');
  const { items: clubMembers } = useCollectionData('club_members');
  const { items: clubRequests, deleteItem: deleteRequest } = useCollectionData('club_requests');
  const { items: users } = useCollectionData('users');
  
  const [myMemberships, setMyMemberships] = useState([]);
  const [myRequests, setMyRequests] = useState([]);
  const [activeTab, setActiveTab] = useState('memberships');
  const [cancelRequestId, setCancelRequestId] = useState(null);
  const [successMessage, setSuccessMessage] = useState('');
  const [error, setError] = useState('');
  
  // Get user memberships and requests
  useEffect(() => {
    if (!currentUser) return;
    
    // Get memberships
    const memberships = clubMembers
      .filter(member => member.studentId === currentUser.id)
      .map(member => {
        const club = clubs.find(c => c.id === member.clubId);
        if (!club) return null;
        
        const facultyCoordinator = users.find(user => user.id === club.facultyCoordinatorId);
        const studentCoordinator = users.find(user => user.id === club.studentCoordinatorId);
        
        return {
          membershipId: member.id,
          club: {
            id: club.id,
            name: club.name,
            category: club.category || 'Uncategorized',
            description: club.description,
            facultyName: facultyCoordinator ? facultyCoordinator.name : 'Unknown',
            coordinatorName: studentCoordinator ? studentCoordinator.name : 'Unknown'
          }
        };
      })
      .filter(Boolean); // Remove any null items
    
    setMyMemberships(memberships);
    
    // Get requests
    const requests = clubRequests
      .filter(request => request.studentId === currentUser.id)
      .map(request => {
        const club = clubs.find(c => c.id === request.clubId);
        if (!club) return null;
        
        return {
          requestId: request.id,
          status: request.status,
          requestedAt: request.requestedAt,
          club: {
            id: club.id,
            name: club.name,
            category: club.category || 'Uncategorized'
          }
        };
      })
      .filter(Boolean); // Remove any null items
    
    setMyRequests(requests);
  }, [currentUser, clubs, clubMembers, clubRequests, users]);
  
  // Handle request cancellation
  const handleCancelRequest = async (requestId) => {
    if (!requestId) return;
    
    try {
      await deleteRequest(requestId);
      
      // Update state
      setMyRequests(prev => prev.filter(req => req.requestId !== requestId));
      
      setSuccessMessage('Request cancelled successfully');
      setTimeout(() => setSuccessMessage(''), 3000);
      
      setCancelRequestId(null);
    } catch (err) {
      setError('Failed to cancel request');
      setTimeout(() => setError(''), 3000);
    }
  };
  
  return (
    <div>
      <h1>My Club Memberships</h1>
      
      {successMessage && (
        <div style={{ 
          padding: '15px', 
          backgroundColor: '#d4edda', 
          color: '#155724',
          borderRadius: '5px',
          marginBottom: '20px'
        }}>
          {successMessage}
        </div>
      )}
      
      {error && (
        <div style={{ 
          padding: '15px', 
          backgroundColor: '#f8d7da', 
          color: '#721c24',
          borderRadius: '5px',
          marginBottom: '20px'
        }}>
          {error}
        </div>
      )}
      
      <div style={{ 
        display: 'flex', 
        borderBottom: '1px solid #ddd', 
        marginBottom: '20px'
      }}>
        <button
          onClick={() => setActiveTab('memberships')}
          style={{
            padding: '10px 20px',
            backgroundColor: activeTab === 'memberships' ? '#f39c12' : 'transparent',
            color: activeTab === 'memberships' ? 'white' : '#333',
            border: 'none',
            borderTopLeftRadius: '5px',
            borderTopRightRadius: '5px',
            cursor: 'pointer',
            fontWeight: activeTab === 'memberships' ? 'bold' : 'normal'
          }}
        >
          My Memberships ({myMemberships.length})
        </button>
        
        <button
          onClick={() => setActiveTab('requests')}
          style={{
            padding: '10px 20px',
            backgroundColor: activeTab === 'requests' ? '#f39c12' : 'transparent',
            color: activeTab === 'requests' ? 'white' : '#333',
            border: 'none',
            borderTopLeftRadius: '5px',
            borderTopRightRadius: '5px',
            cursor: 'pointer',
            fontWeight: activeTab === 'requests' ? 'bold' : 'normal',
            position: 'relative'
          }}
        >
          Pending Requests ({myRequests.filter(r => r.status === 'pending').length})
          {myRequests.filter(r => r.status === 'pending').length > 0 && (
            <span style={{
              position: 'absolute',
              top: '5px',
              right: '5px',
              width: '8px',
              height: '8px',
              borderRadius: '50%',
              backgroundColor: '#e74c3c'
            }}></span>
          )}
        </button>
      </div>
      
      {activeTab === 'memberships' && (
        <>
          {myMemberships.length === 0 ? (
            <div style={{ 
              backgroundColor: 'white', 
              padding: '30px', 
              borderRadius: '8px',
              textAlign: 'center',
              boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
            }}>
              <p style={{ margin: '0 0 15px 0', fontSize: '16px' }}>You are not a member of any clubs yet.</p>
              <Link to="/student/clubs" style={{
                display: 'inline-block',
                padding: '10px 20px',
                backgroundColor: '#f39c12',
                color: 'white',
                textDecoration: 'none',
                borderRadius: '4px'
              }}>
                Explore Clubs
              </Link>
            </div>
          ) : (
            <div style={{ 
              display: 'grid', 
              gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', 
              gap: '20px'
            }}>
              {myMemberships.map(membership => (
                <div key={membership.membershipId} style={{ 
                  backgroundColor: 'white',
                  borderRadius: '8px',
                  overflow: 'hidden',
                  boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
                }}>
                  <div style={{ padding: '20px' }}>
                    <h2 style={{ margin: '0 0 10px 0', fontSize: '18px' }}>{membership.club.name}</h2>
                    
                    {membership.club.category && (
                      <div style={{ 
                        display: 'inline-block',
                        backgroundColor: '#f8f9fa',
                        padding: '4px 8px',
                        borderRadius: '4px',
                        fontSize: '12px',
                        marginBottom: '15px'
                      }}>
                        {membership.club.category}
                      </div>
                    )}
                    
                    <p style={{ 
                      margin: '0 0 15px 0', 
                      color: '#666',
                      height: '60px',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis'
                    }}>
                      {membership.club.description || 'No description available.'}
                    </p>
                    
                    <div style={{ 
                      borderTop: '1px solid #eee', 
                      paddingTop: '15px'
                    }}>
                      <div style={{ marginBottom: '5px' }}>
                        <span style={{ color: '#666', fontSize: '14px' }}>Faculty:</span>
                        <span style={{ marginLeft: '5px', fontSize: '14px' }}>{membership.club.facultyName}</span>
                      </div>
                      
                      <div>
                        <span style={{ color: '#666', fontSize: '14px' }}>Coordinator:</span>
                        <span style={{ marginLeft: '5px', fontSize: '14px' }}>{membership.club.coordinatorName}</span>
                      </div>
                    </div>
                  </div>
                  
                  <Link to={`/student/clubs/${membership.club.id}`} style={{
                    display: 'block',
                    padding: '12px 0',
                    backgroundColor: '#f39c12',
                    color: 'white',
                    textAlign: 'center',
                    textDecoration: 'none',
                    fontWeight: 'bold'
                  }}>
                    View Club
                  </Link>
                </div>
              ))}
            </div>
          )}
        </>
      )}
      
      {activeTab === 'requests' && (
        <>
          {myRequests.length === 0 ? (
            <div style={{ 
              backgroundColor: 'white', 
              padding: '30px', 
              borderRadius: '8px',
              textAlign: 'center',
              boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
            }}>
              <p style={{ margin: '0 0 15px 0', fontSize: '16px' }}>You don't have any pending club requests.</p>
              <Link to="/student/clubs" style={{
                display: 'inline-block',
                padding: '10px 20px',
                backgroundColor: '#f39c12',
                color: 'white',
                textDecoration: 'none',
                borderRadius: '4px'
              }}>
                Explore Clubs
              </Link>
            </div>
          ) : (
            <div style={{ 
              backgroundColor: 'white',
              borderRadius: '8px',
              padding: '20px',
              boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
            }}>
              <h2 style={{ margin: '0 0 20px 0' }}>Club Membership Requests</h2>
              
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead>
                  <tr style={{ backgroundColor: '#f8f9fa' }}>
                    <th style={{ padding: '12px 15px', textAlign: 'left', borderBottom: '1px solid #ddd' }}>Club</th>
                    <th style={{ padding: '12px 15px', textAlign: 'left', borderBottom: '1px solid #ddd' }}>Status</th>
                    <th style={{ padding: '12px 15px', textAlign: 'left', borderBottom: '1px solid #ddd' }}>Requested On</th>
                    <th style={{ padding: '12px 15px', textAlign: 'right', borderBottom: '1px solid #ddd' }}>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {myRequests.map(request => (
                    <tr key={request.requestId}>
                      <td style={{ padding: '12px 15px', borderBottom: '1px solid #ddd' }}>
                        <Link to={`/student/clubs/${request.club.id}`} style={{ 
                          color: '#f39c12', 
                          textDecoration: 'none',
                          fontWeight: 'bold'
                        }}>
                          {request.club.name}
                        </Link>
                        {request.club.category && (
                          <span style={{ 
                            display: 'inline-block',
                            backgroundColor: '#f8f9fa',
                            padding: '2px 6px',
                            borderRadius: '4px',
                            fontSize: '11px',
                            marginLeft: '8px'
                          }}>
                            {request.club.category}
                          </span>
                        )}
                      </td>
                      <td style={{ padding: '12px 15px', borderBottom: '1px solid #ddd' }}>
                        <span style={{ 
                          display: 'inline-block',
                          padding: '4px 8px',
                          backgroundColor: getStatusColor(request.status),
                          color: 'white',
                          borderRadius: '4px',
                          fontSize: '12px'
                        }}>
                          {request.status}
                        </span>
                      </td>
                      <td style={{ padding: '12px 15px', borderBottom: '1px solid #ddd' }}>
                        {request.requestedAt 
                          ? new Date(request.requestedAt).toLocaleDateString() 
                          : 'Unknown date'}
                      </td>
                      <td style={{ padding: '12px 15px', textAlign: 'right', borderBottom: '1px solid #ddd' }}>
                        {request.status === 'pending' && (
                          <button
                            onClick={() => setCancelRequestId(request.requestId)}
                            style={{
                              padding: '6px 12px',
                              backgroundColor: '#e74c3c',
                              color: 'white',
                              border: 'none',
                              borderRadius: '4px',
                              cursor: 'pointer',
                              fontSize: '14px'
                            }}
                          >
                            Cancel Request
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}
      
      {/* Confirmation Modal */}
      {cancelRequestId && (
        <div style={{ 
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000
        }}>
          <div style={{ 
            backgroundColor: 'white',
            borderRadius: '8px',
            width: '400px',
            padding: '20px',
            boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)'
          }}>
            <h3 style={{ marginTop: 0 }}>Confirm Cancellation</h3>
            <p>Are you sure you want to cancel this membership request?</p>
            
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px', marginTop: '20px' }}>
              <button
                onClick={() => setCancelRequestId(null)}
                style={{
                  padding: '8px 15px',
                  backgroundColor: '#f0f0f0',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
              >
                No, Keep Request
              </button>
              <button
                onClick={() => handleCancelRequest(cancelRequestId)}
                style={{
                  padding: '8px 15px',
                  backgroundColor: '#e74c3c',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
              >
                Yes, Cancel Request
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// Helper function for status colors
const getStatusColor = (status) => {
  switch(status) {
    case 'approved': return '#27ae60';
    case 'pending': return '#f39c12';
    case 'rejected': return '#e74c3c';
    default: return '#95a5a6';
  }
};

export default Memberships;
