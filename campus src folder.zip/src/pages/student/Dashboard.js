import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import useCollectionData from '../../hooks/useCollection';

const StudentDashboard = () => {
  const { currentUser } = useAuth();
  
  const { items: clubs } = useCollectionData('clubs');
  const { items: clubMembers } = useCollectionData('club_members');
  const { items: clubRequests } = useCollectionData('club_requests');
  const { items: events } = useCollectionData('events');
  const { items: eventRegistrations } = useCollectionData('event_registrations');
  const { items: certificates } = useCollectionData('certificates');
  const { items: attendanceRecords } = useCollectionData('attendance_records');
  
  const [studentStats, setStudentStats] = useState({
    memberships: 0,
    pendingRequests: 0,
    registeredEvents: 0,
    upcomingEvents: 0,
    pastEvents: 0,
    certificates: 0,
    fullAttendance: 0
  });
  
  const [upcomingRegistrations, setUpcomingRegistrations] = useState([]);
  
  useEffect(() => {
    if (!currentUser) return;
    
    // Calculate stats
    const memberships = clubMembers.filter(m => m.studentId === currentUser.id).length;
    const pendingRequests = clubRequests.filter(r => r.studentId === currentUser.id && r.status === 'pending').length;
    
    const userRegistrations = eventRegistrations.filter(r => r.studentId === currentUser.id);
    const registeredEvents = userRegistrations.length;
    
    const now = new Date();
    
    const registeredEventIds = userRegistrations.map(r => r.eventId);
    const registeredEventDetails = events.filter(e => registeredEventIds.includes(e.id));
    
    const upcoming = registeredEventDetails.filter(e => new Date(e.date) >= now).length;
    const past = registeredEventDetails.filter(e => new Date(e.date) < now).length;
    
    const certificateCount = certificates.filter(c => c.studentId === currentUser.id).length;
    
    const userAttendance = attendanceRecords.filter(a => a.studentId === currentUser.id);
    const fullAttendanceCount = userAttendance.filter(a => a.FN && a.AN).length;
    
    setStudentStats({
      memberships,
      pendingRequests,
      registeredEvents,
      upcomingEvents: upcoming,
      pastEvents: past,
      certificates: certificateCount,
      fullAttendance: fullAttendanceCount
    });
    
    // Get upcoming events
    const upcomingEventIds = registeredEventDetails
      .filter(e => new Date(e.date) >= now)
      .sort((a, b) => new Date(a.date) - new Date(b.date))
      .map(e => e.id);
      
    const upcomingWithDetails = upcomingEventIds.map(eventId => {
      const event = events.find(e => e.id === eventId);
      const club = event ? clubs.find(c => c.id === event.clubId) : null;
      return {
        ...event,
        clubName: club ? club.name : 'Unknown Club'
      };
    });
    
    setUpcomingRegistrations(upcomingWithDetails.slice(0, 3)); // Only show 3 upcoming events
    
  }, [currentUser, clubs, clubMembers, clubRequests, events, eventRegistrations, certificates, attendanceRecords]);

  return (
    <div>
      <h1>Welcome, {currentUser?.name}!</h1>
      
      {/* Stats Cards */}
      <div style={{ 
        display: 'grid', 
        gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', 
        gap: '20px',
        marginBottom: '30px'
      }}>
        <StatCard 
          title="My Memberships" 
          value={studentStats.memberships}
          color="#3498db"
          link="/student/memberships"
        />
        {studentStats.pendingRequests > 0 && (
          <StatCard 
            title="Pending Requests" 
            value={studentStats.pendingRequests}
            color="#e74c3c"
            link="/student/memberships"
          />
        )}
        <StatCard 
          title="Registered Events" 
          value={studentStats.registeredEvents}
          color="#2ecc71"
          link="/student/my-events"
        />
        <StatCard 
          title="Certificates Earned" 
          value={studentStats.certificates}
          color="#9b59b6"
          link="/student/certificates"
        />
      </div>
      
      <div style={{ display: 'flex', gap: '20px', flexWrap: 'wrap' }}>
        {/* Upcoming Events Section */}
        <div style={{ 
          flex: '1 1 400px', 
          backgroundColor: 'white',
          borderRadius: '8px',
          padding: '20px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
          marginBottom: '20px'
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '15px' }}>
            <h2 style={{ margin: 0 }}>Your Upcoming Events</h2>
            <Link to="/student/my-events" style={{ color: '#f39c12', textDecoration: 'none' }}>
              View All →
            </Link>
          </div>
          
          {upcomingRegistrations.length > 0 ? (
            upcomingRegistrations.map(event => (
              <div key={event.id} style={{ 
                padding: '15px',
                marginBottom: '15px',
                backgroundColor: '#f9f9f9',
                borderRadius: '5px',
                borderLeft: '4px solid #f39c12'
              }}>
                <div style={{ fontWeight: 'bold', fontSize: '16px', marginBottom: '5px' }}>{event.title}</div>
                <div style={{ color: '#666', marginBottom: '5px' }}>
                  <strong>Date:</strong> {new Date(event.date).toLocaleDateString()}
                  {' • '}
                  <strong>Time:</strong> {event.time}
                </div>
                <div style={{ color: '#666', marginBottom: '10px' }}>
                  <strong>Club:</strong> {event.clubName}
                </div>
                <Link to={`/student/events/${event.id}`} style={{
                  display: 'inline-block',
                  padding: '6px 12px',
                  backgroundColor: '#f39c12',
                  color: 'white',
                  textDecoration: 'none',
                  borderRadius: '4px',
                  fontSize: '14px'
                }}>
                  Event Details
                </Link>
              </div>
            ))
          ) : (
            <div style={{ textAlign: 'center', padding: '20px', color: '#666' }}>
              <p>You don't have any upcoming events.</p>
              <Link to="/student/events" style={{ color: '#f39c12', fontWeight: 'bold' }}>Browse Events</Link>
            </div>
          )}
        </div>
        
        {/* Quick Links Section */}
        <div style={{ 
          flex: '1 1 300px', 
          backgroundColor: 'white',
          borderRadius: '8px',
          padding: '20px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
          marginBottom: '20px'
        }}>
          <h2 style={{ marginTop: 0, marginBottom: '20px' }}>Quick Actions</h2>
          
          <div style={{ display: 'grid', gap: '12px' }}>
            <Link to="/student/clubs" style={{
              display: 'block',
              padding: '12px 15px',
              backgroundColor: '#3498db',
              color: 'white',
              textDecoration: 'none',
              borderRadius: '4px',
              textAlign: 'center',
              fontWeight: 'bold'
            }}>
              Browse Clubs
            </Link>
            
            <Link to="/student/events" style={{
              display: 'block',
              padding: '12px 15px',
              backgroundColor: '#2ecc71',
              color: 'white',
              textDecoration: 'none',
              borderRadius: '4px',
              textAlign: 'center',
              fontWeight: 'bold'
            }}>
              Upcoming Events
            </Link>
            
            <Link to="/student/certificates" style={{
              display: 'block',
              padding: '12px 15px',
              backgroundColor: '#9b59b6',
              color: 'white',
              textDecoration: 'none',
              borderRadius: '4px',
              textAlign: 'center',
              fontWeight: 'bold'
            }}>
              My Certificates
            </Link>
            
            <Link to="/student/profile" style={{
              display: 'block',
              padding: '12px 15px',
              backgroundColor: '#f39c12',
              color: 'white',
              textDecoration: 'none',
              borderRadius: '4px',
              textAlign: 'center',
              fontWeight: 'bold'
            }}>
              My Profile
            </Link>
          </div>
        </div>
      </div>
      
      {/* Activity Stats */}
      <div style={{ 
        backgroundColor: 'white',
        borderRadius: '8px',
        padding: '20px',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
      }}>
        <h2 style={{ marginTop: 0, marginBottom: '20px' }}>Your Activity</h2>
        
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '20px' }}>
          <div style={{ 
            flex: '1 1 200px',
            backgroundColor: '#f8f9fa',
            padding: '20px',
            borderRadius: '5px',
            textAlign: 'center'
          }}>
            <div style={{ fontSize: '14px', color: '#666', marginBottom: '10px' }}>Events Attended</div>
            <div style={{ fontSize: '32px', fontWeight: 'bold', color: '#2ecc71' }}>
              {studentStats.pastEvents}
            </div>
          </div>
          
          <div style={{ 
            flex: '1 1 200px',
            backgroundColor: '#f8f9fa',
            padding: '20px',
            borderRadius: '5px',
            textAlign: 'center'
          }}>
            <div style={{ fontSize: '14px', color: '#666', marginBottom: '10px' }}>Full Attendance</div>
            <div style={{ fontSize: '32px', fontWeight: 'bold', color: '#3498db' }}>
              {studentStats.fullAttendance}
            </div>
          </div>
          
          <div style={{ 
            flex: '1 1 200px',
            backgroundColor: '#f8f9fa',
            padding: '20px',
            borderRadius: '5px',
            textAlign: 'center'
          }}>
            <div style={{ fontSize: '14px', color: '#666', marginBottom: '10px' }}>Upcoming Events</div>
            <div style={{ fontSize: '32px', fontWeight: 'bold', color: '#f39c12' }}>
              {studentStats.upcomingEvents}
            </div>
          </div>
          
          <div style={{ 
            flex: '1 1 200px',
            backgroundColor: '#f8f9fa',
            padding: '20px',
            borderRadius: '5px',
            textAlign: 'center'
          }}>
            <div style={{ fontSize: '14px', color: '#666', marginBottom: '10px' }}>Certificates</div>
            <div style={{ fontSize: '32px', fontWeight: 'bold', color: '#9b59b6' }}>
              {studentStats.certificates}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Stats Card component
const StatCard = ({ title, value, color, link }) => (
  <Link to={link} style={{ textDecoration: 'none' }}>
    <div style={{
      backgroundColor: 'white',
      borderRadius: '8px',
      padding: '20px',
      boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
      transition: 'transform 0.2s',
      cursor: 'pointer',
      height: '100%',
      ':hover': {
        transform: 'translateY(-5px)'
      }
    }}>
      <h3 style={{ margin: '0 0 15px 0', color: color }}>{title}</h3>
      <p style={{ 
        margin: 0, 
        fontSize: '28px', 
        fontWeight: 'bold',
        color: '#333'
      }}>
        {value}
      </p>
    </div>
  </Link>
);

export default StudentDashboard;
