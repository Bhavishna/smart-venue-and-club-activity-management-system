import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import useCollectionData from '../../hooks/useCollection';
import { useAuth } from '../../context/AuthContext';

const ClubDetail = () => {
  const { clubId } = useParams();
  const { currentUser } = useAuth();
  
  const { items: clubs } = useCollectionData('clubs');
  const { items: clubMembers } = useCollectionData('club_members');
  const { items: clubRequests, addItem: addRequest } = useCollectionData('club_requests');
  const { items: users } = useCollectionData('users');
  const { items: events } = useCollectionData('events');
  
  const [club, setClub] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [membershipStatus, setMembershipStatus] = useState(null);
  const [members, setMembers] = useState([]);
  const [clubEvents, setClubEvents] = useState([]);
  const [requestSent, setRequestSent] = useState(false);
  
  // Get club details
  useEffect(() => {
    if (clubs.length > 0 && users.length > 0) {
      const clubData = clubs.find(c => c.id === clubId);
      
      if (clubData) {
        const facultyCoordinator = users.find(user => user.id === clubData.facultyCoordinatorId);
        const studentCoordinator = users.find(user => user.id === clubData.studentCoordinatorId);
        
        setClub({
          ...clubData,
          facultyName: facultyCoordinator ? facultyCoordinator.name : 'Unknown',
          facultyEmail: facultyCoordinator ? facultyCoordinator.email : '',
          coordinatorName: studentCoordinator ? studentCoordinator.name : 'Unknown',
          coordinatorEmail: studentCoordinator ? studentCoordinator.email : ''
        });
      } else {
        setError('Club not found');
      }
      
      setLoading(false);
    }
  }, [clubs, users, clubId]);
  
  // Get membership status
  useEffect(() => {
    if (!currentUser || !clubId) return;
    
    // Check if user is already a member
    const membership = clubMembers.find(
      member => member.clubId === clubId && member.studentId === currentUser.id
    );
    
    if (membership) {
      setMembershipStatus({ status: 'member', id: membership.id });
      return;
    }
    
    // Check if user has a pending request
    const request = clubRequests.find(
      req => req.clubId === clubId && req.studentId === currentUser.id
    );
    
    if (request) {
      setMembershipStatus({ status: request.status, id: request.id });
    }
  }, [currentUser, clubId, clubMembers, clubRequests]);
  
  // Get club members
  useEffect(() => {
    if (!clubId) return;
    
    const clubMembersList = clubMembers
      .filter(member => member.clubId === clubId)
      .map(member => {
        const user = users.find(u => u.id === member.studentId);
        return {
          id: member.id,
          userId: member.studentId,
          name: user ? user.name : 'Unknown User',
          email: user ? user.email : ''
        };
      });
    
    setMembers(clubMembersList);
  }, [clubId, clubMembers, users]);
  
  // Get club events
  useEffect(() => {
    if (!clubId) return;
    
    const now = new Date();
    
    const upcomingEvents = events
      .filter(event => event.clubId === clubId && new Date(event.date) >= now && event.approved)
      .sort((a, b) => new Date(a.date) - new Date(b.date))
      .map(event => ({
        ...event,
        dateFormatted: new Date(event.date).toLocaleDateString()
      }));
    
    setClubEvents(upcomingEvents);
  }, [clubId, events]);
  
  // Handle join request
  const handleJoinRequest = async () => {
    try {
      // Create a join request
      await addRequest({
        clubId,
        studentId: currentUser.id,
        status: 'pending',
        message: '',
        requestedAt: new Date().toISOString()
      });
      
      setRequestSent(true);
      setMembershipStatus({ status: 'pending' });
    } catch (err) {
      setError('Failed to send join request');
    }
  };
  
  if (loading) {
    return <div style={{ textAlign: 'center', padding: '50px' }}>Loading...</div>;
  }
  
  if (error || !club) {
    return (
      <div style={{ 
        padding: '20px', 
        backgroundColor: '#f8d7da',
        color: '#721c24',
        borderRadius: '5px',
        textAlign: 'center'
      }}>
        <p style={{ margin: '0 0 10px 0', fontWeight: 'bold' }}>{error || 'Club not found'}</p>
        <Link to="/student/clubs" style={{ color: '#721c24' }}>Back to Clubs List</Link>
      </div>
    );
  }
  
  return (
    <div>
      <div style={{ marginBottom: '20px' }}>
        <Link to="/student/clubs" style={{ color: '#666', textDecoration: 'none' }}>
          ← Back to Clubs
        </Link>
      </div>
      
      {requestSent && (
        <div style={{ 
          padding: '15px', 
          backgroundColor: '#d4edda', 
          color: '#155724',
          borderRadius: '5px',
          marginBottom: '20px'
        }}>
          Your request to join this club has been sent successfully.
        </div>
      )}
      
      <div style={{ 
        backgroundColor: 'white',
        borderRadius: '8px',
        padding: '30px',
        marginBottom: '20px',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: '20px' }}>
          <div>
            <h1 style={{ margin: '0 0 10px 0' }}>{club.name}</h1>
            
            {club.category && (
              <div style={{ 
                display: 'inline-block',
                backgroundColor: '#f8f9fa',
                padding: '6px 12px',
                borderRadius: '4px',
                fontSize: '14px',
                marginBottom: '20px'
              }}>
                {club.category}
              </div>
            )}
          </div>
          
          {membershipStatus ? (
            <div style={{ 
              padding: '10px 20px',
              backgroundColor: getMembershipStatusColor(membershipStatus.status),
              color: 'white',
              borderRadius: '4px',
              alignSelf: 'flex-start'
            }}>
              {getMembershipStatusText(membershipStatus.status)}
            </div>
          ) : (
            <button
              onClick={handleJoinRequest}
              style={{
                padding: '10px 20px',
                backgroundColor: '#f39c12',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: 'pointer'
              }}
            >
              Request to Join
            </button>
          )}
        </div>
        
        <p style={{ margin: '0 0 25px 0', fontSize: '16px', lineHeight: '1.6' }}>
          {club.description}
        </p>
        
        <div style={{ display: 'flex', gap: '30px', flexWrap: 'wrap', marginBottom: '20px' }}>
          <div>
            <h3 style={{ margin: '0 0 10px 0' }}>Faculty Coordinator</h3>
            <p style={{ margin: '0 0 5px 0', fontWeight: 'bold' }}>{club.facultyName}</p>
            <p style={{ margin: '0', color: '#666' }}>{club.facultyEmail}</p>
          </div>
          
          <div>
           // Continuing src/pages/student/ClubDetail.js
            <h3 style={{ margin: '0 0 10px 0' }}>Student Coordinator</h3>
            <p style={{ margin: '0 0 5px 0', fontWeight: 'bold' }}>{club.coordinatorName}</p>
            <p style={{ margin: '0', color: '#666' }}>{club.coordinatorEmail}</p>
          </div>
          
          <div>
            <h3 style={{ margin: '0 0 10px 0' }}>Membership</h3>
            <p style={{ margin: '0', fontWeight: 'bold' }}>{members.length} members</p>
          </div>
        </div>
      </div>
      
      {/* Upcoming events */}
      <div style={{ 
        backgroundColor: 'white',
        borderRadius: '8px',
        padding: '20px',
        marginBottom: '20px',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
      }}>
        <h2 style={{ marginTop: 0 }}>Upcoming Events</h2>
        
        {clubEvents.length > 0 ? (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '20px' }}>
            {clubEvents.map(event => (
              <div key={event.id} style={{ 
                padding: '15px', 
                backgroundColor: '#f8f9fa', 
                borderRadius: '8px',
                border: '1px solid #eee'
              }}>
                <h3 style={{ margin: '0 0 10px 0' }}>{event.title}</h3>
                <p style={{ margin: '0 0 10px 0', color: '#666' }}>
                  <strong>Date:</strong> {event.dateFormatted}
                  <br />
                  <strong>Time:</strong> {event.time}
                </p>
                
                <Link to={`/student/events/${event.id}`} style={{
                  display: 'inline-block',
                  padding: '8px 15px',
                  backgroundColor: '#f39c12',
                  color: 'white',
                  textDecoration: 'none',
                  borderRadius: '4px',
                  fontSize: '14px'
                }}>
                  View Details
                </Link>
              </div>
            ))}
          </div>
        ) : (
          <p style={{ color: '#666' }}>No upcoming events for this club.</p>
        )}
      </div>
      
      {/* Members list */}
      {(membershipStatus?.status === 'member' || members.length < 5) && (
        <div style={{ 
          backgroundColor: 'white',
          borderRadius: '8px',
          padding: '20px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
        }}>
          <h2 style={{ marginTop: 0 }}>Club Members</h2>
          
          {members.length > 0 ? (
            <div style={{ maxHeight: '300px', overflowY: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead>
                  <tr style={{ backgroundColor: '#f8f9fa' }}>
                    <th style={{ padding: '10px 15px', textAlign: 'left', borderBottom: '1px solid #ddd' }}>Name</th>
                    {membershipStatus?.status === 'member' && (
                      <th style={{ padding: '10px 15px', textAlign: 'left', borderBottom: '1px solid #ddd' }}>Email</th>
                    )}
                  </tr>
                </thead>
                <tbody>
                  {members.map((member, index) => (
                    <tr key={member.id}>
                      <td style={{ padding: '10px 15px', borderBottom: '1px solid #ddd' }}>{member.name}</td>
                      {membershipStatus?.status === 'member' && (
                        <td style={{ padding: '10px 15px', borderBottom: '1px solid #ddd' }}>{member.email}</td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p style={{ color: '#666' }}>This club doesn't have any members yet.</p>
          )}
        </div>
      )}
    </div>
  );
};

// Helper function to get membership status color
const getMembershipStatusColor = (status) => {
  switch(status) {
    case 'member': return '#3498db';
    case 'pending': return '#f39c12';
    case 'rejected': return '#e74c3c';
    default: return '#95a5a6';
  }
};

// Helper function to get membership status text
const getMembershipStatusText = (status) => {
  switch(status) {
    case 'member': return 'Member';
    case 'pending': return 'Request Pending';
    case 'rejected': return 'Request Rejected';
    default: return 'Unknown Status';
  }
};

export default ClubDetail;
