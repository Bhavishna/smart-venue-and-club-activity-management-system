import React, { useState, useEffect } from 'react';
import { createItem, readItems, updateItem, deleteItem } from '../utils/localDB';

const TestLocalDB = () => {
  const [users, setUsers] = useState([]);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [currentId, setCurrentId] = useState(null);

  useEffect(() => {
    // Load data on component mount
    loadUsers();
  }, []);

  const loadUsers = () => {
    const userList = readItems('users');
    setUsers(userList);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (currentId) {
      // Update
      updateItem('users', currentId, { name, email });
      setCurrentId(null);
    } else {
      // Create
      createItem('users', { name, email });
    }
    
    // Reset form
    setName('');
    setEmail('');
    
    // Reload the list
    loadUsers();
  };

  const handleEdit = (user) => {
    setName(user.name);
    setEmail(user.email);
    setCurrentId(user.id);
  };

  const handleDelete = (id) => {
    deleteItem('users', id);
    loadUsers();
  };

  return (
    <div style={{ maxWidth: '800px', margin: '0 auto', padding: '20px' }}>
      <h2>{currentId ? 'Edit User' : 'Add User'}</h2>
      
      <form onSubmit={handleSubmit}>
        <div style={{ marginBottom: '10px' }}>
          <label htmlFor="name">Name:</label>
          <input
            type="text"
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
            style={{ marginLeft: '10px', padding: '5px' }}
          />
        </div>
        
        <div style={{ marginBottom: '10px' }}>
          <label htmlFor="email">Email:</label>
          <input
            type="email"
            id="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            style={{ marginLeft: '10px', padding: '5px' }}
          />
        </div>
        
        <button type="submit" style={{ padding: '8px 15px' }}>
          {currentId ? 'Update User' : 'Add User'}
        </button>
        
        {currentId && (
          <button
            type="button"
            onClick={() => {
              setCurrentId(null);
              setName('');
              setEmail('');
            }}
            style={{ marginLeft: '10px', padding: '8px 15px' }}
          >
            Cancel
          </button>
        )}
      </form>
      
      <h2>Users List</h2>
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr>
            <th style={{ textAlign: 'left', padding: '8px', borderBottom: '1px solid #ddd' }}>Name</th>
            <th style={{ textAlign: 'left', padding: '8px', borderBottom: '1px solid #ddd' }}>Email</th>
            <th style={{ textAlign: 'left', padding: '8px', borderBottom: '1px solid #ddd' }}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {users.map(user => (
            <tr key={user.id}>
              <td style={{ padding: '8px', borderBottom: '1px solid #ddd' }}>{user.name}</td>
              <td style={{ padding: '8px', borderBottom: '1px solid #ddd' }}>{user.email}</td>
              <td style={{ padding: '8px', borderBottom: '1px solid #ddd' }}>
                <button 
                  onClick={() => handleEdit(user)}
                  style={{ marginRight: '5px', padding: '5px 10px' }}
                >
                  Edit
                </button>
                <button 
                  onClick={() => handleDelete(user.id)}
                  style={{ padding: '5px 10px' }}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
          {users.length === 0 && (
            <tr>
              <td colSpan="3" style={{ textAlign: 'center', padding: '10px' }}>
                No users found. Add some users to see them here.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default TestLocalDB;
