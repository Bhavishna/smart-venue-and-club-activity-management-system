import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import useCollectionData from '../hooks/useCollection';

const CertificateVerify = () => {
  const { items: certificates } = useCollectionData('certificates');
  const { items: events } = useCollectionData('events');
  const { items: users } = useCollectionData('users');
  
  const [verificationCode, setVerificationCode] = useState('');
  const [verificationResult, setVerificationResult] = useState(null);
  const [error, setError] = useState('');
  
  // Handle verification
  const handleVerify = (e) => {
    e.preventDefault();
    
    if (!verificationCode.trim()) {
      setError('Please enter a verification code');
      setVerificationResult(null);
      return;
    }
    
    // Find certificate with matching verification code
    const certificate = certificates.find(cert => 
      cert.id.substring(0, 8).toUpperCase() === verificationCode.trim().toUpperCase()
    );
    
    if (certificate) {
      // Get related event and user
      const event = events.find(e => e.id === certificate.eventId);
      const user = users.find(u => u.id === certificate.studentId);
      
      if (event && user) {
        setVerificationResult({
          valid: true,
          certificateId: certificate.id,
          studentName: user.name,
          eventTitle: event.title,
          eventDate: new Date(event.date).toLocaleDateString(),
          issuedDate: certificate.generatedAt 
            ? new Date(certificate.generatedAt).toLocaleDateString()
            : 'Unknown'
        });
        setError('');
      } else {
        setVerificationResult({ valid: false });
        setError('Certificate references missing event or user data');
      }
    } else {
      setVerificationResult({ valid: false });
      setError('Invalid verification code. Certificate not found.');
    }
  };
  
  return (
    <div style={{ 
      maxWidth: '800px', 
      margin: '0 auto', 
      padding: '40px 20px' 
    }}>
      <div style={{ textAlign: 'center', marginBottom: '30px' }}>
        <h1>Certificate Verification</h1>
        <p style={{ color: '#666' }}>Verify the authenticity of a certificate by entering its verification code</p>
      </div>
      
      <div style={{ 
        backgroundColor: 'white',
        borderRadius: '8px',
        padding: '30px',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
        marginBottom: '30px'
      }}>
        <form onSubmit={handleVerify}>
          <div style={{ marginBottom: '20px' }}>
            <label htmlFor="verificationCode" style={{ 
              display: 'block', 
              marginBottom: '10px',
              fontWeight: 'bold' 
            }}>
              Certificate Verification Code
            </label>
            <input
              id="verificationCode"
              type="text"
              value={verificationCode}
              onChange={(e) => setVerificationCode(e.target.value)}
              placeholder="Enter 8-character code (e.g., AB12CD34)"
              style={{
                width: '100%',
                padding: '12px 15px',
                borderRadius: '4px',
                border: '1px solid #ddd',
                fontSize: '16px'
              }}
              maxLength={8}
            />
          </div>
          
          <button
            type="submit"
            style={{
              padding: '12px 25px',
              backgroundColor: '#9b59b6',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              fontSize: '16px',
              cursor: 'pointer',
              width: '100%'
            }}
          >
            Verify Certificate
          </button>
        </form>
      </div>
      
      {error && (
        <div style={{ 
          padding: '15px', 
          backgroundColor: '#f8d7da', 
          color: '#721c24',
          borderRadius: '5px',
          marginBottom: '20px'
        }}>
          {error}
        </div>
      )}
      
      {verificationResult && (
        <div style={{ 
          backgroundColor: 'white',
          borderRadius: '8px',
          padding: '30px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
          border: `2px solid ${verificationResult.valid ? '#d4edda' : '#f8d7da'}`
        }}>
          {verificationResult.valid ? (
            <>
              <div style={{ 
                backgroundColor: '#d4edda', 
                color: '#155724',
                padding: '15px',
                borderRadius: '5px',
                marginBottom: '20px',
                textAlign: 'center',
                fontWeight: 'bold',
                fontSize: '18px'
              }}>
                ✓ Certificate Verified Successfully
              </div>
              
              <h2 style={{ marginTop: 0 }}>Certificate Details</h2>
              
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <tbody>
                  <tr>
                    <td style={{ padding: '10px 0', fontWeight: 'bold', width: '150px' }}>Recipient:</td>
                    <td style={{ padding: '10px 0' }}>{verificationResult.studentName}</td>
                  </tr>
                  <tr>
                    <td style={{ padding: '10px 0', fontWeight: 'bold' }}>Event:</td>
                    <td style={{ padding: '10px 0' }}>{verificationResult.eventTitle}</td>
                  </tr>
                  <tr>
                    <td style={{ padding: '10px 0', fontWeight: 'bold' }}>Event Date:</td>
                    <td style={{ padding: '10px 0' }}>{verificationResult.eventDate}</td>
                  </tr>
                  <tr>
                    <td style={{ padding: '10px 0', fontWeight: 'bold' }}>Certificate ID:</td>
                    <td style={{ padding: '10px 0', fontFamily: 'monospace' }}>
                      {verificationCode.toUpperCase()}...{verificationResult.certificateId.slice(-4)}
                    </td>
                  </tr>
                  <tr>
                    <td style={{ padding: '10px 0', fontWeight: 'bold' }}>Issued On:</td>
                    <td style={{ padding: '10px 0' }}>{verificationResult.issuedDate}</td>
                  </tr>
                </tbody>
              </table>
            </>
          ) : (
            <div style={{ 
              backgroundColor: '#f8d7da', 
              color: '#721c24',
              padding: '15px',
              borderRadius: '5px',
              textAlign: 'center',
              fontWeight: 'bold',
              fontSize: '18px'
            }}>
              ✗ Certificate Verification Failed
            </div>
          )}
        </div>
      )}
      
      <div style={{ textAlign: 'center', marginTop: '30px' }}>
        <Link to="/" style={{ color: '#9b59b6', textDecoration: 'none' }}>
          Return to Home
        </Link>
      </div>
    </div>
  );
};

export default CertificateVerify;
