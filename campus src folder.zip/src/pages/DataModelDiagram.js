import React, { useEffect, useRef, useCallback } from 'react';
import { getDataModelSchema, getEntityRelationships } from '../utils/dataModel';

const DataModelDiagram = () => {
  const canvasRef = useRef(null);
  
  const schema = getDataModelSchema();
  const relationships = getEntityRelationships();

  // Convert drawDiagram to useCallback to avoid infinite re-rendering
  const drawDiagram = useCallback(() => {
    if (!canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    
    // Set canvas size
    canvas.width = 1200;
    canvas.height = 800;
    
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Configuration
    const entities = Object.keys(schema);
    const boxWidth = 200;
    const boxHeight = 200;
    const horizontalSpacing = 300;
    const verticalSpacing = 250;
    
    // Calculate positions for each entity
    const positions = {};
    const maxColumns = 3; // Number of boxes per row
    
    entities.forEach((entity, index) => {
      const column = index % maxColumns;
      const row = Math.floor(index / maxColumns);
      
      positions[entity] = {
        x: 100 + column * horizontalSpacing,
        y: 100 + row * verticalSpacing,
        width: boxWidth,
        height: boxHeight
      };
    });
    
    // Draw entity boxes
    entities.forEach(entity => {
      const pos = positions[entity];
      
      // Draw box
      ctx.fillStyle = '#f0f8ff';
      ctx.strokeStyle = '#333';
      ctx.lineWidth = 2;
      
      // Box with rounded corners
      ctx.beginPath();
      ctx.moveTo(pos.x + 10, pos.y);
      ctx.lineTo(pos.x + pos.width - 10, pos.y);
      ctx.quadraticCurveTo(pos.x + pos.width, pos.y, pos.x + pos.width, pos.y + 10);
      ctx.lineTo(pos.x + pos.width, pos.y + pos.height - 10);
      ctx.quadraticCurveTo(pos.x + pos.width, pos.y + pos.height, pos.x + pos.width - 10, pos.y + pos.height);
      ctx.lineTo(pos.x + 10, pos.y + pos.height);
      ctx.quadraticCurveTo(pos.x, pos.y + pos.height, pos.x, pos.y + pos.height - 10);
      ctx.lineTo(pos.x, pos.y + 10);
      ctx.quadraticCurveTo(pos.x, pos.y, pos.x + 10, pos.y);
      ctx.closePath();
      
      ctx.fill();
      ctx.stroke();
      
      // Entity title
      ctx.fillStyle = '#333';
      ctx.font = 'bold 16px Arial';
      ctx.textAlign = 'center';
      ctx.fillText(entity, pos.x + pos.width / 2, pos.y + 25);
      
      // Separator line
      ctx.beginPath();
      ctx.moveTo(pos.x, pos.y + 35);
      ctx.lineTo(pos.x + pos.width, pos.y + 35);
      ctx.stroke();
      
      // Entity fields
      const fields = Object.keys(schema[entity].schema);
      ctx.font = '12px Arial';
      ctx.textAlign = 'left';
      fields.slice(0, 8).forEach((field, idx) => {
        const fieldY = pos.y + 55 + idx * 16;
        if (fieldY < pos.y + pos.height - 10) {
          ctx.fillText(field, pos.x + 10, fieldY);
        }
      });
      
      if (fields.length > 8) {
        ctx.fillText('...', pos.x + 10, pos.y + pos.height - 15);
      }
    });
    
    // Draw relationships
    ctx.strokeStyle = '#999';
    ctx.lineWidth = 1;
    
    // Process all relationships
    Object.keys(relationships).forEach(sourceEntity => {
      const sourcePos = positions[sourceEntity];
      
      // Draw "hasMany" relationships
      if (relationships[sourceEntity].hasMany) {
        relationships[sourceEntity].hasMany.forEach(relation => {
          // Extract the target entity and foreign key
          const parts = relation.split('.');
          const targetEntity = parts[0];
          
          if (positions[targetEntity]) {
            const targetPos = positions[targetEntity];
            
            // Calculate start and end points
            const startX = sourcePos.x + sourcePos.width;
            const startY = sourcePos.y + sourcePos.height / 2;
            const endX = targetPos.x;
            const endY = targetPos.y + targetPos.height / 2;
            
            // Calculate control points for curved lines
            const controlX1 = startX + (endX - startX) * 0.4;
            const controlY1 = startY;
            const controlX2 = endX - (endX - startX) * 0.4;
            const controlY2 = endY;
            
            // Draw the line
            ctx.beginPath();
            ctx.moveTo(startX, startY);
            ctx.bezierCurveTo(controlX1, controlY1, controlX2, controlY2, endX, endY);
            ctx.stroke();
            
            // Draw arrow at end
            ctx.beginPath();
            ctx.moveTo(endX, endY);
            ctx.lineTo(endX - 10, endY - 5);
            ctx.lineTo(endX - 10, endY + 5);
            ctx.closePath();
            ctx.fillStyle = '#999';
            ctx.fill();
          }
        });
      }
    });
  }, [schema, relationships]);

  useEffect(() => {
    drawDiagram();
  }, [drawDiagram]); // Added drawDiagram to the dependency array

  return (
    <div style={{ padding: '20px' }}>
      <h1>Data Model Diagram</h1>
      <p>This is a simple visualization of the entity relationships in our data model:</p>
      
      <div style={{ overflowX: 'auto', marginBottom: '20px' }}>
        <canvas 
          ref={canvasRef} 
          style={{ 
            border: '1px solid #ddd',
            borderRadius: '5px',
            boxShadow: '0 2px 5px rgba(0,0,0,0.1)',
            backgroundColor: 'white'
          }}
        />
      </div>
      
      <h2>Entity Relationships</h2>
      
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '20px' }}>
        {Object.keys(relationships).map(entity => (
          <div key={entity} style={{ 
            padding: '15px', 
            border: '1px solid #ddd', 
            borderRadius: '5px',
            backgroundColor: '#f9f9f9'
          }}>
            <h3>{entity}</h3>
            
            {relationships[entity].belongsTo && (
              <div style={{ marginBottom: '10px' }}>
                <h4 style={{ margin: '5px 0' }}>Belongs To:</h4>
                <ul style={{ margin: '5px 0', paddingLeft: '20px' }}>
                  {relationships[entity].belongsTo.map((rel, i) => (
                    <li key={i}>{rel}</li>
                  ))}
                </ul>
              </div>
            )}
            
            {relationships[entity].hasMany && (
              <div>
                <h4 style={{ margin: '5px 0' }}>Has Many:</h4>
                <ul style={{ margin: '5px 0', paddingLeft: '20px' }}>
                  {relationships[entity].hasMany.map((rel, i) => (
                    <li key={i}>{rel}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default DataModelDiagram;
