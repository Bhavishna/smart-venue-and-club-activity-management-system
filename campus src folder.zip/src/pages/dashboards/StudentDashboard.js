import React from 'react';
import { Navigate } from 'react-router-dom';

const StudentDashboard = () => {
  // Redirect to the new student dashboard
  return <Navigate to="/student/dashboard" replace />;
};

export default StudentDashboard;
