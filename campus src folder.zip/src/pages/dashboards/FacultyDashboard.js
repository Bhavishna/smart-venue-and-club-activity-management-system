import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { Link } from 'react-router-dom';

const FacultyDashboard = () => {
  const { currentUser, logout } = useAuth();

  return (
    <div style={{ maxWidth: '1000px', margin: '0 auto', padding: '20px' }}>
      <div style={{ 
        display: 'flex', 
        justifyContent: 'space-between', 
        alignItems: 'center',
        marginBottom: '30px',
        backgroundColor: '#1565c0',
        padding: '15px',
        borderRadius: '5px',
        color: 'white'
      }}>
        <h1 style={{ margin: 0 }}>Faculty Dashboard</h1>
        <div>
          <span style={{ marginRight: '15px' }}>
            Welcome, {currentUser.name}
          </span>
          <button 
            onClick={logout}
            style={{ 
              padding: '8px 15px', 
              backgroundColor: '#e74c3c', 
              border: 'none', 
              color: 'white',
              borderRadius: '4px',
              cursor: 'pointer'
            }}
          >
            Logout
          </button>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '20px' }}>
        <div style={{ 
          padding: '20px', 
          backgroundColor: '#f9f9f9', 
          borderRadius: '5px',
          border: '1px solid #eee'
        }}>
          <h2 style={{ marginTop: 0, color: '#3498db' }}>My Courses</h2>
          <p>View and manage your assigned courses.</p>
          <Link to="#" style={{ 
            display: 'inline-block',
            padding: '8px 15px',
            backgroundColor: '#3498db',
            color: 'white',
            textDecoration: 'none',
            borderRadius: '4px'
          }}>
            View Courses
          </Link>
        </div>

        <div style={{ 
          padding: '20px', 
          backgroundColor: '#f9f9f9', 
          borderRadius: '5px',
          border: '1px solid #eee'
        }}>
          <h2 style={{ marginTop: 0, color: '#2ecc71' }}>Assignments</h2>
          <p>Create and manage assignments for your courses.</p>
          <Link to="#" style={{ 
            display: 'inline-block',
            padding: '8px 15px',
            backgroundColor: '#2ecc71',
            color: 'white',
            textDecoration: 'none',
            borderRadius: '4px'
          }}>
            Manage Assignments
          </Link>
        </div>

        <div style={{ 
          padding: '20px', 
          backgroundColor: '#f9f9f9', 
          borderRadius: '5px',
          border: '1px solid #eee'
        }}>
          <h2 style={{ marginTop: 0, color: '#9b59b6' }}>Student Grades</h2>
          <p>View and update student grades.</p>
          <Link to="#" style={{ 
            display: 'inline-block',
            padding: '8px 15px',
            backgroundColor: '#9b59b6',
            color: 'white',
            textDecoration: 'none',
            borderRadius: '4px'
          }}>
            Grade Students
          </Link>
        </div>

        <div style={{ 
          padding: '20px', 
          backgroundColor: '#f9f9f9', 
          borderRadius: '5px',
          border: '1px solid #eee'
        }}>
          <h2 style={{ marginTop: 0, color: '#e67e22' }}>Schedule</h2>
          <p>View your teaching schedule and class timings.</p>
          <Link to="#" style={{ 
            display: 'inline-block',
            padding: '8px 15px',
            backgroundColor: '#e67e22',
            color: 'white',
            textDecoration: 'none',
            borderRadius: '4px'
          }}>
            View Schedule
          </Link>
        </div>
      </div>

      <div style={{ 
        marginTop: '30px',
        padding: '20px',
        backgroundColor: '#e8f5e9',
        borderRadius: '5px',
        border: '1px solid #c8e6c9'
      }}>
        <h2 style={{ marginTop: 0, color: '#2e7d32' }}>Upcoming Classes</h2>
        <ul style={{ paddingLeft: '20px' }}>
          <li style={{ marginBottom: '10px' }}>
            <strong>Introduction to Computer Science</strong> - Monday, 10:00 AM
          </li>
          <li style={{ marginBottom: '10px' }}>
            <strong>Data Structures</strong> - Tuesday, 2:00 PM
          </li>
          <li style={{ marginBottom: '10px' }}>
            <strong>Algorithms</strong> - Wednesday, 11:30 AM
          </li>
        </ul>
      </div>
    </div>
  );
};

export default FacultyDashboard;
