// src/pages/dashboards/StudentCoordinatorDashboard.js
import React from 'react';
import { Navigate } from 'react-router-dom';

const StudentCoordinatorDashboard = () => {
  // Redirect to the new coordinator dashboard
  return <Navigate to="/coordinator/dashboard" replace />;
};

export default StudentCoordinatorDashboard;
