import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import useCollectionData from '../../hooks/useCollection';

const RegistrationsManagement = () => {
  const { currentUser } = useAuth();
  const { items: events } = useCollectionData('events');
  const { items: clubs } = useCollectionData('clubs');
  const { items: registrations, deleteItem: deleteRegistration } = useCollectionData('event_registrations');
  const { items: users } = useCollectionData('users');
  
  const [myEvents, setMyEvents] = useState([]);
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [registrationsList, setRegistrationsList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [confirmRemove, setConfirmRemove] = useState(null);
  const [successMessage, setSuccessMessage] = useState('');
  const [error, setError] = useState(null);
  
  // Get clubs where the current user is a coordinator
  useEffect(() => {
    if (currentUser && clubs.length) {
      const coordinatorClubs = clubs.filter(
        club => club.studentCoordinatorId === currentUser.id
      );
      
      // Get events for these clubs
      if (coordinatorClubs.length > 0 && events.length > 0) {
        const clubIds = coordinatorClubs.map(club => club.id);
        const clubEvents = events.filter(event => 
          clubIds.includes(event.clubId)
        ).map(event => {
          const club = clubs.find(c => c.id === event.clubId);
          return {
            ...event,
            clubName: club ? club.name : 'Unknown Club',
          };
        });
        
        // Sort events by date (most recent first)
        clubEvents.sort((a, b) => new Date(b.date) - new Date(a.date));
        
        setMyEvents(clubEvents);
        
        // Select first event by default if available
        if (clubEvents.length > 0 && !selectedEvent) {
          setSelectedEvent(clubEvents[0]);
        }
      }
      
      setLoading(false);
    }
  }, [currentUser, clubs, events, selectedEvent]);
  
  // Get registrations for selected event
  useEffect(() => {
    if (selectedEvent && registrations.length > 0 && users.length > 0) {
      const eventRegs = registrations.filter(reg => reg.eventId === selectedEvent.id);
      
      const registrationsWithUsers = eventRegs.map(reg => {
        const user = users.find(u => u.id === reg.studentId);
        return {
          id: reg.id,
          studentId: reg.studentId,
          name: user ? user.name : 'Unknown User',
          email: user ? user.email : '',
          registrationDate: reg.createdAt
        };
      });
      
      // Sort by name
      registrationsWithUsers.sort((a, b) => a.name.localeCompare(b.name));
      
      setRegistrationsList(registrationsWithUsers);
    } else {
      setRegistrationsList([]);
    }
  }, [selectedEvent, registrations, users]);
  
  // Handle event selection
  const handleEventSelect = (event) => {
    setSelectedEvent(event);
  };
  
  // Handle registration removal
  const handleRemoveRegistration = async () => {
    if (!confirmRemove) return;
    
    try {
      await deleteRegistration(confirmRemove.id);
      
      // Update local state
      setRegistrationsList(prev => 
        prev.filter(reg => reg.id !== confirmRemove.id)
      );
      
      setSuccessMessage(`Removed ${confirmRemove.name} from the event`);
      setTimeout(() => setSuccessMessage(''), 3000);
      
      // Close confirmation modal
      setConfirmRemove(null);
    } catch (err) {
      setError('Failed to remove registration');
    }
  };
  
  if (loading) {
    return <div style={{ textAlign: 'center', padding: '50px' }}>Loading...</div>;
  }
  
  if (myEvents.length === 0) {
    return (
      <div>
        <h1>Registrations Management</h1>
        <div style={{ 
          padding: '20px', 
          backgroundColor: '#fff3cd', 
          borderRadius: '5px' 
        }}>
          <p style={{ margin: '0', fontWeight: 'bold' }}>
            You don't have any events as a coordinator.
          </p>
          <p style={{ margin: '10px 0 0 0' }}>
            <Link to="/coordinator/events/create" style={{ color: '#856404' }}>Create an event</Link> to start managing registrations.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div>
      <h1>Registrations Management</h1>
      
      {successMessage && (
        <div style={{ 
          padding: '15px', 
          backgroundColor: '#d4edda', 
          color: '#155724',
          borderRadius: '5px',
          marginBottom: '20px'
        }}>
          {successMessage}
        </div>
      )}
      
      {error && (
        <div style={{ 
          padding: '15px', 
          backgroundColor: '#f8d7da', 
          color: '#721c24',
          borderRadius: '5px',
          marginBottom: '20px'
        }}>
          {error}
        </div>
      )}
      
      <div style={{ display: 'flex', gap: '20px', flexWrap: 'wrap' }}>
        {/* Event selection sidebar */}
        <div style={{ 
          width: '300px',
          backgroundColor: 'white',
          borderRadius: '8px',
          padding: '20px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
        }}>
          <h2 style={{ marginTop: 0, marginBottom: '15px' }}>My Events</h2>
          
          <div>
            {myEvents.map(event => (
              <button
                key={event.id}
                onClick={() => handleEventSelect(event)}
                style={{
                  display: 'block',
                  width: '100%',
                  textAlign: 'left',
                  padding: '12px 15px',
                  marginBottom: '10px',
                  backgroundColor: selectedEvent && selectedEvent.id === event.id ? '#5e35b1' : '#f8f9fa',
                  color: selectedEvent && selectedEvent.id === event.id ? 'white' : '#333',
                  border: '1px solid #ddd',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
              >
                <div style={{ fontWeight: 'bold' }}>{event.title}</div>
                <div style={{ fontSize: '12px', marginTop: '5px' }}>
                  {new Date(event.date).toLocaleDateString()} | {event.clubName}
                </div>
                <div style={{ 
                  fontSize: '12px', 
                  marginTop: '5px',
                  padding: '2px 8px',
                  backgroundColor: event.approved ? '#d4edda' : '#f8d7da',
                  color: event.approved ? '#155724' : '#721c24',
                  display: 'inline-block',
                  borderRadius: '4px'
                }}>
                  {event.approved ? 'Approved' : 'Pending Approval'}
                </div>
              </button>
            ))}
            
            <Link to="/coordinator/events" style={{
              display: 'block',
              width: '100%',
              padding: '10px',
              textAlign: 'center',
              backgroundColor: '#f0f0f0',
              color: '#333',
              textDecoration: 'none',
              borderRadius: '4px',
              marginTop: '15px'
            }}>
              View All Events
            </Link>
          </div>
        </div>
        
        {/* Registrations list */}
        <div style={{ 
          flex: 1,
          backgroundColor: 'white',
          borderRadius: '8px',
          padding: '20px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
        }}>
          {selectedEvent ? (
            <>
              <div style={{ marginBottom: '20px' }}>
                <h2 style={{ margin: '0 0 10px 0' }}>{selectedEvent.title}</h2>
                <div style={{ color: '#666' }}>
                  <p style={{ margin: '0 0 5px 0' }}>
                    Date: {new Date(selectedEvent.date).toLocaleDateString()}
                  </p>
                  <p style={{ margin: '0 0 15px 0' }}>
                    Club: {selectedEvent.clubName}
                  </p>
                  
                  <Link to={`/coordinator/events/${selectedEvent.id}`} style={{
                    display: 'inline-block',
                    padding: '5px 10px',
                    backgroundColor: '#5e35b1',
                    color: 'white',
                    textDecoration: 'none',
                    borderRadius: '4px',
                    fontSize: '14px'
                  }}>
                    View Event Details
                  </Link>
                </div>
              </div>
              
              <div style={{ 
                display: 'flex', 
                justifyContent: 'space-between', 
                alignItems: 'center',
                marginBottom: '15px',
                backgroundColor: '#f8f9fa',
                padding: '10px 15px',
                borderRadius: '4px'
              }}>
                <h3 style={{ margin: 0 }}>Registered Participants</h3>
                <span style={{ 
                  backgroundColor: '#5e35b1',
                  color: 'white',
                  padding: '5px 10px',
                  borderRadius: '20px',
                  fontSize: '14px'
                }}>
                  {registrationsList.length} Registered
                </span>
              </div>
              
              {!selectedEvent.approved ? (
                <div style={{ 
                  padding: '15px', 
                  backgroundColor: '#fff3cd', 
                  color: '#856404',
                  borderRadius: '5px',
                  marginBottom: '20px'
                }}>
                  <p style={{ margin: '0', fontWeight: 'bold' }}>Event Not Approved</p>
                  <p style={{ margin: '5px 0 0 0' }}>
                    This event is awaiting faculty approval. Students cannot register until it is approved.
                  </p>
                </div>
              ) : registrationsList.length === 0 ? (
                <div style={{ textAlign: 'center', padding: '30px 0', color: '#666' }}>
                  <p>No students have registered for this event yet.</p>
                </div>
              ) : (
                <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                  <thead>
                    <tr style={{ backgroundColor: '#f8f9fa' }}>
                      <th style={{ padding: '12px 15px', textAlign: 'left', borderBottom: '1px solid #ddd' }}>Name</th>
                      <th style={{ padding: '12px 15px', textAlign: 'left', borderBottom: '1px solid #ddd' }}>Email</th>
                      <th style={{ padding: '12px 15px', textAlign: 'left', borderBottom: '1px solid #ddd' }}>Registration Date</th>
                      <th style={{ padding: '12px 15px', textAlign: 'right', borderBottom: '1px solid #ddd' }}>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {registrationsList.map(registration => (
                      <tr key={registration.id}>
                        <td style={{ padding: '12px 15px', borderBottom: '1px solid #ddd' }}>{registration.name}</td>
                        <td style={{ padding: '12px 15px', borderBottom: '1px solid #ddd' }}>{registration.email}</td>
                        <td style={{ padding: '12px 15px', borderBottom: '1px solid #ddd' }}>
                          {new Date(registration.registrationDate).toLocaleString()}
                        </td>
                        <td style={{ padding: '12px 15px', borderBottom: '1px solid #ddd', textAlign: 'right' }}>
                          <button
                            onClick={() => setConfirmRemove(registration)}
                            style={{
                              padding: '5px 10px',
                              backgroundColor: '#f8f9fa',
                              border: '1px solid #ddd',
                              borderRadius: '4px',
                              cursor: 'pointer'
                            }}
                          >
                            Remove
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </>
          ) : (
            <div style={{ textAlign: 'center', padding: '50px 0', color: '#666' }}>
              <p>Select an event to view its registrations</p>
            </div>
          )}
        </div>
      </div>
      
      {/* Confirmation Modal */}
      {confirmRemove && (
        <div style={{ 
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000
        }}>
          <div style={{ 
            backgroundColor: 'white',
            borderRadius: '8px',
            padding: '20px',
            width: '400px',
            maxWidth: '90%'
          }}>
            <h2 style={{ marginTop: 0 }}>Confirm Removal</h2>
            <p>Are you sure you want to remove this participant from the event?</p>
            <p><strong>Name:</strong> {confirmRemove.name}</p>
            
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px', marginTop: '20px' }}>
              <button 
                onClick={() => setConfirmRemove(null)}
                style={{
                  padding: '8px 15px',
                  backgroundColor: '#f0f0f0',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
              >
                Cancel
              </button>
              <button 
                onClick={handleRemoveRegistration}
                style={{
                  padding: '8px 15px',
                  backgroundColor: '#e74c3c',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
              >
                Remove Participant
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default RegistrationsManagement;
