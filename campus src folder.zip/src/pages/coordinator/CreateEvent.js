import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import useCollectionData from '../../hooks/useCollection';

const CreateEvent = () => {
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const preselectedClubId = searchParams.get('club');

  const { items: clubs } = useCollectionData('clubs');
  const { items: venues } = useCollectionData('venues');
  const { addItem } = useCollectionData('events');

  const [myClubs, setMyClubs] = useState([]);
  const [formData, setFormData] = useState({
    title: '',
    desc: '',
    date: '',
    time: '',
    venueId: '',
    clubId: preselectedClubId || '',
    requiresApproval: true,
    approved: false
  });
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  // Get clubs where user is coordinator
  useEffect(() => {
    if (currentUser && clubs.length) {
      const coordinatorClubs = clubs.filter(
        club => club.studentCoordinatorId === currentUser.id
      );
      setMyClubs(coordinatorClubs);
      
      // If no club is preselected and we have clubs, select the first one
      if (!formData.clubId && coordinatorClubs.length > 0) {
        setFormData(prev => ({
          ...prev,
          clubId: coordinatorClubs[0].id
        }));
      }
    }
  }, [currentUser, clubs, formData.clubId]);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
    
    // Clear error for this field
    if (errors[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: undefined
      }));
    }
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.title.trim()) newErrors.title = 'Title is required';
    if (!formData.desc.trim()) newErrors.desc = 'Description is required';
    if (!formData.date) newErrors.date = 'Date is required';
    if (!formData.time) newErrors.time = 'Time is required';
    if (!formData.venueId) newErrors.venueId = 'Venue is required';
    if (!formData.clubId) newErrors.clubId = 'Club is required';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    setLoading(true);
    
    try {
      // Create new event
      await addItem(formData);
      setSuccess(true);
      
      // Reset form after 2 seconds and navigate to events list
      setTimeout(() => {
        navigate('/coordinator/events');
      }, 2000);
    } catch (error) {
      setErrors({ submit: error.message || 'Failed to create event' });
    } finally {
      setLoading(false);
    }
  };

  if (myClubs.length === 0) {
    return (
      <div style={{ maxWidth: '600px', margin: '0 auto', padding: '20px' }}>
        <h1>Create Event</h1>
        <div style={{ 
          padding: '20px', 
          backgroundColor: '#fff3cd', 
          borderRadius: '5px',
          marginTop: '20px'
        }}>
          <p style={{ margin: '0', fontWeight: 'bold' }}>
            You are not assigned as a coordinator for any club.
          </p>
          <p style={{ margin: '10px 0 0 0' }}>
            You need to be a coordinator of a club to create events.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div style={{ maxWidth: '800px', margin: '0 auto' }}>
      <h1>Create New Event</h1>
      
      {success && (
        <div style={{ 
          padding: '15px', 
          backgroundColor: '#d4edda', 
          color: '#155724',
          borderRadius: '5px',
          marginBottom: '20px'
        }}>
          Event created successfully! Redirecting to events list...
        </div>
      )}
      
      {errors.submit && (
        <div style={{ 
          padding: '15px', 
          backgroundColor: '#f8d7da', 
          color: '#721c24',
          borderRadius: '5px',
          marginBottom: '20px'
        }}>
          {errors.submit}
        </div>
      )}
      
      <div style={{ 
        backgroundColor: 'white',
        borderRadius: '8px',
        padding: '20px',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
      }}>
        <form onSubmit={handleSubmit}>
          <div style={{ marginBottom: '20px' }}>
            <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
              Club <span style={{ color: 'red' }}>*</span>
            </label>
            <select
              name="clubId"
              value={formData.clubId}
              onChange={handleChange}
              style={{ 
                width: '100%', 
                padding: '10px', 
                borderRadius: '4px',
                border: errors.clubId ? '1px solid red' : '1px solid #ddd'
              }}
            >
              <option value="">Select a club</option>
              {myClubs.map(club => (
                <option key={club.id} value={club.id}>{club.name}</option>
              ))}
            </select>
            {errors.clubId && <p style={{ color: 'red', margin: '5px 0 0 0', fontSize: '14px' }}>{errors.clubId}</p>}
          </div>
          
          <div style={{ marginBottom: '20px' }}>
            <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
              Event Title <span style={{ color: 'red' }}>*</span>
            </label>
            <input
              type="text"
              name="title"
              value={formData.title}
              onChange={handleChange}
              placeholder="Enter event title"
              style={{ 
                width: '100%', 
                padding: '10px', 
                borderRadius: '4px',
                border: errors.title ? '1px solid red' : '1px solid #ddd'
              }}
            />
            {errors.title && <p style={{ color: 'red', margin: '5px 0 0 0', fontSize: '14px' }}>{errors.title}</p>}
          </div>
          
          <div style={{ marginBottom: '20px' }}>
            <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
              Description <span style={{ color: 'red' }}>*</span>
            </label>
            <textarea
              name="desc"
              value={formData.desc}
              onChange={handleChange}
              placeholder="Enter event description"
              rows="4"
              style={{ 
                width: '100%', 
                padding: '10px', 
                borderRadius: '4px',
                border: errors.desc ? '1px solid red' : '1px solid #ddd',
                resize: 'vertical'
              }}
            />
            {errors.desc && <p style={{ color: 'red', margin: '5px 0 0 0', fontSize: '14px' }}>{errors.desc}</p>}
          </div>
          
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', marginBottom: '20px' }}>
            <div>
              <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
                Date <span style={{ color: 'red' }}>*</span>
              </label>
              <input
                type="date"
                name="date"
                value={formData.date}
                onChange={handleChange}
                min={new Date().toISOString().split('T')[0]} // Prevent past dates
                style={{ 
                  width: '100%', 
                  padding: '10px', 
                  borderRadius: '4px',
                  border: errors.date ? '1px solid red' : '1px solid #ddd'
                }}
              />
              {errors.date && <p style={{ color: 'red', margin: '5px 0 0 0', fontSize: '14px' }}>{errors.date}</p>}
            </div>
            
            <div>
              <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
                Time <span style={{ color: 'red' }}>*</span>
              </label>
              <input
                type="text"
                name="time"
                value={formData.time}
                onChange={handleChange}
                placeholder="e.g. 14:00-16:00"
                style={{ 
                  width: '100%', 
                  padding: '10px', 
                  borderRadius: '4px',
                  border: errors.time ? '1px solid red' : '1px solid #ddd'
                }}
              />
              {errors.time && <p style={{ color: 'red', margin: '5px 0 0 0', fontSize: '14px' }}>{errors.time}</p>}
            </div>
          </div>
          
          <div style={{ marginBottom: '20px' }}>
            <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>
              Venue <span style={{ color: 'red' }}>*</span>
            </label>
            <select
              name="venueId"
              value={formData.venueId}
              onChange={handleChange}
              style={{ 
                width: '100%', 
                padding: '10px', 
                borderRadius: '4px',
                border: errors.venueId ? '1px solid red' : '1px solid #ddd'
              }}
            >
              <option value="">Select a venue</option>
              {venues.map(venue => (
                <option key={venue.id} value={venue.id}>
                  {venue.name} (Capacity: {venue.capacity})
                </option>
              ))}
            </select>
            {errors.venueId && <p style={{ color: 'red', margin: '5px 0 0 0', fontSize: '14px' }}>{errors.venueId}</p>}
          </div>
          
          <div style={{ marginBottom: '30px' }}>
            <label style={{ display: 'flex', alignItems: 'center', cursor: 'pointer' }}>
              <input
                type="checkbox"
                name="requiresApproval"
                checked={formData.requiresApproval}
                onChange={handleChange}
                style={{ marginRight: '10px' }}
              />
              <span>Requires Faculty Approval (recommended)</span>
            </label>
            <p style={{ margin: '5px 0 0 0', color: '#666', fontSize: '14px' }}>
              Events that require approval will be visible only after faculty approval.
            </p>
          </div>
          
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <button
              type="button"
              onClick={() => navigate('/coordinator/events')}
              style={{ 
                padding: '10px 20px',
                backgroundColor: '#f0f0f0',
                border: 'none',
                borderRadius: '4px',
                cursor: 'pointer'
              }}
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              style={{ 
                padding: '10px 20px',
                backgroundColor: '#5e35b1',
                color: 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: loading ? 'not-allowed' : 'pointer',
                opacity: loading ? 0.7 : 1
              }}
            >
              {loading ? 'Creating...' : 'Create Event'}
            </button>
          </div>
        </form>
      </div>
      
      <div style={{ 
        marginTop: '20px',
        padding: '15px',
        backgroundColor: '#e8f4fd',
        borderRadius: '5px',
        fontSize: '14px'
      }}>
        <p style={{ margin: '0', fontWeight: 'bold' }}>Note:</p>
        <p style={{ margin: '5px 0 0 0' }}>
          By default, events require faculty approval. Once approved, students will be able to register.
        </p>
      </div>
    </div>
  );
};

export default CreateEvent;
