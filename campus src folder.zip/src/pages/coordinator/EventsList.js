import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import useCollectionData from '../../hooks/useCollection';

const EventsList = () => {
  const { currentUser } = useAuth();
  const { items: clubs } = useCollectionData('clubs');
  const { items: events } = useCollectionData('events');
  const { items: venues } = useCollectionData('venues');
  const { items: eventRegistrations } = useCollectionData('event_registrations');
  
  const [myEvents, setMyEvents] = useState([]);
  const [filter, setFilter] = useState('all'); // 'all', 'upcoming', 'past', 'pending'
  const [clubFilter, setClubFilter] = useState('all');
  const [myClubs, setMyClubs] = useState([]);
  
  // Get clubs where the current user is a coordinator
  useEffect(() => {
    if (currentUser && clubs.length) {
      const coordinatorClubs = clubs.filter(
        club => club.studentCoordinatorId === currentUser.id
      );
      setMyClubs(coordinatorClubs);
    }
  }, [currentUser, clubs]);
  
  // Get events organized by the coordinator's clubs
  useEffect(() => {
    if (myClubs.length && events.length && venues.length) {
      const clubIds = myClubs.map(club => club.id);
      const coordinatorEvents = events.filter(event => 
        clubIds.includes(event.clubId)
      ).map(event => {
        const club = clubs.find(c => c.id === event.clubId);
        const venue = venues.find(v => v.id === event.venueId);
        const registrations = eventRegistrations.filter(reg => reg.eventId === event.id).length;
        
        return {
          ...event,
          clubName: club ? club.name : 'Unknown Club',
          venueName: venue ? venue.name : 'Unknown Venue',
          registrationCount: registrations
        };
      });
      
      setMyEvents(coordinatorEvents);
    }
  }, [myClubs, events, venues, clubs, eventRegistrations]);
  
  // Apply filters
  const getFilteredEvents = () => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    let filtered = [...myEvents];
    
    // Apply status filter
    switch (filter) {
      case 'upcoming':
        filtered = filtered.filter(event => {
          const eventDate = new Date(event.date);
          return eventDate >= today;
        });
        break;
      case 'past':
        filtered = filtered.filter(event => {
          const eventDate = new Date(event.date);
          return eventDate < today;
        });
        break;
      case 'pending':
        filtered = filtered.filter(event => !event.approved);
        break;
      case 'approved':
        filtered = filtered.filter(event => event.approved);
        break;
      default:
        // all events, no filter
    }
    
    // Apply club filter
    if (clubFilter !== 'all') {
      filtered = filtered.filter(event => event.clubId === clubFilter);
    }
    
    // Sort by date, newest first
    return filtered.sort((a, b) => new Date(b.date) - new Date(a.date));
  };
  
  const filteredEvents = getFilteredEvents();

  return (
    <div>
      <div style={{ 
        display: 'flex', 
        justifyContent: 'space-between', 
        alignItems: 'center',
        marginBottom: '20px'
      }}>
        <h1 style={{ margin: 0 }}>My Events</h1>
        
        <Link to="/coordinator/events/create" style={{
          display: 'inline-block',
          padding: '10px 20px',
          backgroundColor: '#5e35b1',
          color: 'white',
          textDecoration: 'none',
          borderRadius: '4px'
        }}>
          Create New Event
        </Link>
      </div>
      
      <div style={{ 
        display: 'flex', 
        gap: '15px',
        marginBottom: '20px',
        backgroundColor: 'white',
        padding: '15px',
        borderRadius: '8px',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
        flexWrap: 'wrap'
      }}>
        <div>
          <label style={{ marginRight: '8px' }}>Status:</label>
          <select 
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            style={{ 
              padding: '8px', 
              borderRadius: '4px', 
              border: '1px solid #ddd' 
            }}
          >
            <option value="all">All Events</option>
            <option value="upcoming">Upcoming</option>
            <option value="past">Past Events</option>
            <option value="pending">Pending Approval</option>
            <option value="approved">Approved</option>
          </select>
        </div>
        
        <div>
          <label style={{ marginRight: '8px' }}>Club:</label>
          <select 
            value={clubFilter}
            onChange={(e) => setClubFilter(e.target.value)}
            style={{ 
              padding: '8px', 
              borderRadius: '4px', 
              border: '1px solid #ddd' 
            }}
          >
            <option value="all">All Clubs</option>
            {myClubs.map(club => (
              <option key={club.id} value={club.id}>{club.name}</option>
            ))}
          </select>
        </div>
      </div>
      
      {myClubs.length === 0 ? (
        <div style={{
          padding: '20px',
          background: '#fff3cd',
          borderRadius: '5px'
        }}>
          <p style={{ margin: '0', fontWeight: 'bold' }}>
            You are not assigned as a coordinator for any club yet.
          </p>
        </div>
      ) : filteredEvents.length === 0 ? (
        <div style={{
          padding: '30px',
          textAlign: 'center',
          backgroundColor: 'white',
          borderRadius: '8px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
        }}>
          <p style={{ fontSize: '18px', margin: '0 0 15px 0' }}>
            No events found matching your criteria.
          </p>
          <Link to="/coordinator/events/create" style={{
            display: 'inline-block',
            padding: '10px 20px',
            backgroundColor: '#5e35b1',
            color: 'white',
            textDecoration: 'none',
            borderRadius: '4px'
          }}>
            Create an Event
          </Link>
        </div>
      ) : (
        <div style={{ 
          display: 'grid', 
          gridTemplateColumns: 'repeat(auto-fill, minmax(350px, 1fr))', 
          gap: '20px'
        }}>
          {filteredEvents.map(event => {
            const eventDate = new Date(event.date);
            const isPast = eventDate < new Date();
            
            return (
              <div key={event.id} style={{ 
                backgroundColor: 'white',
                borderRadius: '8px',
                overflow: 'hidden',
                boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
                // src/pages/coordinator/EventsList.js (continued)
                display: 'flex',
                flexDirection: 'column'
              }}>
                <div style={{ 
                  padding: '15px', 
                  borderBottom: '1px solid #eee',
                  backgroundColor: isPast ? '#f9f9f9' : '#f0f6ff'
                }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                    <h2 style={{ margin: '0 0 5px 0', fontSize: '18px' }}>{event.title}</h2>
                    <span style={{ 
                      display: 'inline-block',
                      padding: '4px 8px',
                      backgroundColor: event.approved ? '#27ae60' : '#e74c3c',
                      color: 'white',
                      borderRadius: '4px',
                      fontSize: '12px'
                    }}>
                      {event.approved ? 'Approved' : 'Pending'}
                    </span>
                  </div>
                  <p style={{ margin: '0 0 5px 0', color: '#666' }}>
                    Club: {event.clubName}
                  </p>
                  <p style={{ margin: '0', color: '#666' }}>
                    {eventDate.toLocaleDateString()} at {event.time}
                  </p>
                </div>
                
                <div style={{ padding: '15px', flex: '1' }}>
                  <div style={{ 
                    display: 'flex', 
                    justifyContent: 'space-between',
                    marginBottom: '15px'
                  }}>
                    <div>
                      <p style={{ margin: '0 0 5px 0', fontWeight: 'bold' }}>Venue:</p>
                      <p style={{ margin: '0', color: '#666' }}>{event.venueName}</p>
                    </div>
                    <div style={{ textAlign: 'right' }}>
                      <p style={{ margin: '0 0 5px 0', fontWeight: 'bold' }}>Registrations:</p>
                      <p style={{ margin: '0', color: '#666' }}>{event.registrationCount}</p>
                    </div>
                  </div>
                  
                  <p style={{ margin: '0 0 15px 0', fontSize: '14px', color: '#666' }}>
                    {event.desc.length > 100 ? `${event.desc.substring(0, 100)}...` : event.desc}
                  </p>
                </div>
                
                <div style={{ 
                  display: 'grid',
                  gridTemplateColumns: '1fr 1fr',
                  gap: '10px',
                  padding: '15px',
                  borderTop: '1px solid #eee'
                }}>
                  <Link to={`/coordinator/events/${event.id}`} style={{
                    display: 'block',
                    padding: '8px 0',
                    backgroundColor: '#5e35b1',
                    color: 'white',
                    textAlign: 'center',
                    textDecoration: 'none',
                    borderRadius: '4px',
                    fontSize: '14px'
                  }}>
                    View Details
                  </Link>
                  <Link to={`/coordinator/attendance/${event.id}`} style={{
                    display: 'block',
                    padding: '8px 0',
                    backgroundColor: isPast ? '#27ae60' : '#f0f0f0',
                    color: isPast ? 'white' : '#999',
                    textAlign: 'center',
                    textDecoration: 'none',
                    borderRadius: '4px',
                    fontSize: '14px',
                    cursor: isPast ? 'pointer' : 'not-allowed'
                  }}>
                    {isPast ? 'Manage Attendance' : 'Future Event'}
                  </Link>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default EventsList;
