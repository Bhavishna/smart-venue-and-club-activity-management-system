import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import useCollectionData from '../../hooks/useCollection';

const EventDetails = () => {
  const { eventId } = useParams();
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  
  const { items: events, updateItem, deleteItem } = useCollectionData('events');
  const { items: clubs } = useCollectionData('clubs');
  const { items: venues } = useCollectionData('venues');
  const { items: registrations, deleteItem: deleteRegistration } = useCollectionData('event_registrations');
  const { items: attendanceRecords } = useCollectionData('attendance_records');
  const { items: users } = useCollectionData('users');
  
  const [event, setEvent] = useState(null);
  const [registeredUsers, setRegisteredUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [isConfirmCancelModalOpen, setIsConfirmCancelModalOpen] = useState(false);
  const [userToRemove, setUserToRemove] = useState(null);
  
  useEffect(() => {
    if (events.length > 0 && clubs.length > 0 && venues.length > 0) {
      const currentEvent = events.find(e => e.id === eventId);
      
      if (currentEvent) {
        // Check if user has permission to view this event
        const club = clubs.find(c => c.id === currentEvent.clubId);
        
        if (club && club.studentCoordinatorId === currentUser.id) {
          const venue = venues.find(v => v.id === currentEvent.venueId);
          
          setEvent({
            ...currentEvent,
            clubName: club ? club.name : 'Unknown Club',
            venueName: venue ? venue.name : 'Unknown Venue',
          });
        } else {
          setError("You don't have permission to view this event");
        }
      } else {
        setError("Event not found");
      }
      
      setLoading(false);
    }
  }, [events, clubs, venues, eventId, currentUser.id]);
  
  // Get registered users
  useEffect(() => {
    if (event && registrations && users.length > 0) {
      const eventRegs = registrations.filter(reg => reg.eventId === eventId);
      
      const usersWithAttendance = eventRegs.map(reg => {
        const user = users.find(u => u.id === reg.studentId);
        const attendance = attendanceRecords.find(
          a => a.eventId === eventId && a.studentId === reg.studentId
        );
        
        return {
          registration: reg,
          user: user || { name: 'Unknown User' },
          attendance
        };
      });
      
      setRegisteredUsers(usersWithAttendance);
    }
  }, [event, registrations, users, eventId, attendanceRecords]);
  
  const handleDeleteEvent = async () => {
    try {
      await deleteItem(eventId);
      navigate('/coordinator/events');
    } catch (error) {
      setError("Failed to delete event");
    }
  };
  
  const handleCancelRegistration = async () => {
    if (!userToRemove) return;
    
    try {
      await deleteRegistration(userToRemove.registration.id);
      setRegisteredUsers(prev => 
        prev.filter(item => item.registration.id !== userToRemove.registration.id)
      );
      setIsConfirmCancelModalOpen(false);
      setUserToRemove(null);
    } catch (error) {
      setError("Failed to cancel registration");
    }
  };
  
  if (loading) {
    return <div style={{ textAlign: 'center', padding: '50px' }}>Loading...</div>;
  }
  
  if (error) {
    return (
      <div style={{
        padding: '20px',
        backgroundColor: '#f8d7da',
        color: '#721c24',
        borderRadius: '5px',
        marginBottom: '20px'
      }}>
        <p style={{ margin: '0', fontWeight: 'bold' }}>{error}</p>
        <Link to="/coordinator/events" style={{ color: '#721c24', textDecoration: 'underline' }}>
          Return to Events
        </Link>
      </div>
    );
  }
  
  if (!event) {
    return <div style={{ textAlign: 'center', padding: '50px' }}>Event not found</div>;
  }
  
  const eventDate = new Date(event.date);
  const isPast = eventDate < new Date();
  const isSameDay = eventDate.toDateString() === new Date().toDateString();
  
  // Determine if we should show attendance link
  const showAttendanceLink = isPast || isSameDay;
  
  // Determine if we should show certificate link
  const showCertificateLink = isPast;

  return (
    <div>
      <div style={{ 
        display: 'flex', 
        justifyContent: 'space-between', 
        alignItems: 'center',
        marginBottom: '20px'
      }}>
        <div>
          <Link to="/coordinator/events" style={{ color: '#666', textDecoration: 'none' }}>
            ← Back to Events
          </Link>
          <h1 style={{ margin: '10px 0 0 0' }}>{event.title}</h1>
        </div>
        
        <div style={{ display: 'flex', gap: '10px' }}>
          {showAttendanceLink && (
            <Link to={`/coordinator/attendance/${event.id}`} style={{
              display: 'inline-block',
              padding: '10px 20px',
              backgroundColor: '#27ae60',
              color: 'white',
              textDecoration: 'none',
              borderRadius: '4px'
            }}>
              Manage Attendance
            </Link>
          )}
          
          {showCertificateLink && (
            <Link to={`/coordinator/certificates/${event.id}`} style={{
              display: 'inline-block',
              padding: '10px 20px',
              backgroundColor: '#3498db',
              color: 'white',
              textDecoration: 'none',
              borderRadius: '4px'
            }}>
              Generate Certificates
            </Link>
          )}
          
          <button 
            onClick={() => setIsDeleteModalOpen(true)}
            style={{
              padding: '10px 20px',
              backgroundColor: '#e74c3c',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer'
            }}
          >
            Delete
          </button>
        </div>
      </div>
      
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
        {/* Event Details Card */}
        <div style={{ 
          backgroundColor: 'white',
          borderRadius: '8px',
          padding: '20px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
        }}>
          <h2 style={{ marginTop: 0 }}>Event Details</h2>
          
          <div style={{ marginBottom: '15px' }}>
            <span style={{ 
              display: 'inline-block',
              padding: '5px 10px',
              backgroundColor: event.approved ? '#d4edda' : '#f8d7da',
              color: event.approved ? '#155724' : '#721c24',
              borderRadius: '4px',
              fontSize: '14px',
              marginBottom: '15px'
            }}>
              {event.approved ? 'Approved' : 'Pending Approval'}
            </span>
            
            <p style={{ margin: '0 0 5px 0', fontWeight: 'bold' }}>Date & Time:</p>
            <p style={{ margin: '0 0 15px 0' }}>
              {eventDate.toLocaleDateString()} at {event.time}
            </p>
            
            <p style={{ margin: '0 0 5px 0', fontWeight: 'bold' }}>Venue:</p>
            <p style={{ margin: '0 0 15px 0' }}>{event.venueName}</p>
            
            <p style={{ margin: '0 0 5px 0', fontWeight: 'bold' }}>Club:</p>
            <p style={{ margin: '0 0 15px 0' }}>{event.clubName}</p>
            
            <p style={{ margin: '0 0 5px 0', fontWeight: 'bold' }}>Description:</p>
            <p style={{ margin: '0', whiteSpace: 'pre-line' }}>{event.desc}</p>
          </div>
          
          {!event.approved && (
            <div style={{
              padding: '15px',
              backgroundColor: '#fff3cd',
              borderRadius: '5px',
              marginTop: '20px'
            }}>
              <p style={{ margin: '0', fontWeight: 'bold' }}>Approval Status</p>
              <p style={{ margin: '5px 0 0 0' }}>
                This event is awaiting faculty approval. Students will not be able to 
                register until it is approved.
              </p>
            </div>
          )}
        </div>
        
        {/* Registrations Card */}
        <div style={{ 
          backgroundColor: 'white',
          borderRadius: '8px',
          padding: '20px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '15px' }}>
            <h2 style={{ margin: 0 }}>Registered Participants</h2>
            <span style={{ 
              backgroundColor: '#f0f0f0',
              padding: '4px 10px',
              borderRadius: '20px',
              fontSize: '14px'
            }}>
              {registeredUsers.length} Registered
            </span>
          </div>
          
          {!event.approved ? (
            <div style={{ textAlign: 'center', padding: '20px', color: '#666' }}>
              <p>Registration not open yet. Waiting for faculty approval.</p>
            </div>
          ) : registeredUsers.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '20px', color: '#666' }}>
              <p>No students have registered for this event yet.</p>
            </div>
          ) : (
            <div style={{ maxHeight: '400px', overflowY: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead style={{ position: 'sticky', top: 0, backgroundColor: 'white' }}>
                  <tr>
                    <th style={{ padding: '10px', textAlign: 'left', borderBottom: '1px solid #ddd' }}>Student</th>
                    <th style={{ padding: '10px', textAlign: 'center', borderBottom: '1px solid #ddd' }}>Attendance</th>
                    <th style={{ padding: '10px', textAlign: 'right', borderBottom: '1px solid #ddd' }}>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {registeredUsers.map((item) => (
                    <tr key={item.registration.id}>
                      <td style={{ padding: '10px', borderBottom: '1px solid #ddd' }}>
                        {item.user.name}
                      </td>
                      <td style={{ padding: '10px', borderBottom: '1px solid #ddd', textAlign: 'center' }}>
                        {item.attendance ? (
                          <div>
                            <span style={{ 
                              display: 'inline-block',
                              width: '8px',
                              height: '8px',
                              borderRadius: '50%',
                              backgroundColor: item.attendance.FN ? '#27ae60' : '#e74c3c',
                              marginRight: '5px'
                            }}></span>
                            FN
                            
                            <span style={{ 
                              display: 'inline-block',
                              width: '8px',
                              height: '8px',
                              borderRadius: '50%',
                              backgroundColor: item.attendance.AN ? '#27ae60' : '#e74c3c',
                              marginLeft: '10px',
                              marginRight: '5px'
                            }}></span>
                            AN
                          </div>
                        ) : isPast ? (
                          <span style={{ color: '#e74c3c', fontSize: '14px' }}>Not Marked</span>
                        ) : (
                          <span style={{ color: '#666', fontSize: '14px' }}>Upcoming</span>
                        )}
                      </td>
                      <td style={{ padding: '10px', borderBottom: '1px solid #ddd', textAlign: 'right' }}>
                        <button 
                          onClick={() => {
                            setUserToRemove(item);
                            setIsConfirmCancelModalOpen(true);
                          }}
                          style={{
                            padding: '5px 10px',
                            backgroundColor: '#f8f9fa',
                            border: '1px solid #ddd',
                            borderRadius: '4px',
                            cursor: 'pointer'
                          }}
                        >
                          Remove
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          
          <div style={{ marginTop: '20px', textAlign: 'center' }}>
            {showAttendanceLink && (
              <Link to={`/coordinator/attendance/${event.id}`} style={{
                display: 'inline-block',
                padding: '10px 20px',
                backgroundColor: '#27ae60',
                color: 'white',
                textDecoration: 'none',
                borderRadius: '4px',
                width: '100%',
                boxSizing: 'border-box',
                textAlign: 'center'
              }}>
                Manage Attendance
              </Link>
            )}
          </div>
        </div>
      </div>
      
      {/* Delete Event Modal */}
      {isDeleteModalOpen && (
        <div style={{ 
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000
        }}>
          <div style={{ 
            backgroundColor: 'white',
            borderRadius: '8px',
            padding: '20px',
            width: '400px',
            maxWidth: '90%'
          }}>
            <h2 style={{ marginTop: 0 }}>Confirm Delete</h2>
            <p>Are you sure you want to delete this event? This action cannot be undone.</p>
            <p><strong>Event:</strong> {event.title}</p>
            
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px', marginTop: '20px' }}>
              <button 
                onClick={() => setIsDeleteModalOpen(false)}
                style={{
                  padding: '8px 15px',
                  backgroundColor: '#f0f0f0',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
              >
                Cancel
              </button>
              <button 
                onClick={handleDeleteEvent}
                style={{
                  padding: '8px 15px',
                  backgroundColor: '#e74c3c',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
              >
                Delete Event
              </button>
            </div>
          </div>
        </div>
      )}
      
      {/* Cancel Registration Modal */}
      {isConfirmCancelModalOpen && userToRemove && (
        <div style={{ 
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000
        }}>
          <div style={{ 
            backgroundColor: 'white',
            borderRadius: '8px',
            padding: '20px',
            width: '400px',
            maxWidth: '90%'
          }}>
            <h2 style={{ marginTop: 0 }}>Confirm Removal</h2>
            <p>Are you sure you want to remove this participant from the event?</p>
            <p><strong>Student:</strong> {userToRemove.user.name}</p>
            
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px', marginTop: '20px' }}>
              <button 
                onClick={() => {
                  setIsConfirmCancelModalOpen(false);
                  setUserToRemove(null);
                }}
                style={{
                  padding: '8px 15px',
                  backgroundColor: '#f0f0f0',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
              >
                Cancel
              </button>
              <button 
                onClick={handleCancelRegistration}
                style={{
                  padding: '8px 15px',
                  backgroundColor: '#e74c3c',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
              >
                Remove Participant
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default EventDetails;
