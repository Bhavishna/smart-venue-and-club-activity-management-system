import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import useCollectionData from '../../hooks/useCollection';

const CoordinatorDashboard = () => {
  const { currentUser } = useAuth();
  const { items: clubs } = useCollectionData('clubs');
  const { items: events } = useCollectionData('events');
  const { items: eventRegistrations } = useCollectionData('event_registrations');
  const { items: certificates } = useCollectionData('certificates');
  
  const [myClubs, setMyClubs] = useState([]);
  const [myEvents, setMyEvents] = useState([]);
  const [pendingApprovalCount, setPendingApprovalCount] = useState(0);
  
  // Get clubs where the current user is a coordinator
  useEffect(() => {
    if (currentUser && clubs.length) {
      const coordinatorClubs = clubs.filter(
        club => club.studentCoordinatorId === currentUser.id
      );
      setMyClubs(coordinatorClubs);
    }
  }, [currentUser, clubs]);
  
  // Get events organized by the coordinator's clubs
  useEffect(() => {
    if (myClubs.length && events.length) {
      const clubIds = myClubs.map(club => club.id);
      const coordinatorEvents = events.filter(event => 
        clubIds.includes(event.clubId)
      );
      
      setMyEvents(coordinatorEvents);
      
      // Count events pending approval
      const pending = coordinatorEvents.filter(
        event => event.requiresApproval && !event.approved
      ).length;
      setPendingApprovalCount(pending);
    }
  }, [myClubs, events]);
  
  // Get upcoming events (future date)
  const upcomingEvents = myEvents.filter(event => {
    const eventDate = new Date(event.date);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return eventDate >= today;
  }).sort((a, b) => new Date(a.date) - new Date(b.date));
  
  // Count event statistics
  const eventCounts = {
    total: myEvents.length,
    upcoming: upcomingEvents.length,
    approved: myEvents.filter(event => event.approved).length,
    pending: pendingApprovalCount
  };
  
  // Count registrations for my events
  const registrationCount = eventRegistrations.filter(
    reg => myEvents.some(event => event.id === reg.eventId)
  ).length;
  
  // Count certificates issued
  const certificateCount = certificates.filter(
    cert => myEvents.some(event => event.id === cert.eventId)
  ).length;

  return (
    <div>
      <h1>Coordinator Dashboard</h1>
      
      {myClubs.length === 0 ? (
        <div style={{
          padding: '20px',
          background: '#fff3cd',
          borderRadius: '5px',
          marginBottom: '20px'
        }}>
          <p style={{ margin: '0', fontWeight: 'bold' }}>
            You are not assigned as a coordinator for any club yet.
          </p>
        </div>
      ) : (
        <>
          <div style={{ 
            display: 'grid', 
            gridTemplateColumns: 'repeat(auto-fill, minmax(250px, 1fr))', 
            gap: '20px',
            marginBottom: '30px'
          }}>
            <StatCard 
              title="My Clubs" 
              value={myClubs.length}
              color="#5e35b1"
              icon="🏛️"
            />
            <StatCard 
              title="Total Events" 
              value={eventCounts.total}
              color="#e67e22"
              icon="📅"
            />
            <StatCard 
              title="Registrations" 
              value={registrationCount}
              color="#27ae60"
              icon="👥"
            />
            <StatCard 
              title="Certificates Issued" 
              value={certificateCount}
              color="#3498db"
              icon="🎓"
            />
          </div>
          
          <div style={{ display: 'flex', gap: '20px', flexWrap: 'wrap' }}>
            {/* My clubs section */}
            <div style={{ 
              flex: '1 1 350px', 
              backgroundColor: 'white',
              borderRadius: '8px',
              padding: '20px',
              boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
              marginBottom: '20px'
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '15px' }}>
                <h2 style={{ margin: 0 }}>My Clubs</h2>
              </div>
              
              <div>
                {myClubs.map(club => (
                  <div key={club.id} style={{ 
                    padding: '15px', 
                    borderBottom: '1px solid #eee',
                    borderRadius: '5px',
                    marginBottom: '10px',
                    backgroundColor: '#f9f9f9'
                  }}>
                    <h3 style={{ margin: '0 0 5px 0' }}>{club.name}</h3>
                    <p style={{ margin: '0 0 10px 0', color: '#666' }}>{club.description.substring(0, 100)}...</p>
                    
                    <div style={{ display: 'flex', gap: '10px' }}>
                      <Link to={`/coordinator/events/create?club=${club.id}`} style={{
                        display: 'inline-block',
                        padding: '8px 15px',
                        backgroundColor: '#5e35b1',
                        color: 'white',
                        textDecoration: 'none',
                        borderRadius: '4px',
                        fontSize: '14px'
                      }}>
                        Create Event
                      </Link>
                      
                      <Link to="/coordinator/events" style={{
                        display: 'inline-block',
                        padding: '8px 15px',
                        backgroundColor: '#f0f0f0',
                        color: '#333',
                        textDecoration: 'none',
                        borderRadius: '4px',
                        fontSize: '14px'
                      }}>
                        View Events
                      </Link>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Upcoming events section */}
            <div style={{ 
              flex: '1 1 350px', 
              backgroundColor: 'white',
              borderRadius: '8px',
              padding: '20px',
              boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
              marginBottom: '20px'
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '15px' }}>
                <h2 style={{ margin: 0 }}>Upcoming Events</h2>
                <Link to="/coordinator/events" style={{ color: '#5e35b1', textDecoration: 'none' }}>
                  View All →
                </Link>
              </div>
              
              <div>
                {upcomingEvents.length > 0 ? (
                  upcomingEvents.slice(0, 5).map(event => {
                    const eventDate = new Date(event.date);
                    const club = myClubs.find(c => c.id === event.clubId);
                    
                    return (
                      <div key={event.id} style={{ 
                        padding: '15px',
                        marginBottom: '10px',
                        backgroundColor: '#f9f9f9',
                        borderRadius: '5px',
                        borderLeft: event.approved ? '4px solid #27ae60' : '4px solid #e74c3c'
                      }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                          <div>
                            <h3 style={{ margin: '0 0 5px 0' }}>{event.title}</h3>
                            <p style={{ margin: '0 0 5px 0', color: '#666' }}>
                              Club: {club ? club.name : 'Unknown'}
                            </p>
                            <p style={{ margin: '0', color: '#666' }}>
                              {eventDate.toLocaleDateString()} at {event.time}
                            </p>
                          </div>
                          <div style={{ 
                            padding: '4px 8px', 
                            backgroundColor: event.approved ? '#27ae60' : '#e74c3c',
                            color: 'white',
                            borderRadius: '4px',
                            fontSize: '12px'
                          }}>
                            {event.approved ? 'Approved' : 'Pending'}
                          </div>
                        </div>
                        <div style={{ marginTop: '10px' }}>
                          <Link to={`/coordinator/events/${event.id}`} style={{
                            display: 'inline-block',
                            padding: '6px 12px',
                            backgroundColor: '#5e35b1',
                            color: 'white',
                            textDecoration: 'none',
                            borderRadius: '4px',
                            fontSize: '14px'
                          }}>
                            Manage Event
                          </Link>
                        </div>
                      </div>
                    );
                  })
                ) : (
                  <p style={{ textAlign: 'center', color: '#666', padding: '20px' }}>
                    No upcoming events. <Link to="/coordinator/events/create" style={{ color: '#5e35b1' }}>Create one now!</Link>
                  </p>
                )}
              </div>
            </div>
          </div>
          
          {/* Quick actions */}
          <div style={{ 
            backgroundColor: 'white',
            borderRadius: '8px',
            padding: '20px',
            boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
            marginBottom: '20px'
          }}>
            <h2 style={{ margin: '0 0 20px 0' }}>Quick Actions</h2>
            
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(250px, 1fr))', gap: '15px' }}>
              <Link to="/coordinator/events/create" style={{
                display: 'block',
                padding: '15px 20px',
                backgroundColor: '#5e35b1',
                color: 'white',
                textDecoration: 'none',
                borderRadius: '6px',
                textAlign: 'center',
                fontWeight: 'bold'
              }}>
                Create New Event
              </Link>
              
              <Link to="/coordinator/registrations" style={{
                display: 'block',
                padding: '15px 20px',
                backgroundColor: '#27ae60',
                color: 'white',
                textDecoration: 'none',
                borderRadius: '6px',
                textAlign: 'center',
                fontWeight: 'bold'
              }}>
                Manage Registrations
              </Link>
              
              <Link to="/coordinator/attendance" style={{
                display: 'block',
                padding: '15px 20px',
                backgroundColor: '#e67e22',
                color: 'white',
                textDecoration: 'none',
                borderRadius: '6px',
                textAlign: 'center',
                fontWeight: 'bold'
              }}>
                Take Attendance
              </Link>
              
              <Link to="/coordinator/certificates" style={{
                display: 'block',
                padding: '15px 20px',
                backgroundColor: '#3498db',
                color: 'white',
                textDecoration: 'none',
                borderRadius: '6px',
                textAlign: 'center',
                fontWeight: 'bold'
              }}>
                Generate Certificates
              </Link>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

// Helper component for stats
const StatCard = ({ title, value, color, icon }) => (
  <div style={{
    backgroundColor: 'white',
    borderRadius: '8px',
    padding: '20px',
    boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
    position: 'relative',
    overflow: 'hidden'
  }}>
    <div style={{ marginBottom: '10px' }}>
      <h3 style={{ margin: '0', fontSize: '16px', color: '#666' }}>{title}</h3>
      <p style={{ margin: '10px 0 0 0', fontSize: '28px', fontWeight: 'bold' }}>{value}</p>
    </div>
    
    {icon && (
      <div style={{ 
        position: 'absolute', 
        top: '15px', 
        right: '15px',
        width: '40px',
        height: '40px',
        borderRadius: '50%',
        backgroundColor: `${color}20`,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        color: color,
        fontSize: '20px'
      }}>
        {icon}
      </div>
    )}
  </div>
);

export default CoordinatorDashboard;
