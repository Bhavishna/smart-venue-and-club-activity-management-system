import React, { useState, useEffect, useRef } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import useCollectionData from '../../hooks/useCollection';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

const CertificateGeneration = () => {
  const { eventId } = useParams();
  const { currentUser } = useAuth();
  const certificateRef = useRef(null);
  
  // Collection data
  const { items: events } = useCollectionData('events');
  const { items: clubs } = useCollectionData('clubs');
  const { items: venues } = useCollectionData('venues');
  const { items: registrations } = useCollectionData('event_registrations');
  const { items: attendanceRecords } = useCollectionData('attendance_records');
  const { items: users } = useCollectionData('users');
  const { items: certificates, addItem: addCertificate } = useCollectionData('certificates');
  
  // Local state
  const [event, setEvent] = useState(null);
  const [eligibleStudents, setEligibleStudents] = useState([]);
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [generatingCertificate, setGeneratingCertificate] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  const [certificateTemplate, setCertificateTemplate] = useState('template1');
  const [generatingBatch, setGeneratingBatch] = useState(false);
  const [progress, setProgress] = useState(0);
  
  // Load event data
  useEffect(() => {
    if (events.length > 0 && clubs.length > 0) {
      const currentEvent = events.find(e => e.id === eventId);
      
      if (currentEvent) {
        // Check if user has permission to view this event
        const club = clubs.find(c => c.id === currentEvent.clubId);
        
        if (club && club.studentCoordinatorId === currentUser.id) {
          const venue = venues.find(v => v.id === currentEvent.venueId);
          
          setEvent({
            ...currentEvent,
            clubName: club ? club.name : 'Unknown Club',
            venueName: venue ? venue.name : 'Unknown Venue',
          });
        } else {
          setError("You don't have permission to view this event");
        }
      } else {
        setError("Event not found");
      }
      
      setLoading(false);
    }
  }, [events, clubs, venues, eventId, currentUser.id]);
  
  // Find eligible students (with both FN and AN attendance)
  useEffect(() => {
    if (event && registrations.length > 0 && attendanceRecords.length > 0 && users.length > 0) {
      const eventRegs = registrations.filter(reg => reg.eventId === eventId);
      
      const eligible = eventRegs
        .filter(reg => {
          const attendance = attendanceRecords.find(
            a => a.eventId === eventId && a.studentId === reg.studentId
          );
          
          // Check for full attendance (both sessions)
          return attendance && attendance.FN && attendance.AN;
        })
        .map(reg => {
          const user = users.find(u => u.id === reg.studentId);
          const existingCertificate = certificates.find(
            c => c.eventId === eventId && c.studentId === reg.studentId
          );
          
          return {
            registrationId: reg.id,
            studentId: reg.studentId,
            name: user ? user.name : 'Unknown User',
            email: user ? user.email : '',
            hasCertificate: !!existingCertificate,
            certificateId: existingCertificate ? existingCertificate.id : null,
            certificateUrl: existingCertificate ? existingCertificate.url : null
          };
        });
      
      setEligibleStudents(eligible);
    }
  }, [event, registrations, attendanceRecords, users, certificates, eventId]);
  
  // Generate a single certificate
  const generateCertificate = async (student) => {
    if (!certificateRef.current) return;
    
    setSelectedStudent(student);
    setGeneratingCertificate(true);
    
    try {
      // Wait for the certificate to render with the student's name
      await new Promise(resolve => setTimeout(resolve, 100));
      
      // Convert to canvas
      const canvas = await html2canvas(certificateRef.current, { scale: 2 });
      
      // Convert to PDF
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('l', 'mm', 'a4'); // Landscape orientation
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();
      
      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
      
      // Save as binary data
      const pdfBlob = pdf.output('blob');
      const fileName = `certificate_${event.title.replace(/\s+/g, '_')}_${student.name.replace(/\s+/g, '_')}.pdf`;
      
      // Create object URL for preview
      const url = URL.createObjectURL(pdfBlob);
      
      // Store in certificates collection
      const certificateData = {
        eventId,
        studentId: student.studentId,
        url,
        fileName,
        generatedAt: new Date().toISOString(),
        generatedBy: currentUser.id
      };
      
      // Check if certificate already exists
      if (student.certificateId) {
        // Just return the existing certificate
        setSuccessMessage('Certificate already exists for this student');
      } else {
        // Add new certificate
        await addCertificate(certificateData);
        setSuccessMessage('Certificate generated successfully');
      }
      
      // Update student to show they have a certificate
      student.hasCertificate = true;
      student.certificateUrl = url;
      
      // Reset selection after a delay
      setTimeout(() => {
        setSelectedStudent(null);
        setSuccessMessage('');
      }, 3000);
      
    } catch (error) {
      console.error('Error generating certificate:', error);
      setError('Failed to generate certificate');
    } finally {
      setGeneratingCertificate(false);
    }
  };
  
  // Generate certificates for all eligible students
  const generateBatchCertificates = async () => {
    if (eligibleStudents.length === 0) {
      setError('No eligible students to generate certificates for');
      return;
    }
    
    setGeneratingBatch(true);
    setProgress(0);
    
    try {
      // Filter students who don't have certificates yet
      const studentsWithoutCertificates = eligibleStudents.filter(student => !student.hasCertificate);
      
      if (studentsWithoutCertificates.length === 0) {
        setSuccessMessage('All eligible students already have certificates');
        setGeneratingBatch(false);
        return;
      }
      
      // Process each student
      for (let i = 0; i < studentsWithoutCertificates.length; i++) {
        const student = studentsWithoutCertificates[i];
        
        // Update progress
        setProgress(Math.floor((i / studentsWithoutCertificates.length) * 100));
        
        // Generate certificate
        await generateCertificate(student);
        
        // Short delay between generations
        await new Promise(resolve => setTimeout(resolve, 500));
      }
      
      setSuccessMessage(`Generated ${studentsWithoutCertificates.length} certificates successfully`);
      setProgress(100);
      
    } catch (error) {
      console.error('Error in batch certificate generation:', error);
      setError('Failed to generate all certificates');
    } finally {
      setGeneratingBatch(false);
    }
  };
  
  // Download a certificate
  const downloadCertificate = (student) => {
    if (student.certificateUrl) {
      // Create temporary anchor element to trigger download
      const a = document.createElement('a');
      a.href = student.certificateUrl;
      a.download = `certificate_${event.title.replace(/\s+/g, '_')}_${student.name.replace(/\s+/g, '_')}.pdf`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    }
  };
  
  // Count how many students need certificates
  const studentsNeedingCertificates = eligibleStudents.filter(s => !s.hasCertificate).length;
  
  if (loading) {
    return <div style={{ textAlign: 'center', padding: '50px' }}>Loading...</div>;
  }
  
  if (error) {
    return (
      <div style={{
        padding: '20px',
        backgroundColor: '#f8d7da',
        color: '#721c24',
        borderRadius: '5px',
        marginBottom: '20px'
      }}>
        <p style={{ margin: '0', fontWeight: 'bold' }}>{error}</p>
        <Link to="/coordinator/events" style={{ color: '#721c24', textDecoration: 'underline' }}>
          Return to Events
        </Link>
      </div>
    );
  }
  
  if (!event) {
    return <div style={{ textAlign: 'center', padding: '50px' }}>Event not found</div>;
  }
  
  return (
    <div>
      <div style={{ 
        display: 'flex', 
        justifyContent: 'space-between', 
        alignItems: 'center',
        marginBottom: '20px'
      }}>
        <div>
          <Link to={`/coordinator/events/${eventId}`} style={{ color: '#666', textDecoration: 'none' }}>
            ← Back to Event
          </Link>
          <h1 style={{ margin: '10px 0 0 0' }}>Certificate Generation</h1>
        </div>
      </div>
      
      {/* Event Details Card */}
      <div style={{ 
        backgroundColor: 'white',
        borderRadius: '8px',
        padding: '20px',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
        marginBottom: '20px'
      }}>
        <h2 style={{ marginTop: 0, marginBottom: '15px' }}>{event.title}</h2>
        
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: '30px', marginBottom: '20px' }}>
          <div>
            <p style={{ margin: '0 0 5px 0', fontWeight: 'bold' }}>Date:</p>
            <p style={{ margin: '0' }}>{new Date(event.date).toLocaleDateString()}</p>
          </div>
          <div>
            <p style={{ margin: '0 0 5px 0', fontWeight: 'bold' }}>Time:</p>
            <p style={{ margin: '0' }}>{event.time}</p>
          </div>
          <div>
            <p style={{ margin: '0 0 5px 0', fontWeight: 'bold' }}>Venue:</p>
            <p style={{ margin: '0' }}>{event.venueName}</p>
          </div>
          <div>
            <p style={{ margin: '0 0 5px 0', fontWeight: 'bold' }}>Club:</p>
            <p style={{ margin: '0' }}>{event.clubName}</p>
          </div>
        </div>
        
        <div style={{ display: 'flex', gap: '20px', marginTop: '20px', flexWrap: 'wrap' }}>
          <div style={{ 
            backgroundColor: '#e8f4fd', 
            padding: '15px', 
            borderRadius: '5px', 
            flex: '1 1 200px' 
          }}>
            <h3 style={{ margin: '0 0 10px 0', fontSize: '16px' }}>Registered Participants</h3>
            <p style={{ margin: '0', fontSize: '24px', fontWeight: 'bold' }}>{registrations.filter(r => r.eventId === eventId).length}</p>
          </div>
          
          <div style={{ 
            backgroundColor: '#e8f8f5', 
            padding: '15px', 
            borderRadius: '5px', 
            flex: '1 1 200px' 
          }}>
            <h3 style={{ margin: '0 0 10px 0', fontSize: '16px' }}>Eligible for Certificate</h3>
            <p style={{ margin: '0', fontSize: '24px', fontWeight: 'bold' }}>{eligibleStudents.length}</p>
          </div>
          
          <div style={{ 
            backgroundColor: '#fef9e7', 
            padding: '15px', 
            borderRadius: '5px', 
            flex: '1 1 200px' 
          }}>
            <h3 style={{ margin: '0 0 10px 0', fontSize: '16px' }}>Certificates Generated</h3>
            <p style={{ margin: '0', fontSize: '24px', fontWeight: 'bold' }}>
              {eligibleStudents.filter(s => s.hasCertificate).length}
            </p>
          </div>
        </div>
      </div>
      
      {/* Certificate Generation Controls */}
      <div style={{ 
        backgroundColor: 'white',
        borderRadius: '8px',
        padding: '20px',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
        marginBottom: '20px'
      }}>
        <h2 style={{ marginTop: 0, marginBottom: '15px' }}>Certificate Generation</h2>
        
        <div style={{ marginBottom: '20px' }}>
          <label style={{ display: 'block', marginBottom: '5px', fontWeight: 'bold' }}>Select Certificate Template</label>
          <select
            value={certificateTemplate}
            onChange={(e) => setCertificateTemplate(e.target.value)}
            style={{ 
              padding: '10px', 
              borderRadius: '4px',
              border: '1px solid #ddd',
              width: '100%',
              maxWidth: '400px'
            }}
          >
            <option value="template1">Elegant (Dark Blue)</option>
            <option value="template2">Modern (Purple)</option>
            <option value="template3">Classic (Gold)</option>
          </select>
        </div>
        
        {successMessage && (
          <div style={{ 
            padding: '15px', 
            backgroundColor: '#d4edda', 
            color: '#155724',
            borderRadius: '5px',
            marginBottom: '20px'
          }}>
            {successMessage}
          </div>
        )}
        
        {eligibleStudents.length > 0 ? (
          <div>
            <button
              onClick={generateBatchCertificates}
              disabled={generatingBatch || studentsNeedingCertificates === 0}
              style={{
                padding: '12px 25px',
                backgroundColor: studentsNeedingCertificates === 0 ? '#f0f0f0' : '#3498db',
                color: studentsNeedingCertificates === 0 ? '#999' : 'white',
                border: 'none',
                borderRadius: '4px',
                cursor: studentsNeedingCertificates === 0 ? 'not-allowed' : 'pointer',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '10px'
              }}
            >
              {generatingBatch ? (
                <>Generating... ({progress}%)</>
              ) : (
                <>Generate {studentsNeedingCertificates} Certificates</>
              )}
            </button>
            
            {generatingBatch && (
              <div style={{ marginTop: '15px' }}>
                <div style={{ 
                  height: '10px', 
                  backgroundColor: '#f0f0f0',
                  borderRadius: '5px',
                  marginBottom: '5px',
                  overflow: 'hidden'
                }}>
                  <div style={{ 
                    height: '100%', 
                    width: `${progress}%`,
                    backgroundColor: '#3498db',
                    borderRadius: '5px',
                    transition: 'width 0.3s ease'
                  }} />
                </div>
                <p style={{ margin: '0', fontSize: '14px', color: '#666', textAlign: 'center' }}>
                  Processing {progress}% complete
                </p>
              </div>
            )}
          </div>
        ) : (
          <div style={{ 
            padding: '15px', 
            backgroundColor: '#fff3cd', 
            color: '#856404',
            borderRadius: '5px'
          }}>
            <p style={{ margin: '0' }}>There are no students eligible for certificates yet. Students need to have attended both FN and AN sessions to be eligible.</p>
            <Link 
              to={`/coordinator/attendance/${eventId}`}
              style={{
                display: 'inline-block',
                marginTop: '10px',
                color: '#856404',
                fontWeight: 'bold',
                textDecoration: 'underline'
              }}
            >
              Manage Attendance
            </Link>
          </div>
        )}
      </div>
      
      {/* Eligible Students List */}
      {eligibleStudents.length > 0 && (
        <div style={{ 
          backgroundColor: 'white',
          borderRadius: '8px',
          padding: '20px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
        }}>
          <h2 style={{ marginTop: 0 }}>Eligible Students</h2>
          
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ backgroundColor: '#f8f9fa' }}>
                  <th style={{ padding: '12px 15px', textAlign: 'left', borderBottom: '1px solid #ddd' }}>#</th>
                  <th style={{ padding: '12px 15px', textAlign: 'left', borderBottom: '1px solid #ddd' }}>Student</th>
                  <th style={{ padding: '12px 15px', textAlign: 'center', borderBottom: '1px solid #ddd' }}>Certificate</th>
                  <th style={{ padding: '12px 15px', textAlign: 'right', borderBottom: '1px solid #ddd' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {eligibleStudents.map((student, index) => (
                  <tr key={student.registrationId} style={{ backgroundColor: index % 2 === 0 ? '#ffffff' : '#f8f9fa' }}>
                    <td style={{ padding: '12px 15px', borderBottom: '1px solid #ddd' }}>{index + 1}</td>
                    <td style={{ padding: '12px 15px', borderBottom: '1px solid #ddd' }}>
                      <div style={{ fontWeight: 'bold' }}>{student.name}</div>
                      <div style={{ fontSize: '12px', color: '#666' }}>{student.email}</div>
                    </td>
                    <td style={{ padding: '12px 15px', borderBottom: '1px solid #ddd', textAlign: 'center' }}>
                      <span style={{
                        display: 'inline-block',
                        padding: '5px 10px',
                        backgroundColor: student.hasCertificate ? '#d4edda' : '#f8d7da',
                        color: student.hasCertificate ? '#155724' : '#721c24',
                        borderRadius: '4px',
                        fontSize: '14px'
                      }}>
                        {student.hasCertificate ? 'Generated' : 'Not Generated'}
                      </span>
                    </td>
                    <td style={{ padding: '12px 15px', borderBottom: '1px solid #ddd', textAlign: 'right' }}>
                      {student.hasCertificate ? (
                        <button
                          onClick={() => downloadCertificate(student)}
                          style={{
                            padding: '8px 15px',
                            backgroundColor: '#3498db',
                            color: 'white',
                            border: 'none',
                            borderRadius: '4px',
                            cursor: 'pointer'
                          }}
                        >
                          Download
                        </button>
                      ) : (
                        <button
                          onClick={() => generateCertificate(student)}
                          disabled={generatingCertificate}
                          style={{
                            padding: '8px 15px',
                            backgroundColor: '#27ae60',
                            color: 'white',
                            border: 'none',
                            borderRadius: '4px',
                            cursor: 'pointer'
                          }}
                        >
                          {generatingCertificate && selectedStudent?.studentId === student.studentId 
                            ? 'Generating...' 
                            : 'Generate'
                          }
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
      
      {/* Hidden certificate template for generation */}
      <div style={{ position: 'absolute', left: '-9999px' }}>
        <div ref={certificateRef} style={{ width: '842px', height: '595px' }}>
          {certificateTemplate === 'template1' && (
            <div style={{
              width: '100%',
              height: '100%',
              backgroundColor: '#f9f9f9',
              padding: '40px',
              boxSizing: 'border-box',
              fontFamily: 'Arial, sans-serif',
              position: 'relative',
              borderRadius: '10px',
              border: '15px solid #1e3a8a'
            }}>
              <div style={{ 
                position: 'absolute', 
                top: '20px', 
                left: '20px',
                fontSize: '24px',
                fontWeight: 'bold',
                color: '#1e3a8a'
              }}>
                {event.clubName}
              </div>
              
              <div style={{ textAlign: 'center', marginTop: '40px' }}>
                <h1 style={{ 
                  fontSize: '42px', 
                  color: '#1e3a8a',
                  margin: '20px 0',
                  fontFamily: 'Georgia, serif',
                  textTransform: 'uppercase'
                }}>Certificate of Participation</h1>
                
                <p style={{ 
                  fontSize: '18px', 
                  margin: '30px 0',
                  fontStyle: 'italic'
                }}>
                  This is to certify that
                </p>
                
                <h2 style={{ 
                  fontSize: '36px', 
                  margin: '20px 0',
                  color: '#1e3a8a',
                  fontFamily: 'Georgia, serif'
                }}>
                  {selectedStudent ? selectedStudent.name : '[Student Name]'}
                </h2>
                
                <p style={{ 
                  fontSize: '18px', 
                  margin: '30px 0',
                  lineHeight: '1.6'
                }}>
                  has successfully participated in <strong>{event.title}</strong><br/>
                  held on {new Date(event.date).toLocaleDateString()} at {event.venueName}
                </p>
              </div>
              
              <div style={{ 
                position: 'absolute',
                bottom: '60px',
                left: '0',
                right: '0',
                display: 'flex',
                justifyContent: 'space-around'
              }}>
                <div style={{ textAlign: 'center' }}>
                  <div style={{ 
                    width: '150px',
                    borderTop: '1px solid #333',
                    margin: '0 auto 5px auto'
                  }}></div>
                  <p style={{ margin: 0 }}>Faculty Coordinator</p>
                </div>
                
                <div style={{ textAlign: 'center' }}>
                  <div style={{ 
                    width: '150px',
                    borderTop: '1px solid #333',
                    margin: '0 auto 5px auto'
                  }}></div>
                  <p style={{ margin: 0 }}>Student Coordinator</p>
                </div>
              </div>
              
              <div style={{ 
                position: 'absolute',
                bottom: '20px',
                right: '20px',
                fontSize: '12px',
                color: '#666'
              }}>
                Certificate ID: CERT-{eventId.substring(0, 6)}-{selectedStudent ? selectedStudent.studentId.substring(0, 6) : 'XXXXXX'}
              </div>
            </div>
          )}
          
          {certificateTemplate === 'template2' && (
            <div style={{
              width: '100%',
              height: '100%',
              backgroundColor: '#fff',
              padding: '30px',
              boxSizing: 'border-box',
              fontFamily: 'Arial, sans-serif',
              position: 'relative',
              background: 'linear-gradient(135deg, #f5f7fa 0%, #e2e6f0 100%)',
              borderRadius: '8px'
            }}>
              <div style={{ 
                position: 'absolute', 
                top: '0',
                left: '0',
                right: '0',
                height: '80px',
                background: 'linear-gradient(90deg, #5e35b1 0%, #7c4dff 100%)',
                borderTopLeftRadius: '8px',
                borderTopRightRadius: '8px',
                display: 'flex',
                alignItems: 'center',
                padding: '0 50px'
              }}>
                <span style={{
                  color: 'white',
                  fontSize: '24px',
                  fontWeight: 'bold'
                }}>{event.clubName}</span>
              </div>
              
              <div style={{ textAlign: 'center', marginTop: '90px' }}>
                <h1 style={{ 
                  fontSize: '36px', 
                  color: '#5e35b1',
                  margin: '10px 0',
                  fontWeight: 'normal',
                  letterSpacing: '2px',
                  textTransform: 'uppercase'
                }}>Certificate of Participation</h1>
                
                <div style={{
                  width: '100px',
                  height: '4px',
                  background: 'linear-gradient(90deg, #5e35b1 0%, #7c4dff 100%)',
                  margin: '15px auto 30px auto',
                  borderRadius: '2px'
                }}></div>
                
                <p style={{ 
                  fontSize: '16px', 
                  margin: '20px 0',
                  color: '#666'
                }}>
                  This certificate is presented to
                </p>
                
                <h2 style={{ 
                  fontSize: '32px', 
                  margin: '20px 0',
                  color: '#5e35b1',
                  fontWeight: 'bold'
                }}>
                  {selectedStudent ? selectedStudent.name : '[Student Name]'}
                </h2>
                
                <p style={{ 
                  fontSize: '16px', 
                  margin: '30px 0 20px 0',
                  color: '#333',
                  lineHeight: '1.6'
                }}>
                  for active participation in <strong>{event.title}</strong><br/>
                  on {new Date(event.date).toLocaleDateString()} at {event.venueName}
                </p>
                
                <p style={{ 
                  fontSize: '14px', 
                  fontStyle: 'italic',
                  color: '#666',
                  margin: '20px 0'
                }}>
                  This certifies that the participant has attended the entire event<br/>
                  and fulfilled all the requirements.
                </p>
              </div>
              
              <div style={{ 
                position: 'absolute',
                bottom: '50px',
                left: '0',
                right: '0',
                display: 'flex',
                justifyContent: 'space-around'
              }}>
                <div style={{ textAlign: 'center' }}>
                  <div style={{ 
                    // src/pages/coordinator/CertificateGeneration.js (continued)
                    width: '150px',
                    borderTop: '2px solid #5e35b1',
                    margin: '0 auto 5px auto'
                  }}></div>
                  <p style={{ margin: 0, color: '#5e35b1' }}>Faculty Coordinator</p>
                </div>
                
                <div style={{ textAlign: 'center' }}>
                  <div style={{ 
                    width: '150px',
                    borderTop: '2px solid #5e35b1',
                    margin: '0 auto 5px auto'
                  }}></div>
                  <p style={{ margin: 0, color: '#5e35b1' }}>Student Coordinator</p>
                </div>
              </div>
              
              <div style={{ 
                position: 'absolute',
                bottom: '15px',
                right: '20px',
                fontSize: '10px',
                color: '#999'
              }}>
                Date of Issue: {new Date().toLocaleDateString()}
              </div>
            </div>
          )}
          
          {certificateTemplate === 'template3' && (
            <div style={{
              width: '100%',
              height: '100%',
              backgroundColor: '#fff',
              boxSizing: 'border-box',
              fontFamily: 'Georgia, serif',
              position: 'relative',
              border: '15px solid #f1c40f',
              padding: '20px'
            }}>
              <div style={{
                position: 'absolute',
                top: '10px',
                left: '10px',
                right: '10px',
                bottom: '10px',
                border: '2px solid #f1c40f',
                padding: '20px',
                boxSizing: 'border-box'
              }}>
                <div style={{ textAlign: 'center' }}>
                  <h1 style={{ 
                    fontSize: '40px', 
                    color: '#7f6000',
                    margin: '10px 0 20px 0',
                    fontFamily: 'Georgia, serif'
                  }}>Certificate of Participation</h1>
                  
                  <div style={{ 
                    fontSize: '18px', 
                    margin: '20px 0 30px 0',
                    color: '#333'
                  }}>
                    <em>This is to certify that</em>
                  </div>
                  
                  <h2 style={{ 
                    fontSize: '36px', 
                    margin: '20px 0',
                    color: '#7f6000',
                    fontFamily: 'Georgia, serif'
                  }}>
                    {selectedStudent ? selectedStudent.name : '[Student Name]'}
                  </h2>
                  
                  <div style={{ 
                    fontSize: '18px', 
                    margin: '30px 0 20px 0',
                    lineHeight: '1.6',
                    color: '#333'
                  }}>
                    has successfully participated in<br />
                    <strong style={{ fontSize: '22px', color: '#7f6000' }}>{event.title}</strong><br/>
                    organized by <strong>{event.clubName}</strong><br />
                    on {new Date(event.date).toLocaleDateString()} at {event.venueName}
                  </div>
                </div>
                
                <div style={{ 
                  position: 'absolute',
                  bottom: '40px',
                  left: '0',
                  right: '0',
                  display: 'flex',
                  justifyContent: 'space-around'
                }}>
                  <div style={{ textAlign: 'center' }}>
                    <div style={{ 
                      width: '150px',
                      borderTop: '1px solid #7f6000',
                      margin: '0 auto 5px auto'
                    }}></div>
                    <p style={{ margin: 0, color: '#7f6000' }}>Faculty Coordinator</p>
                  </div>
                  
                  <div style={{ textAlign: 'center' }}>
                    <div style={{ 
                      width: '150px',
                      borderTop: '1px solid #7f6000',
                      margin: '0 auto 5px auto'
                    }}></div>
                    <p style={{ margin: 0, color: '#7f6000' }}>Student Coordinator</p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CertificateGeneration;
