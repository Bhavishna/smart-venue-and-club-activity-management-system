import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import useCollectionData from '../../hooks/useCollection';

const AttendanceManagement = () => {
  const { eventId } = useParams();
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  
  const { items: events } = useCollectionData('events');
  const { items: clubs } = useCollectionData('clubs');
  const { items: venues } = useCollectionData('venues');
  const { items: registrations } = useCollectionData('event_registrations');
  const { items: users } = useCollectionData('users');
  const { 
    items: attendanceRecords, 
    addItem: addAttendance, 
    updateItem: updateAttendance 
  } = useCollectionData('attendance_records');
  
  const [event, setEvent] = useState(null);
  const [attendanceList, setAttendanceList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [notes, setNotes] = useState({});
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [currentStudent, setCurrentStudent] = useState(null);
  const [saveMessage, setSaveMessage] = useState('');
  
  useEffect(() => {
    if (events.length > 0 && clubs.length > 0) {
      const currentEvent = events.find(e => e.id === eventId);
      
      if (currentEvent) {
        // Check if user has permission to view this event
        const club = clubs.find(c => c.id === currentEvent.clubId);
        
        if (club && club.studentCoordinatorId === currentUser.id) {
          const venue = venues.find(v => v.id === currentEvent.venueId);
          
          setEvent({
            ...currentEvent,
            clubName: club ? club.name : 'Unknown Club',
            venueName: venue ? venue.name : 'Unknown Venue',
          });
        } else {
          setError("You don't have permission to view this event");
        }
      } else {
        setError("Event not found");
      }
      
      setLoading(false);
    }
  }, [events, clubs, venues, eventId, currentUser.id]);
  
  // Prepare attendance list with registration and user data
  useEffect(() => {
    if (event && registrations.length > 0 && users.length > 0) {
      const eventRegs = registrations.filter(reg => reg.eventId === eventId);
      
      // Map registrations to include user data and attendance status
      const attendanceData = eventRegs.map(reg => {
        const user = users.find(u => u.id === reg.studentId);
        const attendance = attendanceRecords.find(
          a => a.eventId === eventId && a.studentId === reg.studentId
        );
        
        // Initialize notes if attendance exists
        if (attendance && attendance.notes) {
          setNotes(prev => ({
            ...prev,
            [reg.studentId]: attendance.notes
          }));
        }
        
        return {
          registrationId: reg.id,
          studentId: reg.studentId,
          name: user ? user.name : 'Unknown User',
          email: user ? user.email : '',
          attendanceId: attendance ? attendance.id : null,
          FN: attendance ? attendance.FN : false,
          AN: attendance ? attendance.AN : false,
          timestamps: attendance ? attendance.timestamps : null,
          notes: attendance ? attendance.notes : ''
        };
      });
      
      // Sort by name
      attendanceData.sort((a, b) => a.name.localeCompare(b.name));
      
      setAttendanceList(attendanceData);
    }
  }, [event, registrations, users, attendanceRecords, eventId]);
  
  // Handle toggling attendance status
  const handleToggleAttendance = async (student, session) => {
    try {
      const newValue = !student[session];
      
      // If attendance record exists, update it
      if (student.attendanceId) {
        // Prepare updated data
        const updatedData = {
          [session]: newValue,
          // Add timestamp for when marked present
          timestamps: {
            ...(student.timestamps || {}),
            ...(newValue ? { [session]: new Date().toISOString() } : {})
          }
        };
        
        await updateAttendance(student.attendanceId, updatedData);
        
        // Update local state
        setAttendanceList(prev => 
          prev.map(s => 
            s.studentId === student.studentId 
              ? { 
                  ...s, 
                  [session]: newValue,
                  timestamps: {
                    ...(s.timestamps || {}),
                    ...(newValue ? { [session]: new Date().toISOString() } : {})
                  }
                } 
              : s
          )
        );
      } else {
        // Create new attendance record
        const newRecord = {
          eventId,
          studentId: student.studentId,
          FN: session === 'FN' ? newValue : false,
          AN: session === 'AN' ? newValue : false,
          timestamps: {
            [session]: newValue ? new Date().toISOString() : null
          },
          notes: notes[student.studentId] || ''
        };
        
        const result = await addAttendance(newRecord);
        
        // Update local state
        setAttendanceList(prev => 
          prev.map(s => 
            s.studentId === student.studentId 
              ? { 
                  ...s, 
                  attendanceId: result.id,
                  [session]: newValue,
                  timestamps: {
                    [session]: newValue ? new Date().toISOString() : null
                  }
                } 
              : s
          )
        );
      }
      
      // Show brief success message
      setSaveMessage('Attendance saved');
      setTimeout(() => setSaveMessage(''), 2000);
      
    } catch (error) {
      console.error('Error updating attendance:', error);
      setError('Failed to update attendance');
    }
  };
  
  // Handle bulk mark attendance
  const handleBulkMark = async (session, value) => {
    try {
      // Process each student
      for (const student of attendanceList) {
        if (student[session] === value) continue; // Skip if already in desired state
        
        if (student.attendanceId) {
          // Update existing record
          await updateAttendance(student.attendanceId, {
            [session]: value,
            timestamps: {
              ...(student.timestamps || {}),
              ...(value ? { [session]: new Date().toISOString() } : {})
            }
          });
        } else {
          // Create new record
          const newRecord = {
            eventId,
            studentId: student.studentId,
            FN: session === 'FN' ? value : false,
            AN: session === 'AN' ? value : false,
            timestamps: {
              [session]: value ? new Date().toISOString() : null
            },
            notes: notes[student.studentId] || ''
          };
          
          const result = await addAttendance(newRecord);
          
          // Update student's attendance ID in local state
          student.attendanceId = result.id;
        }
        
        // Update local state for this student
        student[session] = value;
        if (!student.timestamps) student.timestamps = {};
        if (value) {
          student.timestamps[session] = new Date().toISOString();
        }
      }
      
      // Force a refresh of the attendance list
      setAttendanceList([...attendanceList]);
      
      // Show success message
      setSaveMessage(`All students marked ${value ? 'present' : 'absent'} for ${session}`);
      setTimeout(() => setSaveMessage(''), 3000);
      
    } catch (error) {
      console.error('Error in bulk attendance update:', error);
      setError('Failed to update all attendance records');
    }
  };
  
  // Handle notes changes
  const handleNotesChange = (studentId, value) => {
    setNotes(prev => ({
      ...prev,
      [studentId]: value
    }));
  };
  
  // Save notes to attendance record
  const handleSaveNotes = async (student) => {
    try {
      const noteText = notes[student.studentId] || '';
      
      if (student.attendanceId) {
        // Update existing record
        await updateAttendance(student.attendanceId, {
          notes: noteText
        });
        
        // Update local state
        setAttendanceList(prev => 
          prev.map(s => 
            s.studentId === student.studentId 
              ? { ...s, notes: noteText } 
              : s
          )
        );
      } else {
        // Create new record with just notes
        const newRecord = {
          eventId,
          studentId: student.studentId,
          FN: false,
          AN: false,
          notes: noteText
        };
        
        const result = await addAttendance(newRecord);
        
        // Update local state
        setAttendanceList(prev => 
          prev.map(s => 
            s.studentId === student.studentId 
              ? { ...s, attendanceId: result.id, notes: noteText } 
              : s
          )
        );
      }
      
      // Close form
      setIsFormOpen(false);
      setCurrentStudent(null);
      
      // Show success message
      setSaveMessage('Notes saved');
      setTimeout(() => setSaveMessage(''), 2000);
      
    } catch (error) {
      console.error('Error saving notes:', error);
      setError('Failed to save notes');
    }
  };
  
  // Open notes form for a student
  const openNotesForm = (student) => {
    setCurrentStudent(student);
    setIsFormOpen(true);
  };
  
  if (loading) {
    return <div style={{ textAlign: 'center', padding: '50px' }}>Loading...</div>;
  }
  
  if (error) {
    return (
      <div style={{
        padding: '20px',
        backgroundColor: '#f8d7da',
        color: '#721c24',
        borderRadius: '5px',
        marginBottom: '20px'
      }}>
        <p style={{ margin: '0', fontWeight: 'bold' }}>{error}</p>
        <Link to="/coordinator/events" style={{ color: '#721c24', textDecoration: 'underline' }}>
          Return to Events
        </Link>
      </div>
    );
  }
  
  if (!event) {
    return <div style={{ textAlign: 'center', padding: '50px' }}>Event not found</div>;
  }
  
  const eventDate = new Date(event.date);
  
  return (
    <div>
      <div style={{ 
        display: 'flex', 
        justifyContent: 'space-between', 
        alignItems: 'center',
        marginBottom: '20px'
      }}>
        <div>
          <Link to={`/coordinator/events/${eventId}`} style={{ color: '#666', textDecoration: 'none' }}>
            ← Back to Event
          </Link>
          <h1 style={{ margin: '10px 0 0 0' }}>Attendance: {event.title}</h1>
        </div>
        
        <div>
          <button
            onClick={() => navigate('/coordinator/certificates/' + eventId)}
            style={{
              padding: '10px 20px',
              backgroundColor: '#3498db',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer'
            }}
          >
            Generate Certificates
          </button>
        </div>
      </div>
      
      <div style={{ 
        backgroundColor: 'white',
        borderRadius: '8px',
        padding: '20px',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
        marginBottom: '20px'
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: '10px' }}>
          <div>
            <p style={{ margin: '0 0 5px 0', fontWeight: 'bold' }}>Event Date:</p>
            <p style={{ margin: '0' }}>{eventDate.toLocaleDateString()}</p>
          </div>
          <div>
            <p style={{ margin: '0 0 5px 0', fontWeight: 'bold' }}>Time:</p>
            <p style={{ margin: '0' }}>{event.time}</p>
          </div>
          <div>
            <p style={{ margin: '0 0 5px 0', fontWeight: 'bold' }}>Venue:</p>
            <p style={{ margin: '0' }}>{event.venueName}</p>
          </div>
          <div>
            <p style={{ margin: '0 0 5px 0', fontWeight: 'bold' }}>Club:</p>
            <p style={{ margin: '0' }}>{event.clubName}</p>
          </div>
          <div>
            <p style={{ margin: '0 0 5px 0', fontWeight: 'bold' }}>Total Participants:</p>
            <p style={{ margin: '0' }}>{attendanceList.length}</p>
          </div>
        </div>
      </div>
      
      {/* Bulk actions */}
      <div style={{ 
        backgroundColor: 'white',
        borderRadius: '8px',
        padding: '20px',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
        marginBottom: '20px'
      }}>
        <h2 style={{ marginTop: 0, marginBottom: '15px' }}>Bulk Actions</h2>
        
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '15px' }}>
          <div>
            <h3 style={{ margin: '0 0 10px 0', fontSize: '16px' }}>Forenoon (FN) Session</h3>
            <div style={{ display: 'flex', gap: '10px' }}>
              <button 
                onClick={() => handleBulkMark('FN', true)}
                style={{
                  flex: 1,
                  padding: '8px',
                  backgroundColor: '#27ae60',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
              >
                Mark All Present
              </button>
              <button 
                onClick={() => handleBulkMark('FN', false)}
                style={{
                  flex: 1,
                  padding: '8px',
                  backgroundColor: '#e74c3c',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
              >
                Mark All Absent
              </button>
            </div>
          </div>
          
          <div>
            <h3 style={{ margin: '0 0 10px 0', fontSize: '16px' }}>Afternoon (AN) Session</h3>
            <div style={{ display: 'flex', gap: '10px' }}>
              <button 
                onClick={() => handleBulkMark('AN', true)}
                // src/pages/coordinator/AttendanceManagement.js (continued)
                style={{
                  flex: 1,
                  padding: '8px',
                  backgroundColor: '#27ae60',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
              >
                Mark All Present
              </button>
              <button 
                onClick={() => handleBulkMark('AN', false)}
                style={{
                  flex: 1,
                  padding: '8px',
                  backgroundColor: '#e74c3c',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
              >
                Mark All Absent
              </button>
            </div>
          </div>
        </div>
        
        {/* Save message */}
        {saveMessage && (
          <div style={{ 
            marginTop: '15px',
            padding: '10px',
            backgroundColor: '#d4edda',
            color: '#155724',
            borderRadius: '4px',
            textAlign: 'center'
          }}>
            {saveMessage}
          </div>
        )}
      </div>
      
      {/* Attendance Table */}
      <div style={{ 
        backgroundColor: 'white',
        borderRadius: '8px',
        padding: '20px',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
      }}>
        <h2 style={{ marginTop: 0 }}>Participant Attendance</h2>
        
        {attendanceList.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '30px 0', color: '#666' }}>
            <p>No students have registered for this event yet.</p>
          </div>
        ) : (
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ backgroundColor: '#f8f9fa' }}>
                  <th style={{ padding: '12px 15px', textAlign: 'left', borderBottom: '1px solid #ddd' }}>#</th>
                  <th style={{ padding: '12px 15px', textAlign: 'left', borderBottom: '1px solid #ddd' }}>Student</th>
                  <th style={{ padding: '12px 15px', textAlign: 'center', borderBottom: '1px solid #ddd' }}>FN Session</th>
                  <th style={{ padding: '12px 15px', textAlign: 'center', borderBottom: '1px solid #ddd' }}>AN Session</th>
                  <th style={{ padding: '12px 15px', textAlign: 'center', borderBottom: '1px solid #ddd' }}>Eligibility</th>
                  <th style={{ padding: '12px 15px', textAlign: 'right', borderBottom: '1px solid #ddd' }}>Notes</th>
                </tr>
              </thead>
              <tbody>
                {attendanceList.map((student, index) => (
                  <tr key={student.registrationId} style={{ backgroundColor: index % 2 === 0 ? '#ffffff' : '#f8f9fa' }}>
                    <td style={{ padding: '12px 15px', borderBottom: '1px solid #ddd' }}>{index + 1}</td>
                    <td style={{ padding: '12px 15px', borderBottom: '1px solid #ddd' }}>
                      <div style={{ fontWeight: 'bold' }}>{student.name}</div>
                      <div style={{ fontSize: '12px', color: '#666' }}>{student.email}</div>
                    </td>
                    <td style={{ padding: '12px 15px', borderBottom: '1px solid #ddd', textAlign: 'center' }}>
                      <button
                        onClick={() => handleToggleAttendance(student, 'FN')}
                        style={{
                          padding: '8px 15px',
                          backgroundColor: student.FN ? '#27ae60' : '#e74c3c',
                          color: 'white',
                          border: 'none',
                          borderRadius: '4px',
                          cursor: 'pointer',
                          width: '100px'
                        }}
                      >
                        {student.FN ? 'Present' : 'Absent'}
                      </button>
                    </td>
                    <td style={{ padding: '12px 15px', borderBottom: '1px solid #ddd', textAlign: 'center' }}>
                      <button
                        onClick={() => handleToggleAttendance(student, 'AN')}
                        style={{
                          padding: '8px 15px',
                          backgroundColor: student.AN ? '#27ae60' : '#e74c3c',
                          color: 'white',
                          border: 'none',
                          borderRadius: '4px',
                          cursor: 'pointer',
                          width: '100px'
                        }}
                      >
                        {student.AN ? 'Present' : 'Absent'}
                      </button>
                    </td>
                    <td style={{ padding: '12px 15px', borderBottom: '1px solid #ddd', textAlign: 'center' }}>
                      <span style={{
                        display: 'inline-block',
                        padding: '5px 10px',
                        backgroundColor: student.FN && student.AN ? '#d4edda' : '#f8d7da',
                        color: student.FN && student.AN ? '#155724' : '#721c24',
                        borderRadius: '4px',
                        fontSize: '14px'
                      }}>
                        {student.FN && student.AN ? 'Eligible' : 'Not Eligible'}
                      </span>
                    </td>
                    <td style={{ padding: '12px 15px', borderBottom: '1px solid #ddd', textAlign: 'right' }}>
                      <button
                        onClick={() => openNotesForm(student)}
                        style={{
                          padding: '5px 10px',
                          backgroundColor: student.notes ? '#3498db' : '#f0f0f0',
                          color: student.notes ? 'white' : '#333',
                          border: 'none',
                          borderRadius: '4px',
                          cursor: 'pointer'
                        }}
                      >
                        {student.notes ? 'Edit Notes' : 'Add Notes'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
      
      {/* Notes Modal */}
      {isFormOpen && currentStudent && (
        <div style={{ 
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000
        }}>
          <div style={{ 
            backgroundColor: 'white',
            borderRadius: '8px',
            padding: '20px',
            width: '500px',
            maxWidth: '90%'
          }}>
            <h2 style={{ marginTop: 0 }}>Attendance Notes</h2>
            <p style={{ margin: '0 0 15px 0' }}>Student: {currentStudent.name}</p>
            
            <textarea
              value={notes[currentStudent.studentId] || ''}
              onChange={(e) => handleNotesChange(currentStudent.studentId, e.target.value)}
              placeholder="Enter notes about this student's attendance..."
              rows={6}
              style={{
                width: '100%',
                padding: '10px',
                borderRadius: '4px',
                border: '1px solid #ddd',
                marginBottom: '20px',
                resize: 'vertical'
              }}
            />
            
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px' }}>
              <button
                onClick={() => {
                  setIsFormOpen(false);
                  setCurrentStudent(null);
                }}
                style={{
                  padding: '8px 15px',
                  backgroundColor: '#f0f0f0',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
              >
                Cancel
              </button>
              <button
                onClick={() => handleSaveNotes(currentStudent)}
                style={{
                  padding: '8px 15px',
                  backgroundColor: '#3498db',
                  color: 'white',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: 'pointer'
                }}
              >
                Save Notes
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AttendanceManagement;
