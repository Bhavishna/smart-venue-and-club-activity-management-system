import React, { useState, useEffect } from 'react';
import useCollection from '../../hooks/useCollection';

const ClubManagement = () => {
  const { items: clubs, loading: clubsLoading, addItem, updateItem, deleteItem } = useCollection('clubs');
  const { items: users, loading: usersLoading } = useCollection('users');
  const { items: clubMembers } = useCollection('club_members');

  const [filteredClubs, setFilteredClubs] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [currentClub, setCurrentClub] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [memberCounts, setMemberCounts] = useState({});

  // Form state
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    facultyCoordinatorId: '',
    studentCoordinatorId: ''
  });

  // Filter faculty and student coordinator users
  const facultyUsers = users.filter(user => user.role === 'faculty' || user.role === 'admin');
  const studentCoordinatorUsers = users.filter(user => user.role === 'studentCoordinator');

  // Update filtered clubs when clubs or search term changes
  useEffect(() => {
    if (!clubs) return;
    
    let result = [...clubs];
    
    // Apply search filter
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      result = result.filter(club => 
        club.name.toLowerCase().includes(term) || 
        club.description.toLowerCase().includes(term)
      );
    }
    
    setFilteredClubs(result);
  }, [clubs, searchTerm]);

  // Calculate member counts for each club
  useEffect(() => {
    const counts = {};
    clubMembers.forEach(member => {
      counts[member.clubId] = (counts[member.clubId] || 0) + 1;
    });
    setMemberCounts(counts);
  }, [clubMembers]);

  // Handle input change
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  // Reset form
  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      facultyCoordinatorId: '',
      studentCoordinatorId: ''
    });
    setCurrentClub(null);
  };

  // Open modal to add new club
  const openAddModal = () => {
    resetForm();
    setIsModalOpen(true);
  };

  // Open modal to edit club
  const openEditModal = (club) => {
    setCurrentClub(club);
    setFormData({
      name: club.name,
      description: club.description,
      facultyCoordinatorId: club.facultyCoordinatorId,
      studentCoordinatorId: club.studentCoordinatorId
    });
    setIsModalOpen(true);
  };

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (currentClub) {
      updateItem(currentClub.id, formData);
    } else {
      addItem(formData);
    }
    
    setIsModalOpen(false);
    resetForm();
  };

  // Handle club deletion
  const handleDelete = (clubId) => {
    if (window.confirm('Are you sure you want to delete this club?')) {
      deleteItem(clubId);
    }
  };

  // Find user name by ID
  const getUserName = (userId) => {
    const user = users.find(u => u.id === userId);
    return user ? user.name : 'Not Assigned';
  };

  const loading = clubsLoading || usersLoading;

  return (
    <div>
      <div style={{ 
        display: 'flex', 
        justifyContent: 'space-between', 
        alignItems: 'center',
        marginBottom: '20px'
      }}>
        <h1 style={{ margin: 0 }}>Club Management</h1>
        
        <button 
          onClick={openAddModal}
          style={{
            backgroundColor: '#3498db',
            color: 'white',
            border: 'none',
            padding: '10px 20px',
            borderRadius: '4px',
            cursor: 'pointer'
          }}
        >
          Create New Club
        </button>
      </div>
      
      <div style={{ 
        marginBottom: '20px',
        backgroundColor: 'white',
        padding: '15px',
        borderRadius: '8px',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
      }}>
        <input
          type="text"
          placeholder="Search clubs..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          style={{
            width: '100%',
            padding: '10px',
            border: '1px solid #ddd',
            borderRadius: '4px'
          }}
        />
      </div>
      
      {loading ? (
        <div style={{ textAlign: 'center', padding: '40px 0' }}>Loading...</div>
      ) : (
        <div style={{ 
          display: 'grid', 
          gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', 
          gap: '20px'
        }}>
          {filteredClubs.length > 0 ? (
            filteredClubs.map(club => (
              <div key={club.id} style={{
                backgroundColor: 'white',
                borderRadius: '8px',
                overflow: 'hidden',
                boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
              }}>
                <div style={{ padding: '20px' }}>
                  <h2 style={{ margin: '0 0 10px 0', fontSize: '18px' }}>{club.name}</h2>
                  <p style={{ 
                    margin: '0 0 15px 0', 
                    color: '#7f8c8d',
                    minHeight: '60px',
                    maxHeight: '80px',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis'
                  }}>
                    {club.description}
                  </p>
                  
                  <div style={{ marginBottom: '15px' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '5px' }}>
                      <span style={{ color: '#7f8c8d' }}>Faculty Coordinator:</span>
                      <span>{getUserName(club.facultyCoordinatorId)}</span>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                      <span style={{ color: '#7f8c8d' }}>Student Coordinator:</span>
                      <span>{getUserName(club.studentCoordinatorId)}</span>
                    </div>
                  </div>
                  
                  <div style={{ 
                    backgroundColor: '#f8f9fa',
                    padding: '10px',
                    borderRadius: '4px',
                    textAlign: 'center',
                    marginBottom: '15px'
                  }}>
                    <span style={{ fontWeight: 'bold' }}>
                      {memberCounts[club.id] || 0} Members
                    </span>
                  </div>
                  
                  <div style={{ display: 'flex', gap: '10px' }}>
                    <button
                      onClick={() => openEditModal(club)}
                      style={{
                        flex: 1,
                        padding: '8px 0',
                        backgroundColor: '#3498db',
                        color: 'white',
                        border: 'none',
                        borderRadius: '4px',
                        cursor: 'pointer'
                      }}
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => handleDelete(club.id)}
                      style={{
                        flex: 1,
                        padding: '8px 0',
                        backgroundColor: '#e74c3c',
                        color: 'white',
                        border: 'none',
                        borderRadius: '4px',
                        cursor: 'pointer'
                      }}
                    >
                      Delete
                    </button>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div style={{ 
              gridColumn: '1 / -1', 
              padding: '30px', 
              textAlign: 'center',
              backgroundColor: 'white',
              borderRadius: '8px'
            }}>
              No clubs found matching your search
            </div>
          )}
        </div>
      )}
      
      {/* Club Modal */}
      {isModalOpen && (
        <div style={{ 
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0,0,0,0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000
        }}>
          <div style={{ 
            backgroundColor: 'white',
            borderRadius: '8px',
            width: '100%',
            maxWidth: '500px',
            padding: '20px',
            boxShadow: '0 4px 8px rgba(0,0,0,0.1)'
          }}>
            <h2 style={{ marginTop: 0 }}>{currentClub ? 'Edit Club' : 'Create New Club'}</h2>
            
            <form onSubmit={handleSubmit}>
              <div style={{ marginBottom: '15px' }}>
                <label style={{ display: 'block', marginBottom: '5px' }}>Club Name</label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  required
                  style={{
                    width: '100%',
                    padding: '10px',
                    border: '1px solid #ddd',
                    borderRadius: '4px'
                  }}
                />
              </div>
              
              <div style={{ marginBottom: '15px' }}>
                <label style={{ display: 'block', marginBottom: '5px' }}>Description</label>
                <textarea
                  name="description"
                  value={formData.description}
                  onChange={handleInputChange}
                  required
                  rows={4}
                  style={{
                    width: '100%',
                    padding: '10px',
                    border: '1px solid #ddd',
                    borderRadius: '4px',
                    resize: 'vertical'
                  }}
                ></textarea>
              </div>
              
              <div style={{ marginBottom: '15px' }}>
                <label style={{ display: 'block', marginBottom: '5px' }}>Faculty Coordinator</label>
                <select
                  name="facultyCoordinatorId"
                  value={formData.facultyCoordinatorId}
                  onChange={handleInputChange}
                  required
                  style={{
                    width: '100%',
                    padding: '10px',
                    border: '1px solid #ddd',
                    borderRadius: '4px',
                    backgroundColor: 'white'
                  }}
                >
                  <option value="">Select Faculty Coordinator</option>
                  {facultyUsers.map(user => (
                    <option key={user.id} value={user.id}>{user.name} ({user.email})</option>
                  ))}
                </select>
              </div>
              
              <div style={{ marginBottom: '20px' }}>
                <label style={{ display: 'block', marginBottom: '5px' }}>Student Coordinator</label>
                <select
                  name="studentCoordinatorId"
                  value={formData.studentCoordinatorId}
                  onChange={handleInputChange}
                  required
                  style={{
                    width: '100%',
                    padding: '10px',
                    border: '1px solid #ddd',
                    borderRadius: '4px',
                    backgroundColor: 'white'
                  }}
                >
                  <option value="">Select Student Coordinator</option>
                  {studentCoordinatorUsers.map(user => (
                    <option key={user.id} value={user.id}>{user.name} ({user.email})</option>
                  ))}
                </select>
              </div>
              
              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px' }}>
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  style={{
                    padding: '10px 20px',
                    backgroundColor: '#7f8c8d',
                    color: 'white',
                    border: 'none',
                    borderRadius: '4px',
                    cursor: 'pointer'
                  }}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  style={{
                    padding: '10px 20px',
                    backgroundColor: currentClub ? '#2ecc71' : '#3498db',
                    color: 'white',
                    border: 'none',
                    borderRadius: '4px',
                    cursor: 'pointer'
                  }}
                >
                  {currentClub ? 'Update Club' : 'Create Club'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default ClubManagement;
