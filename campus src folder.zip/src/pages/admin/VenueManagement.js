import React, { useState, useEffect } from 'react';
import useCollection from '../../hooks/useCollection';

const VenueManagement = () => {
  const { items: venues, loading, addItem, updateItem, deleteItem } = useCollection('venues');
  const { items: events } = useCollection('events');
  
  const [filteredVenues, setFilteredVenues] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [currentVenue, setCurrentVenue] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [venueUsage, setVenueUsage] = useState({});

  // Form state
  const [formData, setFormData] = useState({
    name: '',
    capacity: 0
  });

  // Update filtered venues when venues or search term changes
  useEffect(() => {
    if (!venues) return;
    
    let result = [...venues];
    
    // Apply search filter
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      result = result.filter(venue => 
        venue.name.toLowerCase().includes(term)
      );
    }
    
    // Sort by name
    result.sort((a, b) => a.name.localeCompare(b.name));
    
    setFilteredVenues(result);
  }, [venues, searchTerm]);

  // Calculate venue usage
  useEffect(() => {
    const usage = {};
    events.forEach(event => {
      usage[event.venueId] = (usage[event.venueId] || 0) + 1;
    });
    setVenueUsage(usage);
  }, [events]);

  // Handle input change
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: name === 'capacity' ? parseInt(value, 10) || 0 : value
    });
  };

  // Reset form
  const resetForm = () => {
    setFormData({
      name: '',
      capacity: 0
    });
    setCurrentVenue(null);
  };

  // Open modal to add new venue
  const openAddModal = () => {
    resetForm();
    setIsModalOpen(true);
  };

  // Open modal to edit venue
  const openEditModal = (venue) => {
    setCurrentVenue(venue);
    setFormData({
      name: venue.name,
      capacity: venue.capacity
    });
    setIsModalOpen(true);
  };

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (currentVenue) {
      updateItem(currentVenue.id, formData);
    } else {
      addItem(formData);
    }
    
    setIsModalOpen(false);
    resetForm();
  };

  // Handle venue deletion
  const handleDelete = (venueId) => {
    // Check if venue is being used by any events
    const isUsed = events.some(event => event.venueId === venueId);
    
    if (isUsed) {
      alert('This venue cannot be deleted because it is currently in use by one or more events.');
      return;
    }
    
    if (window.confirm('Are you sure you want to delete this venue?')) {
      deleteItem(venueId);
    }
  };

  return (
    <div>
      <div style={{ 
        display: 'flex', 
        justifyContent: 'space-between', 
        alignItems: 'center',
        marginBottom: '20px'
      }}>
        <h1 style={{ margin: 0 }}>Venue Management</h1>
        
        <button 
          onClick={openAddModal}
          style={{
            backgroundColor: '#3498db',
            color: 'white',
            border: 'none',
            padding: '10px 20px',
            borderRadius: '4px',
            cursor: 'pointer'
          }}
        >
          Add New Venue
        </button>
      </div>
      
      <div style={{ 
        marginBottom: '20px',
        backgroundColor: 'white',
        padding: '15px',
        borderRadius: '8px',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
      }}>
        <input
          type="text"
          placeholder="Search venues..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          style={{
            width: '100%',
            padding: '10px',
            border: '1px solid #ddd',
            borderRadius: '4px'
          }}
        />
      </div>
      
      {loading ? (
        <div style={{ textAlign: 'center', padding: '40px 0' }}>Loading...</div>
      ) : (
        <div style={{ 
          backgroundColor: 'white',
          borderRadius: '8px',
          overflow: 'hidden',
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
        }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ backgroundColor: '#f8f9fa' }}>
                <th style={{ padding: '12px 15px', textAlign: 'left', borderBottom: '1px solid #ddd' }}>Venue Name</th>
                <th style={{ padding: '12px 15px', textAlign: 'left', borderBottom: '1px solid #ddd' }}>Capacity</th>
                <th style={{ padding: '12px 15px', textAlign: 'left', borderBottom: '1px solid #ddd' }}>Events Hosted</th>
                <th style={{ padding: '12px 15px', textAlign: 'right', borderBottom: '1px solid #ddd' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredVenues.length > 0 ? (
                filteredVenues.map(venue => (
                  <tr key={venue.id}>
                    <td style={{ padding: '12px 15px', borderBottom: '1px solid #ddd' }}>{venue.name}</td>
                    <td style={{ padding: '12px 15px', borderBottom: '1px solid #ddd' }}>
                      {venue.capacity} {venue.capacity === 1 ? 'person' : 'people'}
                    </td>
                    <td style={{ padding: '12px 15px', borderBottom: '1px solid #ddd' }}>
                      <span style={{ 
                        display: 'inline-block',
                        padding: '4px 8px',
                        borderRadius: '4px',
                        backgroundColor: venueUsage[venue.id] ? '#3498db' : '#ecf0f1',
                        color: venueUsage[venue.id] ? 'white' : '#95a5a6',
                        fontSize: '12px'
                      }}>
                        {venueUsage[venue.id] || 0} events
                      </span>
                    </td>
                    <td style={{ padding: '12px 15px', textAlign: 'right', borderBottom: '1px solid #ddd' }}>
                      <button
                        onClick={() => openEditModal(venue)}
                        style={{
                          backgroundColor: '#3498db',
                          color: 'white',
                          border: 'none',
                          padding: '6px 12px',
                          borderRadius: '4px',
                          marginRight: '8px',
                          cursor: 'pointer'
                        }}
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => handleDelete(venue.id)}
                        style={{
                          backgroundColor: '#e74c3c',
                          color: 'white',
                          border: 'none',
                          padding: '6px 12px',
                          borderRadius: '4px',
                          cursor: 'pointer',
                          opacity: venueUsage[venue.id] ? 0.5 : 1,
                          cursor: venueUsage[venue.id] ? 'not-allowed' : 'pointer'
                        }}
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="4" style={{ padding: '20px', textAlign: 'center', color: '#7f8c8d' }}>
                    No venues found matching your criteria
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
      
      {/* Venue Modal */}
      {isModalOpen && (
        <div style={{ 
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0,0,0,0.5)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000
        }}>
          <div style={{ 
            backgroundColor: 'white',
            borderRadius: '8px',
            width: '100%',
            maxWidth: '500px',
            padding: '20px',
            boxShadow: '0 4px 8px rgba(0,0,0,0.1)'
          }}>
            <h2 style={{ marginTop: 0 }}>{currentVenue ? 'Edit Venue' : 'Add New Venue'}</h2>
            
            <form onSubmit={handleSubmit}>
              <div style={{ marginBottom: '15px' }}>
                <label style={{ display: 'block', marginBottom: '5px' }}>Venue Name</label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  required
                  style={{
                    width: '100%',
                    padding: '10px',
                    border: '1px solid #ddd',
                    borderRadius: '4px'
                  }}
                />
              </div>
              
              <div style={{ marginBottom: '20px' }}>
                <label style={{ display: 'block', marginBottom: '5px' }}>Capacity</label>
                <input
                  type="number"
                  name="capacity"
                  value={formData.capacity}
                  onChange={handleInputChange}
                  required
                  min="1"
                  style={{
                    width: '100%',
                    padding: '10px',
                    border: '1px solid #ddd',
                    borderRadius: '4px'
                  }}
                />
              </div>
              
              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '10px' }}>
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  style={{
                    padding: '10px 20px',
                    backgroundColor: '#7f8c8d',
                    color: 'white',
                    border: 'none',
                    borderRadius: '4px',
                    cursor: 'pointer'
                  }}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  style={{
                    padding: '10px 20px',
                    backgroundColor: currentVenue ? '#2ecc71' : '#3498db',
                    color: 'white',
                    border: 'none',
                    borderRadius: '4px',
                    cursor: 'pointer'
                  }}
                >
                  {currentVenue ? 'Update Venue' : 'Add Venue'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default VenueManagement;
