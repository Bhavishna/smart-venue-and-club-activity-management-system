// src/pages/admin/Reports.js
import React, { useState, useEffect, useRef } from 'react';
import useCollectionData from '../../hooks/useCollection';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

const Reports = () => {
  const { items: clubs } = useCollectionData('clubs');
  const { items: clubMembers } = useCollectionData('club_members');
  const { items: events } = useCollectionData('events');
  const { items: eventRegistrations } = useCollectionData('event_registrations');
  const { items: users } = useCollectionData('users');
  const { items: venues } = useCollectionData('venues');

  const [activeTab, setActiveTab] = useState('membership');
  const [csvData, setCsvData] = useState('');
  const [reportTitle, setReportTitle] = useState('Club Membership Report');
  const reportRef = useRef(null);

  // For date filtering
  const [dateRange, setDateRange] = useState({
    start: '',
    end: ''
  });

  // Calculate statistics when data changes
  useEffect(() => {
    if (activeTab === 'membership') {
      setReportTitle('Club Membership Report');
    } else if (activeTab === 'events') {
      setReportTitle('Event Activity Report');
    } else if (activeTab === 'users') {
      setReportTitle('User Statistics Report');
    }
  }, [activeTab]);

  // For club membership stats
  const membershipStats = clubs.map(club => {
    const memberCount = clubMembers.filter(member => member.clubId === club.id).length;
    const facultyCoordinator = users.find(user => user.id === club.facultyCoordinatorId);
    const studentCoordinator = users.find(user => user.id === club.studentCoordinatorId);
    
    return {
      id: club.id,
      name: club.name,
      memberCount,
      facultyCoordinator: facultyCoordinator ? facultyCoordinator.name : 'Not Assigned',
      studentCoordinator: studentCoordinator ? studentCoordinator.name : 'Not Assigned'
    };
  });

  // For event stats
  const eventStats = events.map(event => {
    const registrationCount = eventRegistrations.filter(reg => reg.eventId === event.id).length;
    const club = clubs.find(club => club.id === event.clubId);
    const venue = venues.find(venue => venue.id === event.venueId);
    
    return {
      id: event.id,
      title: event.title,
      date: event.date,
      registrationCount,
      club: club ? club.name : 'Unknown Club',
      venue: venue ? venue.name : 'Unknown Venue',
      approved: event.approved ? 'Yes' : 'No'
    };
  }).filter(event => {
    // Apply date range filter if it exists
    if (dateRange.start && dateRange.end) {
      const eventDate = new Date(event.date);
      const startDate = new Date(dateRange.start);
      const endDate = new Date(dateRange.end);
      endDate.setHours(23, 59, 59); // Include the entire end day
      
      return eventDate >= startDate && eventDate <= endDate;
    }
    return true;
  });

  // For user stats
  const userStats = {
    total: users.length,
    byRole: users.reduce((acc, user) => {
      acc[user.role] = (acc[user.role] || 0) + 1;
      return acc;
    }, {})
  };

  // Generate CSV data
  const generateCSV = () => {
    let csvContent = '';
    
    if (activeTab === 'membership') {
      // CSV headers
      csvContent = 'Club Name,Member Count,Faculty Coordinator,Student Coordinator\n';
      
      // CSV rows
      membershipStats.forEach(stat => {
        csvContent += `"${stat.name}",${stat.memberCount},"${stat.facultyCoordinator}","${stat.studentCoordinator}"\n`;
      });
    } else if (activeTab === 'events') {
      // CSV headers
      csvContent = 'Event Title,Date,Registration Count,Club,Venue,Approved\n';
      
      // CSV rows
      eventStats.forEach(stat => {
        csvContent += `"${stat.title}","${stat.date}",${stat.registrationCount},"${stat.club}","${stat.venue}","${stat.approved}"\n`;
      });
    } else if (activeTab === 'users') {
      // CSV headers
      csvContent = 'Role,Count\n';
      
      // CSV rows
      Object.entries(userStats.byRole).forEach(([role, count]) => {
        csvContent += `"${role}",${count}\n`;
      });
      csvContent += `"Total",${userStats.total}\n`;
    }
    
    setCsvData(csvContent);
    return csvContent; // Return the generated content for immediate use
  };

  // Download CSV
  const downloadCSV = () => {
    const content = generateCSV(); // Get the fresh CSV content
    
    const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `${reportTitle.replace(/\s+/g, '_').toLowerCase()}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Download PDF
  const downloadPDF = () => {
    if (reportRef.current) {
      html2canvas(reportRef.current).then(canvas => {
        const imgData = canvas.toDataURL('image/png');
        const pdf = new jsPDF('p', 'mm', 'a4');
        const imgProps = pdf.getImageProperties(imgData);
        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
        
        pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
        pdf.save(`${reportTitle.replace(/\s+/g, '_').toLowerCase()}.pdf`);
      });
    }
  };

  // Handle date range change
  const handleDateChange = (e) => {
    const { name, value } = e.target;
    setDateRange(prev => ({
      ...prev,
      [name]: value
    }));
  };

  return (
    <div>
      <div style={{ 
        display: 'flex', 
        justifyContent: 'space-between', 
        alignItems: 'center',
        marginBottom: '20px'
      }}>
        <h1 style={{ margin: 0 }}>Reports</h1>
        
        <div style={{ display: 'flex', gap: '10px' }}>
          <button 
            onClick={downloadCSV}
            style={{
              backgroundColor: '#2ecc71',
              color: 'white',
              border: 'none',
              padding: '10px 15px',
              borderRadius: '4px',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center'
            }}
          >
            Export CSV
          </button>
          
          <button 
            onClick={downloadPDF}
            style={{
              backgroundColor: '#e74c3c',
              color: 'white',
              border: 'none',
              padding: '10px 15px',
              borderRadius: '4px',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center'
            }}
          >
            Export PDF
          </button>
        </div>
      </div>
      
      <div style={{ 
        backgroundColor: 'white',
        borderRadius: '8px',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
        marginBottom: '20px'
      }}>
        <div style={{ display: 'flex', borderBottom: '1px solid #ddd' }}>
          <button 
            onClick={() => setActiveTab('membership')}
            style={{
              flex: 1,
              padding: '15px',
              backgroundColor: activeTab === 'membership' ? '#3498db' : 'transparent',
              color: activeTab === 'membership' ? 'white' : '#333',
              border: 'none',
              borderRadius: activeTab === 'membership' ? '8px 0 0 0' : '0',
              cursor: 'pointer',
              fontWeight: activeTab === 'membership' ? 'bold' : 'normal'
            }}
          >
            Club Membership
          </button>
          
          <button 
            onClick={() => setActiveTab('events')}
            style={{
              flex: 1,
              padding: '15px',
              backgroundColor: activeTab === 'events' ? '#3498db' : 'transparent',
              color: activeTab === 'events' ? 'white' : '#333',
              border: 'none',
              cursor: 'pointer',
              fontWeight: activeTab === 'events' ? 'bold' : 'normal'
            }}
          >
            Event Activity
          </button>
          
          <button 
            onClick={() => setActiveTab('users')}
            style={{
              flex: 1,
              padding: '15px',
              backgroundColor: activeTab === 'users' ? '#3498db' : 'transparent',
              color: activeTab === 'users' ? 'white' : '#333',
              border: 'none',
              borderRadius: activeTab === 'users' ? '0 8px 0 0' : '0',
              cursor: 'pointer',
              fontWeight: activeTab === 'users' ? 'bold' : 'normal'
            }}
          >
            User Statistics
          </button>
        </div>
        
        {/* Date filter for events tab */}
        {activeTab === 'events' && (
          <div style={{ 
            padding: '15px', 
            display: 'flex', 
            gap: '20px', 
            alignItems: 'center',
            borderBottom: '1px solid #ddd'
          }}>
            <div>
              <label style={{ marginRight: '10px' }}>Date Range:</label>
              <input 
                type="date" 
                name="start"
                value={dateRange.start}
                onChange={handleDateChange}
                style={{
                  padding: '8px',
                  border: '1px solid #ddd',
                  borderRadius: '4px',
                  marginRight: '10px'
                }}
              />
              <span>to</span>
              <input 
                type="date"
                name="end"
                value={dateRange.end}
                onChange={handleDateChange}
                style={{
                  padding: '8px',
                  border: '1px solid #ddd',
                  borderRadius: '4px',
                  marginLeft: '10px'
                }}
              />
            </div>
          </div>
        )}
        
        {/* Report content */}
        <div style={{ padding: '20px' }} ref={reportRef}>
          <h2 style={{ marginTop: 0, marginBottom: '20px' }}>{reportTitle}</h2>
          
          {activeTab === 'membership' && (
            <div>
              <p>Club membership statistics and visualizations will appear here.</p>
            </div>
          )}
          
          {activeTab === 'events' && (
            <div>
              <p>Event activity statistics will appear here.</p>
            </div>
          )}
          
          {activeTab === 'users' && (
            <div>
              <p>User statistics will appear here.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// Helper functions
const getMemberCountColor = (count) => {
  if (count >= 20) return '#e74c3c';
  if (count >= 10) return '#f39c12';
  if (count >= 5) return '#2ecc71';
  return '#3498db';
};

const getRegistrationCountColor = (count) => {
  if (count >= 30) return '#e74c3c';
  if (count >= 15) return '#f39c12';
  if (count >= 5) return '#2ecc71';
  return '#3498db';
};

const getRoleColor = (role) => {
  switch(role) {
    case 'admin': return '#e74c3c';
    case 'faculty': return '#3498db';
    case 'studentCoordinator': return '#2ecc71';
    case 'student': return '#f39c12';
    default: return '#95a5a6';
  }
};

export default Reports;
