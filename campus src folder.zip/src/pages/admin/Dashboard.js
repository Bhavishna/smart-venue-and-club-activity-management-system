// src/pages/admin/Dashboard.js
import React from 'react';
import { Link } from 'react-router-dom';
import useCollectionData from '../../hooks/useCollection';

const AdminDashboard = () => {
  const { items: users } = useCollectionData('users');
  const { items: clubs } = useCollectionData('clubs');
  const { items: venues } = useCollectionData('venues');
  const { items: events } = useCollectionData('events');
  const { items: eventRegistrations } = useCollectionData('event_registrations');

  // Calculate statistics
  const usersByRole = users.reduce((acc, user) => {
    acc[user.role] = (acc[user.role] || 0) + 1;
    return acc;
  }, {});

  const pendingEvents = events.filter(event => 
    event.requiresApproval && !event.approved
  ).length;

  const upcomingEvents = events.filter(event => {
    const eventDate = new Date(event.date);
    const now = new Date();
    return eventDate > now;
  }).length;

  // Get total registrations
  const totalRegistrations = eventRegistrations.length;

  // Get latest users (5 most recent)
  const latestUsers = [...users]
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .slice(0, 5);

  // Get club with most members
  const clubMemberships = {};
  const { items: clubMembers } = useCollectionData('club_members');
  
  clubMembers.forEach(member => {
    clubMemberships[member.clubId] = (clubMemberships[member.clubId] || 0) + 1;
  });

  const mostPopularClubId = Object.entries(clubMemberships)
    .sort(([, countA], [, countB]) => countB - countA)
    .map(([id]) => id)[0];
    
  const mostPopularClub = clubs.find(club => club.id === mostPopularClubId);

  // Card component for statistics
  const StatCard = ({ title, value, color, icon, link }) => (
    <div style={{
      backgroundColor: 'white',
      borderRadius: '8px',
      padding: '20px',
      boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
      position: 'relative',
      overflow: 'hidden'
    }}>
      <div style={{ marginBottom: '10px' }}>
        <h3 style={{ margin: '0', fontSize: '16px', color: '#666' }}>{title}</h3>
        <p style={{ margin: '10px 0 0 0', fontSize: '28px', fontWeight: 'bold' }}>{value}</p>
      </div>
      {link && (
        <Link to={link} style={{ 
          display: 'inline-block', 
          marginTop: '10px',
          color: color,
          textDecoration: 'none',
          fontSize: '14px',
          fontWeight: 'bold'
        }}>
          View Details →
        </Link>
      )}
      {icon && (
        <div style={{ 
          position: 'absolute', 
          top: '15px', 
          right: '15px',
          width: '40px',
          height: '40px',
          borderRadius: '50%',
          backgroundColor: `${color}20`, // Light version of the color
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: color,
          fontSize: '20px'
        }}>
          {icon}
        </div>
      )}
    </div>
  );

  return (
    <div>
      <h1 style={{ marginBottom: '30px' }}>Admin Dashboard</h1>

      <div style={{ 
        display: 'grid', 
        gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', 
        gap: '20px',
        marginBottom: '30px'
      }}>
        <StatCard 
          title="Total Users" 
          value={users.length} 
          color="#3498db" 
          icon="👥" 
          link="/admin/users"
        />
        <StatCard 
          title="Total Clubs" 
          value={clubs.length} 
          color="#2ecc71" 
          icon="🏛️" 
          link="/admin/clubs"
        />
        <StatCard 
          title="Available Venues" 
          value={venues.length} 
          color="#9b59b6" 
          icon="🏢" 
          link="/admin/venues"
        />
        <StatCard 
          title="Upcoming Events" 
          value={upcomingEvents} 
          color="#e67e22" 
          icon="📅" 
        />
      </div>

      <div style={{ display: 'flex', gap: '20px', marginBottom: '30px', flexWrap: 'wrap' }}>
        {/* User role breakdown */}
        <div style={{
          flex: '1 1 400px',
          backgroundColor: 'white',
          borderRadius: '8px',
          padding: '20px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
            <h3 style={{ marginTop: 0, marginBottom: 0 }}>User Role Distribution</h3>
            <Link 
              to="/admin/reports" 
              style={{ fontSize: '14px', color: '#3498db', textDecoration: 'none' }}
            >
              View Reports →
            </Link>
          </div>
          
          <div>
            {Object.entries(usersByRole).map(([role, count]) => (
              <div key={role} style={{ marginBottom: '15px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '5px' }}>
                  <span style={{ textTransform: 'capitalize' }}>{role}</span>
                  <span>{count}</span>
                </div>
                <div style={{ 
                  height: '10px', 
                  backgroundColor: '#ecf0f1',
                  borderRadius: '5px',
                  overflow: 'hidden'
                }}>
                  <div style={{ 
                    height: '100%', 
                    width: `${(count / users.length) * 100}%`,
                    backgroundColor: roleColor(role),
                    borderRadius: '5px'
                  }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick actions */}
        <div style={{
          flex: '1 1 300px',
          backgroundColor: 'white',
          borderRadius: '8px',
          padding: '20px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
        }}>
          <h3 style={{ marginTop: 0 }}>Quick Actions</h3>
          
          <div style={{ display: 'grid', gap: '10px' }}>
            <Link to="/admin/users" style={{ 
              display: 'block',
              padding: '12px 15px',
              backgroundColor: '#3498db',
              color: 'white',
              textDecoration: 'none',
              borderRadius: '4px',
              textAlign: 'center'
            }}>
              Add New User
            </Link>
            
            <Link to="/admin/clubs" style={{ 
              display: 'block',
              padding: '12px 15px',
              backgroundColor: '#2ecc71',
              color: 'white',
              textDecoration: 'none',
              borderRadius: '4px',
              textAlign: 'center'
            }}>
              Manage Clubs
            </Link>
            
            <Link to="/admin/venues" style={{ 
              display: 'block',
              padding: '12px 15px',
              backgroundColor: '#9b59b6',
              color: 'white',
              textDecoration: 'none',
              borderRadius: '4px',
              textAlign: 'center'
            }}>
              Manage Venues
            </Link>

            <div style={{ 
              padding: '12px 15px',
              backgroundColor: pendingEvents > 0 ? '#e74c3c20' : '#ecf0f1',
              color: pendingEvents > 0 ? '#e74c3c' : '#7f8c8d',
              borderRadius: '4px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between'
            }}>
              <span>Pending Events: {pendingEvents}</span>
              {pendingEvents > 0 && (
                <Link to="/admin/events" style={{ color: '#e74c3c' }}>
                  Review
                </Link>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Second row */}
      <div style={{ display: 'flex', gap: '20px', marginBottom: '30px', flexWrap: 'wrap' }}>
        {/* Latest users table */}
        <div style={{
          flex: '2 1 500px',
          backgroundColor: 'white',
          borderRadius: '8px',
          padding: '20px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
        }}>
          <h3 style={{ marginTop: 0 }}>Latest Users</h3>
          
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr>
                <th style={{ textAlign: 'left', padding: '10px 0', borderBottom: '1px solid #eee' }}>Name</th>
                <th style={{ textAlign: 'left', padding: '10px 0', borderBottom: '1px solid #eee' }}>Email</th>
                <th style={{ textAlign: 'left', padding: '10px 0', borderBottom: '1px solid #eee' }}>Role</th>
                <th style={{ textAlign: 'right', padding: '10px 0', borderBottom: '1px solid #eee' }}>Joined</th>
              </tr>
            </thead>
            <tbody>
              {latestUsers.map(user => (
                <tr key={user.id}>
                  <td style={{ padding: '10px 0', borderBottom: '1px solid #eee' }}>{user.name}</td>
                  <td style={{ padding: '10px 0', borderBottom: '1px solid #eee' }}>{user.email}</td>
                  <td style={{ padding: '10px 0', borderBottom: '1px solid #eee' }}>
                    <span style={{ 
                      display: 'inline-block',
                      padding: '3px 8px',
                      borderRadius: '4px',
                      backgroundColor: roleColor(user.role),
                      color: 'white',
                      fontSize: '12px'
                    }}>
                      {user.role}
                    </span>
                  </td>
                  <td style={{ padding: '10px 0', borderBottom: '1px solid #eee', textAlign: 'right', color: '#7f8c8d', fontSize: '14px' }}>
                    {formatDate(user.createdAt)}
                  </td>
                </tr>
              ))}
              {latestUsers.length === 0 && (
                <tr>
                  <td colSpan="4" style={{ padding: '20px 0', textAlign: 'center', color: '#7f8c8d' }}>
                    No users found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
          
          <div style={{ marginTop: '15px', textAlign: 'right' }}>
            <Link to="/admin/users" style={{ color: '#3498db', textDecoration: 'none' }}>
              View All Users →
            </Link>
          </div>
        </div>

        {/* System Stats */}
        <div style={{
          flex: '1 1 300px',
          backgroundColor: 'white',
          borderRadius: '8px',
          padding: '20px',
          boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
        }}>
          <h3 style={{ marginTop: 0 }}>System Statistics</h3>
          
          <div style={{ marginBottom: '20px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '5px' }}>
              <span>Total Event Registrations</span>
              <span>{totalRegistrations}</span>
            </div>
            <div style={{ 
              height: '10px', 
              backgroundColor: '#ecf0f1',
              borderRadius: '5px',
              overflow: 'hidden'
            }}>
              <div style={{ 
                height: '100%', 
                width: '100%',
                backgroundColor: '#3498db',
                borderRadius: '5px'
              }} />
            </div>
          </div>
          
          <div style={{ marginBottom: '20px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '5px' }}>
              <span>Approved Events</span>
              <span>{events.filter(e => e.approved).length} / {events.length}</span>
            </div>
            <div style={{ 
              height: '10px', 
              backgroundColor: '#ecf0f1',
              borderRadius: '5px',
              overflow: 'hidden'
            }}>
              <div style={{ 
                height: '100%', 
                width: `${(events.filter(e => e.approved).length / Math.max(events.length, 1)) * 100}%`,
                backgroundColor: '#2ecc71',
                borderRadius: '5px'
              }} />
            </div>
          </div>
          
          {mostPopularClub && (
            <div style={{ 
              backgroundColor: '#f8f9fa', 
              borderRadius: '5px', 
              padding: '15px',
              marginBottom: '10px'
            }}>
              <h4 style={{ margin: '0 0 10px 0', fontSize: '16px' }}>Most Popular Club</h4>
              <p style={{ margin: '0 0 5px 0', fontWeight: 'bold' }}>{mostPopularClub.name}</p>
              <p style={{ margin: '0', fontSize: '14px', color: '#7f8c8d' }}>
                {clubMemberships[mostPopularClubId] || 0} members
              </p>
            </div>
          )}
          
          <div style={{ marginTop: '15px', textAlign: 'right' }}>
            <Link to="/admin/reports" style={{ color: '#3498db', textDecoration: 'none' }}>
              View All Reports →
            </Link>
          </div>
        </div>
      </div>

      {/* Recent System Activity */}
      <div style={{
        backgroundColor: 'white',
        borderRadius: '8px',
        padding: '20px',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
      }}>
        <h3 style={{ marginTop: 0 }}>Recent System Activity</h3>
        
        {/* We'll simulate some activity for now */}
        <ul style={{ padding: 0, margin: 0, listStyle: 'none' }}>
          {[
            { action: 'New user registered', time: '2 hours ago', user: 'John Doe', type: 'user' },
            { action: 'Club created', time: '1 day ago', user: 'Admin User', type: 'club' },
            { action: 'Event approved', time: '2 days ago', user: 'Admin User', type: 'event' },
            { action: 'Venue updated', time: '3 days ago', user: 'Admin User', type: 'venue' },
            { action: 'Certificate generated', time: '5 days ago', user: 'System', type: 'certificate' }
          ].map((activity, index) => (
            <li key={index} style={{ 
              padding: '10px 0', 
              borderBottom: index === 4 ? 'none' : '1px solid #ecf0f1',
              display: 'flex',
              justifyContent: 'space-between'
            }}>
              <div>
                <span style={{ 
                  display: 'inline-block',
                  width: '8px',
                  height: '8px',
                  borderRadius: '50%',
                  backgroundColor: activityColor(activity.type),
                  marginRight: '8px'
                }} />
                <strong>{activity.action}</strong>
                <span style={{ color: '#7f8c8d', marginLeft: '5px' }}>by {activity.user}</span>
              </div>
              <span style={{ color: '#7f8c8d' }}>{activity.time}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

// Helper functions
const roleColor = (role) => {
  switch(role) {
    case 'admin': return '#e74c3c';
    case 'faculty': return '#3498db';
    case 'studentCoordinator': return '#2ecc71';
    case 'student': return '#f39c12';
    default: return '#95a5a6';
  }
};

const activityColor = (type) => {
  switch(type) {
    case 'user': return '#3498db';
    case 'club': return '#2ecc71';
    case 'event': return '#e67e22';
    case 'venue': return '#9b59b6';
    case 'certificate': return '#e74c3c';
    default: return '#95a5a6';
  }
};

const formatDate = (dateString) => {
  if (!dateString) return 'Unknown';
  
  const options = { year: 'numeric', month: 'short', day: 'numeric' };
  const date = new Date(dateString);
  
  // If date is today, show "Today"
  const today = new Date();
  if (date.toDateString() === today.toDateString()) {
    return 'Today';
  }

  // If date is yesterday, show "Yesterday"
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  if (date.toDateString() === yesterday.toDateString()) {
    return 'Yesterday';
  }

  // Otherwise, show the date
  return date.toLocaleDateString(undefined, options);
};

export default AdminDashboard;
