import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

// Dashboard components
import AdminDashboard from './dashboards/AdminDashboard';
import FacultyDashboard from './dashboards/FacultyDashboard';
import StudentCoordinatorDashboard from './dashboards/StudentCoordinatorDashboard';
import StudentDashboard from './dashboards/StudentDashboard';

const Dashboard = () => {
  const { currentUser } = useAuth();

  // Redirect to login if not authenticated
  if (!currentUser) {
    return <Navigate to="/login" />;
  }

  // Render dashboard based on role
  switch(currentUser.role) {
    case 'admin':
      return <AdminDashboard />;
    case 'faculty':
      return <FacultyDashboard />;
    case 'studentCoordinator':
      return <StudentCoordinatorDashboard />;
    case 'student':
      return <StudentDashboard />;
    default:
      // Unknown role, redirect to login
      return <Navigate to="/login" />;
  }
};

export default Dashboard;
