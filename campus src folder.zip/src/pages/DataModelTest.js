import React, { useState } from 'react';
import { getDataModelSchema, getEntityRelationships } from '../utils/dataModel';
import * as dataUtils from '../utils/dataUtils';

const DataModelTest = () => {
  const [selectedCollection, setSelectedCollection] = useState('');
  const [records, setRecords] = useState([]);
  
  const schema = getDataModelSchema();
  const relationships = getEntityRelationships();

  const handleCollectionSelect = (collection) => {
    setSelectedCollection(collection);
    const data = dataUtils.getAll(collection);
    setRecords(data);
  };

  return (
    <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '20px' }}>
      <h1>Data Model Explorer</h1>
      
      <div style={{ display: 'flex', gap: '20px', marginBottom: '30px' }}>
        <div style={{ width: '300px', padding: '15px', backgroundColor: '#f5f5f5', borderRadius: '5px' }}>
          <h3>Collections</h3>
          <ul style={{ padding: 0, listStyle: 'none' }}>
            {Object.keys(schema).map(collection => (
              <li key={collection} style={{ marginBottom: '10px' }}>
                <button 
                  onClick={() => handleCollectionSelect(collection)}
                  style={{ 
                    width: '100%', 
                    padding: '8px', 
                    background: selectedCollection === collection ? '#4caf50' : '#e0e0e0',
                    color: selectedCollection === collection ? 'white' : 'black',
                    border: 'none',
                    borderRadius: '4px',
                    cursor: 'pointer',
                    textAlign: 'left'
                  }}
                >
                  {collection}
                </button>
              </li>
            ))}
          </ul>
        </div>
        
        <div style={{ flex: 1 }}>
          {selectedCollection ? (
            <div>
              <h2>{selectedCollection}</h2>
              
              <div style={{ marginBottom: '20px' }}>
                <h4>Schema</h4>
                <ul>
                  {Object.entries(schema[selectedCollection].schema).map(([field, type]) => (
                    <li key={field}>
                      <strong>{field}:</strong> {type}
                    </li>
                  ))}
                </ul>
              </div>
              
              {relationships[selectedCollection] && (
                <div style={{ marginBottom: '20px' }}>
                  <h4>Relationships</h4>
                  
                  {relationships[selectedCollection].belongsTo && (
                    <div>
                      <strong>Belongs To:</strong>
                      <ul>
                        {relationships[selectedCollection].belongsTo.map((rel, i) => (
                          <li key={i}>{rel}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                  
                  {relationships[selectedCollection].hasMany && (
                    <div>
                      <strong>Has Many:</strong>
                      <ul>
                        {relationships[selectedCollection].hasMany.map((rel, i) => (
                          <li key={i}>{rel}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              )}
              
              <h4>Records ({records.length})</h4>
              
              {records.length > 0 ? (
                <div style={{ overflowX: 'auto' }}>
                  <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                    <thead>
                      <tr>
                        {Object.keys(records[0]).map(header => (
                          <th 
                            key={header}
                            style={{ 
                              textAlign: 'left', 
                              padding: '8px', 
                              borderBottom: '2px solid #ddd',
                              whiteSpace: 'nowrap'
                            }}
                          >
                            {header}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {records.map((record, i) => (
                        <tr key={i}>
                          {Object.values(record).map((value, j) => (
                            <td 
                              key={j}
                              style={{ 
                                padding: '8px', 
                                borderBottom: '1px solid #ddd',
                                maxWidth: '200px',
                                overflow: 'hidden',
                                textOverflow: 'ellipsis',
                                whiteSpace: 'nowrap'
                              }}
                            >
                              {typeof value === 'object' 
                                ? JSON.stringify(value).substring(0, 50) + (JSON.stringify(value).length > 50 ? '...' : '') 
                                : String(value).substring(0, 50) + (String(value).length > 50 ? '...' : '')}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <p>No records found in this collection.</p>
              )}
            </div>
          ) : (
            <div style={{ textAlign: 'center', padding: '50px 0' }}>
              <p>Select a collection to view its data</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default DataModelTest;
