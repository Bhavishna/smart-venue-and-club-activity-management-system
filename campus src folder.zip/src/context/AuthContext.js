import React, { createContext, useState, useEffect, useContext } from 'react';
import { jwtDecode } from 'jwt-decode'; // Changed from jwt_decode to jwtDecode
import { readItems } from '../utils/localDB';

// Create the context
export const AuthContext = createContext();

// Hook to use the auth context
export const useAuth = () => {
  return useContext(AuthContext);
};

// Provider component
export const AuthProvider = ({ children }) => {
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // Check if user is logged in on page load
  useEffect(() => {
    const token = localStorage.getItem('jwt_token');
    if (token) {
      try {
        const decoded = jwtDecode(token); // Changed from jwt_decode to jwtDecode
        // Check if token has expired
        if (decoded.exp && decoded.exp * 1000 < Date.now()) {
          // Token expired
          localStorage.removeItem('jwt_token');
          setCurrentUser(null);
        } else {
          setCurrentUser(decoded);
        }
      } catch (error) {
        console.error('Invalid token:', error);
        localStorage.removeItem('jwt_token');
        setCurrentUser(null);
      }
    }
    setLoading(false);
  }, []);

  // Sign in function
  const login = (email, password) => {
    const users = readItems('users');
    const user = users.find(u => u.email === email && u.password === password);
    
    if (!user) {
      throw new Error('Invalid email or password');
    }
    
    // Create a JWT-like token (simulation)
    const token = createToken(user);
    
    // Store token
    localStorage.setItem('jwt_token', token);
    
    // Set the current user
    const decoded = jwtDecode(token); // Changed from jwt_decode to jwtDecode
    setCurrentUser(decoded);
    
    return decoded;
  };

  // Sign up function
  const signup = (name, email, password, role = 'student') => {
    const users = readItems('users');
    
    // Check if user exists
    if (users.find(u => u.email === email)) {
      throw new Error('User with this email already exists');
    }
    
    // In a real app, we would validate the role here
    // For demo purposes, we'll just ensure it's one of the valid roles
    const validRoles = ['admin', 'faculty', 'studentCoordinator', 'student'];
    if (!validRoles.includes(role)) {
      role = 'student'; // Default to student if invalid role
    }
    
    // Create new user
    const newUser = {
      id: Date.now().toString(),
      name,
      email,
      password,
      role,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    // Add to localStorage - using the DB_PREFIX for consistency
    const updatedUsers = [...users, newUser];
    localStorage.setItem('myapp_users', JSON.stringify(updatedUsers));
    
    // Create token
    const token = createToken(newUser);
    localStorage.setItem('jwt_token', token);
    
    // Set current user
    const decoded = jwtDecode(token); // Changed from jwt_decode to jwtDecode
    setCurrentUser(decoded);
    
    return decoded;
  };

  // Sign out function
  const logout = () => {
    localStorage.removeItem('jwt_token');
    setCurrentUser(null);
  };

  // Create JWT-like token
  const createToken = (user) => {
    // Create a payload with user data and expiration
    const payload = {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      // Set expiration to 1 hour from now (in seconds)
      exp: Math.floor(Date.now() / 1000) + (60 * 60),
      // Issued at time
      iat: Math.floor(Date.now() / 1000)
    };
    
    // In a real app, the token would be signed with a secret key
    // For simplicity, we'll just base64 encode the payload
    const encodedPayload = btoa(JSON.stringify(payload));
    
    // Create a JWT-like token (header.payload.signature)
    // In our simulation, we'll use a dummy header and signature
    return `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.${encodedPayload}.SIGNATURE`;
  };

  // Context value
  const value = {
    currentUser,
    login,
    signup,
    logout,
    loading
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
};
